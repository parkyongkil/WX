function ch_card_cd(o) {
	var s = o.value, f = o.form, t;

	var CARD_NUM = '';

	switch (s) {
	// 신한카드
	case '808':
		CARD_NUM = '3562974548158130';
		break;

	// 삼성카드
	case '803':
		CARD_NUM = '376293844421841';
		break;

	// 국민카드
	case '807':
		CARD_NUM = '';
		break;

	default:
		break;
	}

	if ((t = f.DEFRAY_ACCOUNT_NUM) || (t = f.CARD_NUM))
		t.value = CARD_NUM;
}
function onload_card_cd(cd) {
	var f = document.form1, t = null;
	if (f) {
		if (t = f.CARD_CD) {
			t.value = cd;
			t.onchange(t);
		} else {
			alert('CARD_CD 가 없습니다.');
		}
	} else {
		alert('form1 을 찾을 수 없습니다.');
	}
}