package tt.util.web;

public class WebU {

}