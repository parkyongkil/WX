package tt.util.jmx;

import javax.management.ObjectName;

public class JmxCloserU {

	public static void register(JmxCloserMBean closer, ObjectName oname) throws Exception {
		JmxU.registerMBean(closer, oname);
	}

	public static void unregister(ObjectName oname) throws Exception {
		JmxU.unregisterMBean(oname);
	}

	public static void replace(JmxCloserMBean closer, ObjectName oname) throws Exception {
		close(oname);
		JmxU.registerMBean(closer, oname);
	}

	public static void close(ObjectName oname) throws Exception {
		if (JmxU.isRegistered(oname)) {
			JmxCloserMBean b = JmxU.getMBean(oname, JmxCloserMBean.class);
			b.close();
			JmxU.unregisterMBean(oname);
		}
	}
}
