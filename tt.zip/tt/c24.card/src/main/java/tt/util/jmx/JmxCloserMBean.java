package tt.util.jmx;

public interface JmxCloserMBean {

	void close() throws Exception;
}
