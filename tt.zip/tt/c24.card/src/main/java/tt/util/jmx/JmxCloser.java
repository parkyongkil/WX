package tt.util.jmx;

import java.io.Closeable;

public class JmxCloser implements JmxCloserMBean {

	Closeable object;

	public JmxCloser(Closeable object) {
		super();
		this.object = object;
	}

	@Override
	public void close() throws Exception {
		object.close();
	}
}
