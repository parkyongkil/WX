package tt.util.net;

import java.io.OutputStream;
import java.net.Socket;

public class NetU {

	public static int request(Socket socket, byte[] b, byte[] r) throws Exception {
		OutputStream out = socket.getOutputStream();
		out.write(b);
		out.flush();
		return socket.getInputStream().read(r);
	}
}
