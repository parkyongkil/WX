package tt.io;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.List;

public class TDataU {

	public static List<Field> scanFieldList(Class<?> c) throws Exception {
		List<Field> l = new ArrayList<Field>();
		scanFieldList(c, l);
		return l;
	}

	public static void scanFieldList(Class<?> c, List<Field> l) throws Exception {
		if (c == null || !TData.class.isAssignableFrom(c) || c.isInterface())
			return;
		Class<?> s = c.getSuperclass();
		if (s != null)
			scanFieldList(s, l);
		Field[] fa = c.getDeclaredFields();
		for (Field f : fa) {
			int m = f.getModifiers();
			if (!Modifier.isStatic(m) && !Modifier.isTransient(m))
				l.add(f);
		}
	}
}
