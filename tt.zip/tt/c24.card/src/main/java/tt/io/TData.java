package tt.io;

import java.io.Serializable;

public interface TData extends Serializable, Cloneable {

}
