package tt.lang.string;

import java.nio.charset.Charset;

import org.apache.commons.lang3.StringUtils;

import tt.lang.string.builder.TStringBuilder;

public class StringU {

	public static String leftPad(String s, int n, char c) {
		if (s == null)
			s = "";
		while (s.length() < n)
			s = c + s;
		return s;
	}

	public static boolean isBlank(String s) {
		return StringUtils.isBlank(s);
	}

	public static String convertCharset(String s, String r, String w) {
		return convertCharset(s, Charset.forName(r), Charset.forName(w));
	}

	public static String convertCharset(String s, Charset r, Charset w) {
		return s == null ? s : new String(s.getBytes(r), w);
	}

	public static String toString(Object o) {
		TStringBuilder sb = new TStringBuilder();
		sb.write(o);
		return sb.buildString();
	}
}
