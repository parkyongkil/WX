package scg.c24.net.server;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import scg.c24.config.CardConfig;

@Component
public class CardServerFactory {

	@Autowired
	private CardServerMap cardServerMap;

	private ThreadGroup tg = new ThreadGroup(CardServer.class.getSimpleName());

	public CardServer create(CardConfig cardConfig) throws Exception {
		String key = cardConfig.getUid();
		CardServer server = cardServerMap.remove(key);
		if (server != null)
			server.close();
		cardServerMap.put(key, server = new CardServer(cardConfig));
		Thread t = new Thread(tg, server);
		t.start();
		return server;
	}
}
