package scg.c24.data;

public interface CardDataRemote {

	void toSCGS() throws Exception;

	void toCARD() throws Exception;
}
