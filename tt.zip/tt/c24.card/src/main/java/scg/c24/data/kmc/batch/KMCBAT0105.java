package scg.c24.data.kmc.batch;

import lombok.Data;
import lombok.EqualsAndHashCode;
import tt.io.annotation.AtLPad;
import tt.io.annotation.AtSize;

@Data
@EqualsAndHashCode(callSuper = true)
public class KMCBAT0105 extends KMCBAT0104 {

	@AtLPad(value = 3, pad = '0')
	public int emptyNo;

	@AtSize(100)
	public String chkb;
}
