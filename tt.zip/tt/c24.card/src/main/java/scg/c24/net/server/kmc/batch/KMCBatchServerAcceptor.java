package scg.c24.net.server.kmc.batch;

import java.io.File;
import java.io.FileOutputStream;
import java.net.Socket;
import java.nio.charset.Charset;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;

import scg.c24.config.CardConfig;
import scg.c24.data.kmc.batch.KMCBAT0100;
import scg.c24.data.kmc.batch.KMCBAT0101;
import scg.c24.data.kmc.batch.KMCBAT0102;
import scg.c24.data.kmc.batch.KMCBAT0104;
import scg.c24.data.kmc.batch.KMCBAT0105;
import scg.c24.net.server.CardServerService;
import scg.c24.net.server.GeneralCardServerAcceptor;
import scg.c24.util.CardSysUtil;

public class KMCBatchServerAcceptor extends GeneralCardServerAcceptor {

	protected Charset charset;

	public KMCBatchServerAcceptor(CardConfig cardConfig, CardServerService service, Socket socket) throws Exception {
		super(cardConfig, service, socket);
		this.charset = cardConfig.getCharset();
	}

	@Override
	public void run() {
		try {
			String fn = handle();
			if (StringUtils.isNotBlank(fn)) {
				if (fn.indexOf("KB01") != -1) {
					KMCCardRecev kbcr = new KMCCardRecev(cardConfig, fn);
					kbcr.run();
				} else if (fn.indexOf("SG00") != -1) {
					KMCTransChk kbtc = new KMCTransChk(cardConfig, fn);
					kbtc.run();
				}
			}
		} catch (Exception e) {
			if (log.isErrorEnabled())
				log.error(e.getMessage(), e);
		}
		close();
	}

	private static final int BLOCK_SEQ_NO = 100;

	public String handle() throws Exception {

		String receivePath = String.format("%s/%s/recvFile", cardConfig.getFilePath(), cardConfig.getUid());
		String recevFileNm = null;

		KMCBAT0101 q1 = transfer.readObject(KMCBAT0101.class);

		if ("0600".equals(q1.msgClass))
			return null;
		q1.msgClass = "0610";
		q1.sndTime = DateFormatUtils.format(new Date(), "MMddHHmmss");
		transfer.writeObject(q1);

		while (true) {
			KMCBAT0102 q2 = transfer.readObject(KMCBAT0102.class);

			if ("0630".equals(q2.msgClass) == false)
				return null;
			File f = null;
			long fz = 0;
			if (f == null && StringUtils.isBlank(q2.fileInfNm)) {
				f = new File(receivePath, CardSysUtil.toKMCDatePath(q2.fileInfNm));
				fz = f.exists() ? f.length() : 0;
				recevFileNm = q2.fileInfNm;
			}
			q2.rspnCd = fz < q2.fileInfSize ? "000" : "630";
			q2.fileInfSize = fz;
			transfer.writeObject(q2);

			if (recevFileNm == null)
				throw new Exception("파일이름을 수신하지 못하였습니다.");

			f.getParentFile().mkdirs();
			FileOutputStream fos = new FileOutputStream(f);

			byte[] chkb = new byte[BLOCK_SEQ_NO];
			for (int i = 0; i < BLOCK_SEQ_NO; i++)
				chkb[i] = '0';

			while (true) {
				byte[] b = transfer.read();
				KMCBAT0100 q3 = transfer.toObject(b, KMCBAT0100.class);

				// 송신완료
				if ("0600".equals(q3.msgClass))
					break;

				KMCBAT0104 q4 = transfer.toObject(b, KMCBAT0104.class);

				if ("0620".equals(q3.msgClass)) {
					KMCBAT0105 q5 = transfer.toObject(b, KMCBAT0105.class);
					int emptyNo = 0;
					for (int i = 0; i < q5.seqNo; i++)
						if (chkb[i] == '0')
							emptyNo++;
					q5.msgClass = "0300";
					q5.emptyNo = emptyNo;
					q5.chkb = new String(chkb);

					transfer.writeObject(q5);
				} else if (q3.msgClass.matches("^(0320|0310)$")) {
					int dataByteNo = Integer.parseInt(new String(b, 31, 4));
					String fileDtl = new String(b, 35, dataByteNo);
					if ("0320".equals(q3.msgClass) && fileDtl.trim().length() < 3000) {
						// 결번처리
					} else {
						chkb[q4.seqNo - 1] = '0';
						fos.write(b, 35, dataByteNo);
					}
				}
			}
			fos.close();

			byte[] b = transfer.read();
			log.info(String.format("BR: [%s]", new String(b, charset)));

			q1.msgClass = "0610";
			q1.sndTime = DateFormatUtils.format(new Date(), "MMddHHmmss");

			transfer.writeObject(q1);
			return recevFileNm;
		}
	}
}
