package scg.c24.logview;

import java.io.IOException;
import java.nio.charset.Charset;

import javax.websocket.OnClose;
import javax.websocket.OnError;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.Session;
import javax.websocket.server.PathParam;
import javax.websocket.server.ServerEndpoint;

import org.slf4j.LoggerFactory;

import ch.qos.logback.classic.Logger;
import ch.qos.logback.classic.LoggerContext;
import ch.qos.logback.classic.encoder.PatternLayoutEncoder;
import ch.qos.logback.classic.spi.ILoggingEvent;

@ServerEndpoint("/logview/{loggerName}")
public class LogviewController {

	private static long NO;
	Session session;
	String loggerName;
	String appenderName;
	String charset = "UTF-8";

	LogviewAppender<ILoggingEvent> appender;
	Logger logger;

	@OnOpen
	public void handleOpen(Session session, @PathParam("loggerName") String loggerName) throws IOException {
		this.session = session;
		this.loggerName = loggerName;
		this.appenderName = String.format("LCA_%d", NO++);
		this.startLog();
	}

	@OnMessage
	public String handleMessage(String message) {
		String replymessage = "echo " + message;
		return replymessage;
	}

	@OnClose
	public void handleClose() {
		this.stopLog();
	}

	@OnError
	public void handleError(Throwable t) {
		t.printStackTrace();
		this.stopLog();
	}

	public void startLog() throws IOException {

		LoggerContext context = (LoggerContext) LoggerFactory.getILoggerFactory();

		PatternLayoutEncoder encoder = new PatternLayoutEncoder();
		encoder.setContext(context);
		encoder.setCharset(Charset.forName(charset));
		encoder.setPattern("%d{HH:mm:ss} %-5level %logger{36} - %msg%n");
		encoder.setOutputPatternAsHeader(true);
		encoder.setImmediateFlush(true);
		encoder.start();

		appender = new LogviewAppender<>();
		appender.setContext(context);
		appender.setName(appenderName);
		appender.setEncoder(encoder);
		appender.setSession(session);
		appender.start();

		logger = context.getLogger(loggerName);
		logger.addAppender(appender);
		logger.info(String.format("START LOG_CAPTURE: %s, %s", loggerName, appenderName));
	}

	public void stopLog() {
		if (logger != null) {
			logger.info(String.format("END LOG_CAPTURE: %s, %s", loggerName, appenderName));
			if (logger.isAttached(appender))
				logger.detachAppender(appender);
		}
	}
}
