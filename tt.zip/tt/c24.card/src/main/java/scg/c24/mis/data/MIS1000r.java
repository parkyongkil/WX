package scg.c24.mis.data;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import lombok.Data;
import lombok.EqualsAndHashCode;
import scg.c24.data.CardData;

/**
 * @제목 사용계약번호조회 응답 (1000, 8050)
 */

@Data
@EqualsAndHashCode(callSuper = true)
@XmlRootElement(name = "SCGM")
@XmlAccessorType(XmlAccessType.FIELD)
public class MIS1000r extends MISr {

	public List<Cont> USE_CONTS;

	@Data
	@XmlRootElement(name = "SCGM")
	@XmlAccessorType(XmlAccessType.FIELD)
	public static class Cont implements CardData {

		public String USE_CONT_NUM;

		public String ADDR;
	}
}
