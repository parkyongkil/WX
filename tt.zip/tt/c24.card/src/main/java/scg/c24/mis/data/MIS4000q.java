package scg.c24.mis.data;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @제목 카드인증 요청 (4000, 9050)
 */

@Data
@EqualsAndHashCode(callSuper = true)
@XmlRootElement(name = "SCGM")
@XmlAccessorType(XmlAccessType.FIELD)
public class MIS4000q extends MISq {

	/** 카드번호 */
	public String CARD_NUM;

	/** 카드소유자 주민번호 */
	public String SOC_BIZ_NUM;

	/** 카드소유자 이름 (국민카드 사용안함) */
	public String DEPOSITOR_NM;
}
