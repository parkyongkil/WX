package scg.c24.net.transfer;

import java.io.ByteArrayInputStream;
import java.net.Socket;
import java.nio.charset.Charset;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import scg.c24.config.CardConfig;
import scg.c24.data.CardData;
import tt.io.TDataInputStream;
import tt.io.TDataOutputStream;

public abstract class CardDataTransfer<D extends CardData> {

	protected CardConfig cardConfig;
	protected Socket socket;
	protected Charset charset;
	protected String uid;
	protected TDataInputStream in;
	protected TDataOutputStream out;
	protected boolean toSCGS;
	protected String rx;
	protected String wx;
	protected Log log = LogFactory.getLog(getClass());

	public CardDataTransfer(CardConfig cardConfig, Socket socket, boolean toSCGS) throws Exception {
		super();
		this.cardConfig = cardConfig;
		this.socket = socket;
		this.charset = cardConfig.getCharset();
		this.uid = cardConfig.getUid();
		this.toSCGS = toSCGS;
		this.rx = toSCGS ? "TQ" : "TR";
		this.wx = toSCGS ? "TR" : "TQ";
		this.in = new TDataInputStream(socket.getInputStream(), charset);
		this.out = new TDataOutputStream(socket.getOutputStream(), charset);
	}

	public abstract byte[] read() throws Exception;

	public abstract D toObject(byte[] b) throws Exception;

	@SuppressWarnings("resource")
	public <X> X toObject(byte[] b, Class<X> c) throws Exception {
		return new TDataInputStream(new ByteArrayInputStream(b), in.getCharset()).readObject(c);
	}

	public D readObject() throws Exception {
		byte[] b = read();
		return toObject(b);
	}

	public <X> X readObject(Class<X> c) throws Exception {
		byte[] b = read();
		return toObject(b, c);
	}

	public abstract void write(byte[] b) throws Exception;

	public abstract byte[] toByteArray(D o) throws Exception;

	public void writeObject(D o) throws Exception {
		byte[] b = toByteArray(o);
		write(b);
	}

	public TDataInputStream getInputStream() {
		return in;
	}
}
