package scg.c24.biz.db.kmc.model;

import lombok.Data;

@Data
public class KMCUseContTrans {

	String CUST_NUM;

	String DEFRAY_ACCOUNT_NUM;

	String REQ_INFO_NUM;

	String REQ_YMD;

	String TREAT_FLAG;

	String TRANS_YN;

	String APPLY_YMD;
}
