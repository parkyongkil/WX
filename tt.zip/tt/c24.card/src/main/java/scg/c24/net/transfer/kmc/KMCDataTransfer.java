package scg.c24.net.transfer.kmc;

import java.io.ByteArrayOutputStream;
import java.net.Socket;
import java.util.Arrays;

import org.apache.commons.lang3.math.NumberUtils;

import scg.c24.config.CardConfig;
import scg.c24.data.kmc.KMC1000;
import scg.c24.data.kmc.KMC2000;
import scg.c24.data.kmc.KMC3000;
import scg.c24.data.kmc.KMC4000;
import scg.c24.data.kmc.KMCData;
import scg.c24.net.transfer.CardDataTransfer;
import tt.io.TDataOutputStream;
import tt.lang.string.StringU;

public class KMCDataTransfer extends CardDataTransfer<KMCData> {

	public static final int HL = KMCData.HL;

	public KMCDataTransfer(CardConfig cardConfig, Socket socket, boolean toSCGS) throws Exception {
		super(cardConfig, socket, toSCGS);
	}

	@Override
	public byte[] read() throws Exception {

		byte[] a = new byte[HL];
		int n0 = in.read(a);
		if (n0 != HL)
			throw new Exception(String.format("전문의 공통부의 길이(%d)가 표준(%d)보다 짧습니다.\n[%s]\n%s", n0, HL,
					new String(a, in.getCharset()), Arrays.toString(a)));

		String sx = new String(a, 0, 4);
		int n1 = n0;
		int n2 = n0 - HL;
		int n3 = n2;

		if (n3 < 0)
			throw new Exception(String.format("전문의 전체길이값(%d)이 공통부의 길이값(%d) 보다 작습니다.\n[%s]\n%s\n%s: %s", n1, HL,
					new String(a, in.getCharset()), Arrays.toString(a), rx,
					StringU.toString(toObject(a, KMCData.class))));

		byte[] b = new byte[n1];
		System.arraycopy(a, 0, b, 0, HL);

		boolean rf = false;

		int n4 = 0;
		try {
			if (rf)
				in.readFully(b, HL, n3);
			else
				n4 = in.read(b, HL, n3);
		} catch (Exception e) {
			throw new Exception(String.format("%s\n%s: %s (%5d,%4d)\n[%s]\n%s", e.getMessage(), rx, sx, n1, n2,
					new String(b, in.getCharset()), Arrays.toString(b)), e);
		}
		if (n4 != n3) {
			String e1 = String.format("전문의 전체길이가 기대값과 일치하지 않습니다.(기대값=%d,실제값=%d)", HL + n3, HL + n4);
			String e2 = String.format("%s: %s (%5d,%4d)\n[%s]\n%s", rx, sx, n1, n2,
					new String(b, 0, HL + n4, in.getCharset()), Arrays.toString(b));
			throw new Exception(String.format("%s\n%s", e1, e2));
		} else if (log.isInfoEnabled())
			log.info(String.format("\n%s: %s (%5d,%4d)\n[%s]", rx, sx, n1, n2, new String(b, in.getCharset())));

		return b;
	}

	@Override
	public KMCData toObject(byte[] b) throws Exception {
		String sx = new String(b, 0, 4);
		int nx = NumberUtils.toInt(sx);
		Class<? extends KMCData> c = null;
		switch (nx) {

		// 서버 (카드사 -> 서울도시가스 -> 카드사)

		case 1000: // 계약정보 조회 (1000, 8050)
		case 1100:
			c = KMC1000.class;
			break;

		case 2000: // 카드자동납부신청 요청 (2000, 8150)
		case 2100:
			c = KMC2000.class;
			break;

		// 클라이어트 (MIS -> 카드사 -> MIS)

		case 3000: // 카드자동납부신청 요청 (3000, 9150)
		case 3100:
			c = KMC3000.class;
			break;
		case 4000: // 제목 카드인증 요청 (4000, 9050)
		case 4100:
			c = KMC4000.class;
			break;
		default:
			throw new Exception(String.format("처리할 수 없는 전문구분번호(%s)입니다.", sx));
		}
		return toObject(b, c);
	}

	@Override
	public void write(byte[] b) throws Exception {
		String sx = new String(b, 0, 4);
		int n1 = b.length;
		int n2 = n1 - HL;
		if (log.isInfoEnabled())
			log.info(String.format("\n%s: %s (%5d,%4d)\n[%s]", wx, sx, n1, n2, new String(b, in.getCharset())));
		out.writeUnsignedShort(n1);
		out.write(b);
		out.flush();
	}

	@Override
	public byte[] toByteArray(KMCData o) throws Exception {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		TDataOutputStream tdos = new TDataOutputStream(baos, charset);
		tdos.writeObject(o);
		tdos.close();
		return baos.toByteArray();
	}
}
