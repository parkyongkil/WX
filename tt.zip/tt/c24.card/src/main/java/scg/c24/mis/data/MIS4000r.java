package scg.c24.mis.data;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @제목 카드인증 응답
 */

@Data
@EqualsAndHashCode(callSuper = true)
@XmlRootElement(name = "SCGM")
@XmlAccessorType(XmlAccessType.FIELD)
public class MIS4000r extends MISr {

	/** 카드상태(2) */
	public String CARD_STS_CD;

	/** 제휴여부(1) YN (국민은행만 사용) */
	public String JOIN_YN;

	/** 카드유효기간(4) */
	public String VALID_YM;
}
