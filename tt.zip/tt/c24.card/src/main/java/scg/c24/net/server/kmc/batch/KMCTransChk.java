package scg.c24.net.server.kmc.batch;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.charset.Charset;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.sql.DataSource;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import scg.c24.ApplicationContextHolder;
import scg.c24.config.CardConfig;
import scg.c24.data.kmc.batch.KMCBAT0401;
import scg.c24.net.client.kmc.batch.KMCBatchClient;
import scg.c24.util.CardSysUtil;
import tt.io.TDataInputStream;
import tt.lang.string.StringU;

public class KMCTransChk {

	private Connection conn = null;
	private PreparedStatement ps = null;
	private ResultSet rs = null;

	private String fileNm = "";

	private static final int MSG_LEN = 700; // 황정현 수정 600 -> 700

	private FileInputStream fis = null;
	private FileOutputStream fos = null;
	private String recevPath = "./recvFile/";
	private String sendPath = "./sendFile/";

	private DataSource dataSource = ApplicationContextHolder.getBean(DataSource.class);

	private CardConfig cardConfig2;
	private Charset charset;
	private Log log = LogFactory.getLog(getClass());

	public KMCTransChk(CardConfig cardConfig2, String fileNm) {
		this.cardConfig2 = cardConfig2;
		this.fileNm = fileNm;
		this.charset = cardConfig2.getCharset();
		this.recevPath = String.format("%s/%s/recvFile/", cardConfig2.getFilePath(), cardConfig2.getUid());
		this.sendPath = String.format("%s/%s/sendPath/", cardConfig2.getFilePath(), cardConfig2.getUid());
	}

	public void run() {
		String strYmd = null;
		String sendFileNm = null;

		try {
			File f1 = new File(recevPath, CardSysUtil.toKMCDatePath(fileNm));
			fis = new FileInputStream(f1);

			byte[] readByte = new byte[MSG_LEN];

			int n = fis.read(readByte, 0, MSG_LEN);

			if (n != MSG_LEN)
				throw new Exception(String.format("건단위로 읽어들인 메세지의 길이가 일치하지 않습니다.(기대값=%d, 읽어들인값=%d)\n읽어들인 메세지: [%s]",
						MSG_LEN, n, new String(readByte, 0, n, charset)));

			strYmd = new String(readByte, 8, 8);

			conn = dataSource.getConnection();
			conn.setAutoCommit(false);
			ps = conn.prepareStatement(sqlInsert);

			int count = 0;
			int loopCnt = 0;
			int loopMax = 1000000000;

			while (true) {
				if (loopCnt++ > loopMax)
					throw new Exception(String.format("Exceeded loopMax(%d)", loopMax));

				fis.read(readByte, 0, MSG_LEN);
				KMCBAT0401 kb1 = TDataInputStream.toObject(readByte, KMCBAT0401.class, charset);
				if (kb1.strSeq != null && kb1.strSeq.equals("99999999"))
					break;
				count++;

				log.info(String.format("FI(%s): %s", f1.getName(), StringU.toString(kb1)));

				ps.setString(1, kb1.useContNum);
				ps.setString(2, kb1.cardNum);
				ps.setString(3, kb1.socNum);
				ps.setString(4, kb1.custNm);
				ps.setString(5, kb1.relatCd);
				ps.setString(6, kb1.pathFlag);
				ps.setString(7, kb1.stsCd);
				ps.setString(8, kb1.reqNm);
				ps.setString(9, kb1.cpDdd);
				ps.setString(10, kb1.cpExn);
				ps.setString(11, kb1.cpNum);
				ps.setString(12, kb1.ownhouseTelDdd);
				ps.setString(13, kb1.ownhouseTelExn);
				ps.setString(14, kb1.ownhouseTelNum);
				ps.setString(15, kb1.applyYm);
				ps.setString(16, kb1.contCustNm);
				ps.setString(17, kb1.zipNo);
				ps.setString(18, kb1.zipAddr);
				ps.setString(19, kb1.etcAddr);
				// ps.setString(20, ci); //추가
				// ps.setString(21, filler); //추가

				ps.executeUpdate();

				/* CI가 있을 경우 C1AT_CERT_MST INSERT */
				// setCI(useContNum, ci);
				// getCI(useContNum);

			}
			int maxCount = Integer.parseInt(new String(readByte, 8, 8));

			if (count != maxCount) {

			}

			conn.commit();

		} catch (Exception e) {
			e.printStackTrace();
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		} finally {
			if (ps != null)
				try {
					ps.close();
				} catch (Exception e) {
				}
			if (conn != null)
				try {
					conn.close();
				} catch (Exception e) {
				}
			if (fis != null)
				try {
					fis.close();
				} catch (Exception e) {
				}
		}

		try {
			Date yesterday = new Date();
			yesterday.setTime(new Date().getTime() - (24 * 60 * 60 * 1000));

			strYmd = new SimpleDateFormat("yyyyMMdd").format(yesterday);
			// sendFileNm = "SG11" + strYmd.substring(4, 8);
			sendFileNm = "SG11" + new SimpleDateFormat("MMdd").format(new Date());

			fos = new FileOutputStream(new File(sendPath, CardSysUtil.toKMCDatePath(sendFileNm)), false);

			conn = dataSource.getConnection();

			ps = conn.prepareStatement(sqlSelect);
			ps.setString(1, strYmd);
			ps.setString(2, strYmd);
			rs = ps.executeQuery();

			String outMsg;

			outMsg = "00000000" + strYmd + StringUtils.repeat(' ', 684);

			fos.write(outMsg.getBytes("euc-kr"));

			int count = 0;

			while (rs.next()) {
				count++;

				// CI 세팅
				// String strCi = getCI(rs.getString("DEFRAY_ACCOUNT_NUM"),
				// rs.getString("REQ_INFO_NUM"));
				outMsg = StringUtils.leftPad(rs.getString("SEQ"), 8, '0')
						+ StringUtils.rightPad(rs.getString("REQ_INFO_NUM"), 20)
						+ StringUtils.rightPad(rs.getString("DEFRAY_ACCOUNT_NUM"), 16)
						+ StringUtils.rightPad(rs.getString("SOC_BIZ_NUM").substring(0, 6) + "0000000", 13)
						+ StringUtils.rightPad(rs.getString("DEPOSITOR_NM"), 30)
						+ StringUtils.rightPad(convRelatCd(rs.getString("CUST_RELAT_CD"), 1), 2)
						+ StringUtils.rightPad(rs.getString("REQ_PATH"), 1)
						+ StringUtils.rightPad(rs.getString("RECEIVE_STS_CD"), 2)
						+ StringUtils.rightPad(rs.getString("REQ_NM"), 30)
						+ StringUtils.rightPad(rs.getString("REQ_TEL_DDD"), 4)
						+ StringUtils.rightPad(rs.getString("REQ_TEL_EXN"), 4)
						+ StringUtils.rightPad(rs.getString("REQ_TEL_NUM"), 4)
						+ StringUtils.rightPad(rs.getString("DEPOSITOR_TEL_DDD"), 4)
						+ StringUtils.rightPad(rs.getString("DEPOSITOR_TEL_EXN"), 4)
						+ StringUtils.rightPad(rs.getString("DEPOSITOR_TEL_NUM"), 4)
						+ StringUtils.rightPad(rs.getString("ORIG_APPLY_YM"), 8)
						+ StringUtils.rightPad(rs.getString("CUST_NM"), 30)
						+ StringUtils.rightPad(rs.getString("ZIP_NO"), 6)
						+ StringUtils.rightPad(rs.getString("ADDR1"), 150)
						+ StringUtils.rightPad(rs.getString("ADDR2"), 150) + StringUtils.rightPad(" ", 88)
						+ StringUtils.rightPad(" ", 122);

				fos.write(outMsg.getBytes("euc-kr"));
			}

			outMsg = "99999999" + StringUtils.leftPad(Integer.toString(count), 8, '0') + StringUtils.rightPad(" ", 684);

			fos.write(outMsg.getBytes("euc-kr"));

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (rs != null)
				try {
					rs.close();
				} catch (Exception e) {
				}
			if (ps != null)
				try {
					ps.close();
				} catch (Exception e) {
				}
			if (conn != null)
				try {
					conn.close();
				} catch (Exception e) {
				}
			if (fos != null)
				try {
					fis.close();
				} catch (Exception e) {
				}
		}

		KMCBatchClient KBBC = new KMCBatchClient(cardConfig2, sendFileNm);
		try {
			KBBC.start();
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
	}

	private final static String sqlInsert = " INSERT " + "   INTO C11.C1BT_CARD_TRANS_INF " + "    ( "
			+ "        JOB_YMD " + "      , DATA_FLAG " + "      , SEQ " + "      , CRT_DTM " + "      , CRT_EMPID "
			+ "      , CRT_IP " + "      , USE_CONT_NUM " + "      , CARD_NUM " + "      , SOC_NUM "
			+ "      , CARD_CUST_NM " + "      , REQ_RELAT_CD " + "      , REQ_PATH_FLAG " + "      , RECEIVE_STS_CD "
			+ "      , REQ_NM " + "      , CP_DDD " + "      , CP_EXN " + "      , CP_NUM "
			+ "      , OWNHOUSE_TEL_DDD " + "      , OWNHOUSE_TEL_EXN " + "      , OWNHOUSE_TEL_NUM "
			+ "      , FIRST_APPLY_YMD " + "      , CONT_CUST_NM " + "      , ZIP_NO " + "      , ZIP_ADDR "
			+ "      , ETC_ADDR " + "    ) " + "    VALUES " + "    ( " + "        TO_CHAR(SYSDATE, 'YYYYMMDD') "
			+ "      , '1' " + "      , (SELECT NVL(MAX(SEQ), 0) + 1 " + "           FROM C11.C1BT_CARD_TRANS_INF "
			+ "          WHERE JOB_YMD = TO_CHAR(SYSDATE, 'YYYYMMDD') " + "        ) " + "      , SYSDATE "
			+ "      , 'SYSTEM' " + "      , '*.*.*.*' " + "      , nvl(?, ' ') " + "      , ? " + "      , ? "
			+ "      , ? " + "      , ? " + "      , ? " + "      , ? " + "      , ? " + "      , ? " + "      , ? "
			+ "      , ? " + "      , ? " + "      , ? " + "      , ? " + "      , ? " + "      , ? " + "      , ? "
			+ "      , ? " + "      , ? " + "    )";

	private final static String sqlSelect = " SELECT ROW_NUMBER() OVER(ORDER BY UPD_DTM) SEQ " + "      , A.* "
			+ "   FROM " + "    (SELECT A.REQ_INFO_NUM " + "          , A.DEFRAY_ACCOUNT_NUM "
			+ "          , B.SOC_BIZ_NUM " + "          , B.DEPOSITOR_NM " + "          , B.CUST_RELAT_CD "
			+ "          , DECODE(A.RECEIVE_SEC_CD, '6', '2', '1') REQ_PATH "
			+ "          , DECODE(A.RECEIVE_STS_CD, '30', '30', '10') RECEIVE_STS_CD " + "          , C.REQ_NM "
			+ "          , C.REQ_TEL_DDD " + "          , C.REQ_TEL_EXN " + "          , C.REQ_TEL_NUM "
			+ "          , B.DEPOSITOR_TEL_DDD " + "          , B.DEPOSITOR_TEL_EXN "
			+ "          , B.DEPOSITOR_TEL_NUM " + "          , A.ORIG_APPLY_YM " + "          , E.CUST_NM "
			+ "          , G.ZIP_NO1 || G.ZIP_NO2 ZIP_NO "
			+ "          , G.CITY || ' ' || G.COUNTY || ' ' || G.TOWN ADDR1 "
			+ "          , SUBSTR(F.CURR_ADDR_UNION, LENGTH(G.CITY || ' ' || G.COUNTY || ' ' || G.TOWN || ' ') + 1) ADDR2 "
			+ "          , A.UPD_DTM " +
			// " , (SELECT NVL(CI_NUM, '') FROM C11.C1AT_CERT_MST WHERE
			// CERT_MANAGE_FLAG = '40' AND CERT_MANAGE_NUM = B.SOC_BIZ_NUM)
			// CI_NUM " +
			// " , (SELECT NVL(CI_NUM, '') FROM C11.C1AT_CERT_MST WHERE
			// CERT_MANAGE_FLAG = '40' AND CERT_MANAGE_NUM = (SELECT SOC_NUM
			// FROM C11.C1BT_USE_CONT A, C11.C1AT_CUST_INFO B WHERE A.CUST_NUM =
			// B.CUST_NUM AND A.USE_CONT_NUM = trim(A.REQ_INFO_NUM))) CI_NUM " +
			"       FROM C11.C1BT_USE_CONT_TRANS A " + "          , C11.C1AT_TRANS_ACNT B "
			+ "          , C11.C1AT_TRANS_ACNT_REQ C " + "          , C11.C1BT_USE_CONT D "
			+ "          , C11.C1AT_CUST_INFO E " + "          , C31.C3AT_INST_PLACE F " + "          , A11.A1AT_ZIP G "
			+ "      WHERE A.REQ_YMD = ? " + "        AND A.CNL_YMD = '99991231' "
			+ "        AND A.RECEIVE_STS_CD = '20' " + "        AND A.BNK_CD = '807' "
			+ "        AND A.DEFRAY_ACCOUNT_NUM = B.DEFRAY_ACCOUNT_NUM " + "        AND A.CUST_NUM = B.CUST_NUM "
			+ "        AND A.DEFRAY_ACCOUNT_NUM = C.DEFRAY_ACCOUNT_NUM(+) " + "        AND A.CUST_NUM = C.CUST_NUM(+) "
			+ "        AND A.REQ_YMD = C.REQ_YMD(+) " + "        AND A.REQ_INFO_NUM = D.REQ_INFO_NUM "
			+ "        AND D.CUST_NUM = E.CUST_NUM " + "        AND D.INST_PLACE_NUM = F.INST_PLACE_NUM "
			+ "        AND F.ZIP_SEQ = G.ZIP_SEQ " + "        AND C.REQ_ITEM_CD(+) = '02' " + "      UNION ALL "
			+ "     SELECT A.REQ_INFO_NUM " + "          , A.DEFRAY_ACCOUNT_NUM " + "          , B.SOC_BIZ_NUM "
			+ "          , B.DEPOSITOR_NM " + "          , B.CUST_RELAT_CD "
			+ "          , DECODE(A.RECEIVE_SEC_CD, '6', '2', '1') REQ_PATH "
			+ "          , DECODE(A.RECEIVE_STS_CD, '30', '30', '10') RECEIVE_STS_CD " + "          , C.REQ_NM "
			+ "          , C.REQ_TEL_DDD " + "          , C.REQ_TEL_EXN " + "          , C.REQ_TEL_NUM "
			+ "          , B.DEPOSITOR_TEL_DDD " + "          , B.DEPOSITOR_TEL_EXN "
			+ "          , B.DEPOSITOR_TEL_NUM " + "          , A.ORIG_APPLY_YM " + "          , E.CUST_NM "
			+ "          , G.ZIP_NO1 || G.ZIP_NO2 ZIP_NO "
			+ "          , G.CITY || ' ' || G.COUNTY || ' ' || G.TOWN ADDR1 "
			+ "          , SUBSTR(F.CURR_ADDR_UNION, LENGTH(G.CITY || ' ' || G.COUNTY || ' ' || G.TOWN || ' ') + 1) ADDR2 "
			+ "          , A.UPD_DTM " +
			// " , (SELECT NVL(CI_NUM, '') FROM C11.C1AT_CERT_MST WHERE
			// CERT_MANAGE_FLAG = '40' AND CERT_MANAGE_NUM = B.SOC_BIZ_NUM)
			// CI_NUM " +
			// " , (SELECT NVL(CI_NUM, '') FROM C11.C1AT_CERT_MST WHERE
			// CERT_MANAGE_FLAG = '40' AND CERT_MANAGE_NUM = (SELECT SOC_NUM
			// FROM C11.C1BT_USE_CONT A, C11.C1AT_CUST_INFO B WHERE A.CUST_NUM =
			// B.CUST_NUM AND A.USE_CONT_NUM = trim(A.REQ_INFO_NUM))) CI_NUM " +
			"       FROM C11.C1BT_USE_CONT_TRANS A " + "          , C11.C1AT_TRANS_ACNT B "
			+ "          , C11.C1AT_TRANS_ACNT_REQ C " + "          , C11.C1BT_USE_CONT D "
			+ "          , C11.C1AT_CUST_INFO E " + "          , C31.C3AT_INST_PLACE F " + "          , A11.A1AT_ZIP G "
			+ "      WHERE A.CNL_YMD = ? " + "        AND A.BNK_CD = '807' " + "        AND (SELECT COUNT( * ) "
			+ "               FROM C11.C1BT_USE_CONT_TRANS X " + "              WHERE X.REQ_INFO_NUM = A.REQ_INFO_NUM "
			+ "                AND X.DEFRAY_ACCOUNT_NUM = A.DEFRAY_ACCOUNT_NUM "
			+ "                AND X.RECEIVE_STS_CD = '20' " + "                AND X.BNK_CD = '807') = 0 "
			+ "        AND A.DEFRAY_ACCOUNT_NUM = B.DEFRAY_ACCOUNT_NUM " + "        AND A.CUST_NUM = B.CUST_NUM "
			+ "        AND A.DEFRAY_ACCOUNT_NUM = C.DEFRAY_ACCOUNT_NUM(+) " + "        AND A.CUST_NUM = C.CUST_NUM(+) "
			+ "        AND A.REQ_YMD = C.REQ_YMD(+) " + "        AND A.REQ_INFO_NUM = D.REQ_INFO_NUM "
			+ "        AND D.CUST_NUM = E.CUST_NUM " + "        AND D.INST_PLACE_NUM = F.INST_PLACE_NUM "
			+ "        AND F.ZIP_SEQ = G.ZIP_SEQ " + "        AND C.REQ_ITEM_CD(+) = '08' " + "    ) A ";

	/* convRelatCd(String relatCd, int direction) - 상호간 관계코드변환 direction : 0 (KMC -> SCG) 1 (SCG -> KMC) */
	private static String convRelatCd(String relatCd, int direction) {
		String rValue = null;

		if (direction == 0 && relatCd != null) {
			if (relatCd.equals("01"))
				rValue = "10";
			else if (relatCd.equals("02"))
				rValue = "11";
			else if (relatCd.equals("03"))
				rValue = "13";
			else if (relatCd.equals("04"))
				rValue = "21";
			else if (relatCd.equals("05"))
				rValue = "12";
			else if (relatCd.equals("06"))
				rValue = "12";
			else if (relatCd.equals("07"))
				rValue = "14";
			else if (relatCd.equals("09"))
				rValue = "16";
			else
				rValue = "16";
		} else if (direction == 1 && relatCd != null) {
			if (relatCd.equals("10"))
				rValue = "01";
			else if (relatCd.equals("11"))
				rValue = "02";
			else if (relatCd.equals("12"))
				rValue = "05";
			else if (relatCd.equals("13"))
				rValue = "03";
			else if (relatCd.equals("14"))
				rValue = "07";
			else if (relatCd.equals("16"))
				rValue = "09";
			else if (relatCd.equals("21"))
				rValue = "04";
			else if (relatCd.equals("22"))
				rValue = "04";
			else
				rValue = "09";
		}
		return rValue;
	}

	/* public static void main(String[] args) { run(); } */

	public void setCI(String useContNum, String ci) {
		try {
			conn = dataSource.getConnection();

			String sql = "SELECT * FROM C11.C1BT_USE_CONT A, " + " C11.C1AT_CUST_INFO B "
					+ " WHERE A.CUST_NUM = B.CUST_NUM " + " AND A.USE_CONT_NUM = trim(?) ";

			ps = conn.prepareStatement(sql);
			ps.setString(1, useContNum);
			rs = ps.executeQuery();
			rs.next();

			String jumin = rs.getString("SOC_NUM");
			String custname = rs.getString("CUST_NM");
			String realNmCofYmd = new SimpleDateFormat("yyyyMMdd").format(new Date());

			if (rs != null)
				rs.close();
			if (ps != null)
				ps.close();
			if (conn != null)
				conn.close();

			String sqlInsert = "MERGE INTO " + " C11.C1AT_CERT_MST A " + " USING DUAL " + " ON (A.CERT_MANAGE_FLAG = ? "
					+ " AND A.CERT_MANAGE_NUM = trim(?)) " + " WHEN MATCHED THEN " + " UPDATE SET "
					+ " UPD_DTM = sysdate " + " , UPD_EMPID = NVL(?,' ') " + " , UPD_IP = NVL(?,' ') "
					+ " , SOC_BIZ_NUM_BNK = trim(?) " + " , CUST_NM = trim(?) " + " , BNK_CD = NVL(?,' ') "
					+ " , DEPOSITOR_NM = trim(?) " + " , CERT_YMD = NVL(?,' ') " + " WHEN NOT MATCHED THEN "
					+ " INSERT ( " + " CERT_MANAGE_FLAG    --인증관리구분 " + " , CERT_MANAGE_NUM    --인증관리번호 "
					+ " , CRT_EMPID    --등록자사번 " + " , CRT_IP    --등록IP " + " , SOC_BIZ_NUM_BNK    --주민번호사업자(계좌) "
					+ " , CUST_NM    --고객명 " + " , BNK_CD    --은행코드 " + " , DEPOSITOR_NM    --예금주명 "
					+ " , CERT_YMD    --인증일자 " + " , CI_NUM		--CI번호 " + " , DI_NUM		--DI번호 " + " ) VALUES (	 "
					+ "  NVL(?,' ')    --인증관리구분 " + " , NVL(trim(?),'')    --인증관리번호 " + " , NVL(?,' ')    --등록자사번 "
					+ "  , NVL(?,' ')    --등록IP " + "  , trim(?)    --주민번호사업자(계좌) " + "  , trim(?)    --고객명 "
					+ "  , NVL(?,' ')    --은행코드 " + "  , trim(?)    --예금주명 " + "  , NVL(?,' ')    --인증일자 "
					+ "  , NVL(?,' ')    --CI번호 " + "  , NVL(?,' ')    --DI번호 " + ")";

			conn = dataSource.getConnection();
			conn.setAutoCommit(false);
			ps = conn.prepareStatement(sqlInsert);
			ps.setString(1, "40");
			ps.setString(2, jumin);
			ps.setString(3, null);
			ps.setString(4, null);
			ps.setString(5, null);
			ps.setString(6, custname);
			ps.setString(7, null);
			ps.setString(8, null);
			ps.setString(9, realNmCofYmd);
			ps.setString(10, "40");
			ps.setString(11, jumin);
			ps.setString(12, null);
			ps.setString(13, null);
			ps.setString(14, jumin);
			ps.setString(15, custname);
			ps.setString(16, null);
			ps.setString(17, null);
			ps.setString(18, realNmCofYmd);
			ps.setString(19, ci);
			ps.setString(20, null);

			ps.executeUpdate();

			conn.commit();

			if (rs != null)
				rs.close();
			if (ps != null)
				ps.close();
			if (conn != null)
				conn.close();

		} catch (Exception e) {
			e.printStackTrace(System.err);
		}
	}

	public String getCI(String cardNum, String useContNum) {
		String retVal = "";
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		try {
			conn = dataSource.getConnection();

			// 카드번호를 받지 않는다면 얻어온다.
			if (cardNum.equals("")) {
				String cardSql = "SELECT /*+ index_desc(c C1AX_0_TRANS_ACNT_REQ) */  " + "     D.USE_CONT_NUM "
						+ "   , B.DEFRAY_ACCOUNT_NUM " + " FROM C11.C1BT_USE_CONT_TRANS A "
						+ "   , C11.C1AT_TRANS_ACNT B " + "   , C11.C1AT_TRANS_ACNT_REQ C "
						+ "   , C11.C1BT_USE_CONT D " + " WHERE A.CUST_NUM = B.CUST_NUM "
						+ "  AND A.DEFRAY_ACCOUNT_NUM = B.DEFRAY_ACCOUNT_NUM  "
						// + " -- AND A.RECEIVE_STS_CD = '20' "
						+ "  AND B.TRAN_FLAG = '20' " + "  AND B.BNK_CD = '807'  "
						+ "  AND B.DEFRAY_ACCOUNT_NUM = C.DEFRAY_ACCOUNT_NUM  " + "  AND B.CUST_NUM = C.CUST_NUM "
						+ "  AND C.REQ_ITEM_CD IN('01', '02') " + "  AND A.REQ_INFO_NUM = D.REQ_INFO_NUM "
						+ "  AND D.USE_CONT_NUM = trim(?)  " + "  AND rownum = 1 ";
				ps = conn.prepareStatement(cardSql);
				ps.setString(1, useContNum);
				rs = ps.executeQuery();
				rs.next();

				cardNum = rs.getString("DEFRAY_ACCOUNT_NUM");

				ps.close();
				rs.close();
			}

			String socSql = "select A.soc_num, A.cust_nm, A.ci_num from C11.C1BT_CARD_RECEV_INF A where card_num = trim(?) ";
			ps = conn.prepareStatement(socSql);
			ps.setString(1, cardNum);
			rs = ps.executeQuery();
			rs.next();

			String socNum = "";
			String custNm = "";
			String ci = "";
			String cNum = "";

			if (rs.next()) {
				socNum = rs.getString("SOC_NUM");
				custNm = rs.getString("CUST_NM");
				ci = rs.getString("CI_NUM");
				cNum = "";
			} // C1BT_CARD_RECEV_INF 없다면
			else {
				String socSql2 = "SELECT B.SOC_BIZ_NUM, B.DEPOSITOR_NM	" + "   FROM C11.C1BT_USE_CONT_TRANS A  "
						+ "   , C11.C1AT_TRANS_ACNT B " + "   WHERE A.CUST_NUM = B.CUST_NUM "
						+ "   AND A.DEFRAY_ACCOUNT_NUM = B.DEFRAY_ACCOUNT_NUM  " + "   AND B.TRAN_FLAG = '20' "
						+ "   AND B.BNK_CD = '807'  " + "   AND A.DEFRAY_ACCOUNT_NUM = trim(?) "
						+ "   AND A.REQ_INFO_NUM = trim(?) " + "   AND rownum = 1 ";
				ps = conn.prepareStatement(socSql2);
				ps.setString(1, cardNum);
				ps.setString(2, useContNum);
				rs = ps.executeQuery();
				rs.next();

				socNum = rs.getString("SOC_BIZ_NUM");
				custNm = rs.getString("DEPOSITOR_NM");
				ci = "";
				cNum = "";
			}

			if (socNum.length() == 13) {
				if (socNum.substring(7, 13).equals("000000")) {
					retVal = ci;
				} else {

					String guBun = "40";
					String juMin = socNum;
					String name = custNm;
					String custnum = cNum;
					String realNmCofYmd = new SimpleDateFormat("yyyyMMdd").format(new Date());
					String bankCd = "", accountNo = "", rsltCd = "";

					java.net.Socket client;
					DataInputStream fromServer;
					DataOutputStream toServer;

					client = new java.net.Socket("10.20.1.9", 8655);
					client.setSoTimeout(40000);
					fromServer = new DataInputStream(new BufferedInputStream(client.getInputStream()));
					toServer = new DataOutputStream(new BufferedOutputStream(client.getOutputStream()));
					String send_msg = "";
					send_msg = send_msg + guBun + "|";
					send_msg = send_msg + juMin + "|";
					send_msg = send_msg + name + "|";
					send_msg = send_msg + bankCd + "|";
					send_msg = send_msg + accountNo;

					System.out.println("send_msg : [" + send_msg + "]");

					toServer.write(send_msg.getBytes("EUC-KR"));
					toServer.flush();
					byte readByte[] = new byte[200];
					int read_len = fromServer.read(readByte);
					rsltCd = new String(readByte, 0, 200).trim();

					client.close();

					System.out.println("recev_msg : (" + read_len + ")[" + rsltCd + "]");

					if (rsltCd.substring(0, 2).equals("10")) {
						// @formatter:off
						String sqlInsert = 
						  "INSERT INTO C11.C1AT_CERT_MST (CERT_MANAGE_FLAG, CERT_MANAGE_NUM, CRT_EMPID, CRT_IP, SOC_BIZ_NUM_BNK, CUST_NM, BNK_CD, DEPOSITOR_NM, CERT_YMD, CI_NUM, DI_NUM) "
						+ "  (SELECT ?, ?, nvl(?, ' '), ?, ?, ?, nvl(?, ' '), ?, nvl(?, ' '), ?, ? FROM DUAL  "
						+ " WHERE NOT EXISTS (SELECT CI_NUM FROM C11.C1AT_CERT_MST WHERE CERT_MANAGE_FLAG = '40' AND CERT_MANAGE_NUM = TRIM(?))) ";
						// @formatter:on

						ps = conn.prepareStatement(sqlInsert);
						ps.setString(1, "40");
						ps.setString(2, juMin);
						ps.setString(3, null);
						ps.setString(4, null);
						ps.setString(5, juMin);
						ps.setString(6, name);
						ps.setString(7, null);
						ps.setString(8, null);
						ps.setString(9, realNmCofYmd);
						ps.setString(10, rsltCd.substring(66, 154));
						ps.setString(11, rsltCd.substring(2, 66));
						ps.setString(12, juMin);

						ps.executeUpdate();

						// @formatter:off
						String sqlInsert2 = 
						"INSERT  "
						+ " INTO	C11.C1AT_REAL_NM_CERT( "
						+ "	REAL_NM_CONF_YMD    "
						+ ",	SEQ     "
						+ ",	CRT_EMPID  "
						+ ",	CRT_IP     "
						+ ",	CERT_REQ_FLAG  "
						+ ",	SOC_BIZ_NUM    "
						+ ",	CUST_NUM     "
						+ ",	CUST_NM     "
						+ ",	BNK_CD     "
						+ ",	ACCOUNT_NUM     "
						+ ",	DEPOSITOR_NM     "
						+ ",	SOC_BIZ_NUM_BNK   "
						+ ",	RSLT_CD    "
						+ ",	WHY_CD     "
						+ ",   FORM_ID   "
						+ ",   CI_NUM    "
						+ ",   DI_NUM    "
						+ ") VALUES (	 "
						+ "	    NVL(?,' ')    "
						+ ",	(SELECT LPAD(NVL(MAX(SEQ),0)+1,8,'0') FROM C11.C1AT_REAL_NM_CERT WHERE REAL_NM_CONF_YMD = NVL(?,' ')) "
						+ ",	NVL(?,' ')     "
						+ ",	?    "
						+ ",	NVL(?,' ')     "
						+ ",	trim(?)     "
						+ ",	NVL(?,' ')  "
						+ ",	trim(?)    "
						+ ",	NVL(?,' ')  "
						+ ",	trim(?)    "
						+ ",	trim(?)    "
						+ ",	trim(?)    "
						+ ",	NVL(?,' ')  "
						+ ",	NVL(?,' ')  "
						+ ",   NVL(?,' ')  "
						+ ",	NVL(?,' ')   "
						+ ",   NVL(?,' ')   "
						+ ") ";
						// @formatter:on

						ps = conn.prepareStatement(sqlInsert2);
						ps.setString(1, realNmCofYmd);
						ps.setString(2, realNmCofYmd);
						ps.setString(3, null);
						ps.setString(4, null);
						ps.setString(5, "40");
						ps.setString(6, juMin);
						ps.setString(7, custnum);
						ps.setString(8, name);
						ps.setString(9, null);
						ps.setString(10, null);
						ps.setString(11, null);
						ps.setString(12, juMin);
						ps.setString(13, "10");
						ps.setString(14, null);
						ps.setString(15, "C1301020022U");
						ps.setString(16, rsltCd.substring(66, 154));
						ps.setString(17, rsltCd.substring(2, 66));

						ps.executeUpdate();

						if (rs != null)
							rs.close();
						if (ps != null)
							ps.close();
						if (conn != null)
							conn.close();
					} else {

						// @formatter:off
						String sqlInsert2 = 
						"INSERT  "
						+ " INTO	C11.C1AT_REAL_NM_CERT( "
						+ "	REAL_NM_CONF_YMD    "
						+ ",	SEQ     "
						+ ",	CRT_EMPID   "
						+ ",	CRT_IP     "
						+ ",	CERT_REQ_FLAG   "
						+ ",	SOC_BIZ_NUM    "
						+ ",	CUST_NUM     "
						+ ",	CUST_NM    "
						+ ",	BNK_CD     "
						+ ",	ACCOUNT_NUM   "
						+ ",	DEPOSITOR_NM   "
						+ ",	SOC_BIZ_NUM_BNK   "
						+ ",	RSLT_CD     "
						+ ",	WHY_CD     "
						+ ",	FORM_ID   "
						+ ",	CI_NUM    "
						+ ",	DI_NUM    " + ") VALUES (	 "
						+ "		NVL(?,' ')    "
						+ ",	(SELECT LPAD(NVL(MAX(SEQ),0)+1,8,'0') FROM C11.C1AT_REAL_NM_CERT WHERE REAL_NM_CONF_YMD = NVL(?,' ')) "
						+ ",	NVL(?,' ')    "
						+ ",	?     "
						+ ",	NVL(?,' ')   "
						+ ",	trim(?)     "
						+ ",	NVL(?,' ')  "
						+ ",	trim(?)    "
						+ ",	NVL(?,' ')   "
						+ ",	trim(?)     "
						+ ",	trim(?)    "
						+ ",	trim(?)    "
						+ ",	NVL(?,' ')   "
						+ ",	NVL(?,' ')   "
						+ ",	NVL(?,' ')  "
						+ ",	NVL(?,' ')   "
						+ ",	NVL(?,' ')  "
						+ ")";
						// @formatter:on

						ps = conn.prepareStatement(sqlInsert2);
						ps.setString(1, realNmCofYmd);
						ps.setString(2, realNmCofYmd);
						ps.setString(3, null);
						ps.setString(4, null);
						ps.setString(5, "40");
						ps.setString(6, juMin);
						ps.setString(7, custnum);
						ps.setString(8, name);
						ps.setString(9, null);
						ps.setString(10, null);
						ps.setString(11, null);
						ps.setString(12, juMin);
						ps.setString(13, rsltCd.substring(0, 2));
						ps.setString(14, null);
						ps.setString(15, "C1301020022U");
						ps.setString(16, null);
						ps.setString(17, null);

						ps.executeUpdate();

						if (rs != null)
							rs.close();
						if (ps != null)
							ps.close();
						if (conn != null)
							conn.close();
					}

					retVal = rsltCd.substring(66, 154);
				}
			}
			if (rs != null)
				rs.close();
			if (ps != null)
				ps.close();
			if (conn != null)
				conn.close();
		} catch (Exception e) {
			e.printStackTrace(System.err);
		} finally {
			close(rs, ps, conn);
		}
		System.out.println("getCi ====> " + retVal);
		return retVal;
	}

	public void close(AutoCloseable... oa) {
		if (oa != null)
			for (AutoCloseable o : oa)
				if (o != null)
					try {
						o.close();
					} catch (Exception e) {
						log.error(e.getMessage(), e);
					}
	}
}
