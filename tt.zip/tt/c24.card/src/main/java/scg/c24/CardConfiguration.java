package scg.c24;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;

import scg.c24.config.CardConfig;
import scg.c24.config.CardConfigMap;
import scg.c24.job.CardJob;
import scg.c24.job.impl.CardJobCnl;
import scg.c24.job.kmc.KMCReqDoc;
import scg.c24.net.client.CardClient;
import scg.c24.net.client.CardClientService;
import scg.c24.net.client.CardClientServiceFactory;
import scg.c24.net.client.pool.CardClientPool;
import scg.c24.net.client.pool.CardClientPoolFactory;
import scg.c24.net.server.CardServer;
import scg.c24.net.server.CardServerFactory;
import scg.c24.util.CardCom;

@Configuration
@EnableScheduling
@MapperScan(basePackages = { "scg.c24.biz.db" }) // for mybatis
public class CardConfiguration {

	/* Config */

	@Autowired
	CardConfigMap cardConfigMap;

	@Bean
	@Primary
	@ConfigurationProperties(prefix = "card")
	public CardConfig cardConfig() {
		CardConfig c = new CardConfig();
		cardConfigMap.put(c.getUid(), c);
		return c;
	}

	@Bean
	@ConfigurationProperties(prefix = "card2")
	public CardConfig cardConfig2() {
		CardConfig c = new CardConfig();
		cardConfigMap.put(c.getUid(), c);
		return c;
	}

	/* Server */

	@Autowired
	private CardServerFactory cardServerFactory;

	@Bean(name = "{card.uid}", destroyMethod = "close")
	CardServer cardServer() throws Exception {
		return cardServerFactory.create(cardConfig());
	}

	@Bean
	CardServer cardServer2() throws Exception {
		CardConfig config2 = cardConfig2();
		return config2 == null || config2.getUid() == null ? null : cardServerFactory.create(config2);
	}

	/* Client */

	@Autowired
	private CardClientServiceFactory cardClientServiceFactory;

	@Bean
	CardClientService<? extends CardClient> CardClientService() throws Exception {
		return cardClientServiceFactory.create(cardConfig(), cardClientPool());
	}

	@Autowired
	private CardClientPoolFactory cardClientPoolFactory;

	@Bean(destroyMethod = "close")
	CardClientPool<? extends CardClient> cardClientPool() throws Exception {
		return cardClientPoolFactory.create(cardConfig());
	}

	@Bean(destroyMethod = "close")
	CardClientPool<? extends CardClient> cardClientPool2() throws Exception {
		CardConfig config2 = cardConfig2();
		return config2 == null || config2.getUid() == null ? null : cardClientPoolFactory.create(config2);
	}

	/* Schedule */

	@Async
	@Scheduled(cron = "0 */5 * * * ?")
	public void job1() {
		try {
			new Thread(new CardJobCnl()).start();
		} catch (Exception e) {
			Log log = LogFactory.getLog(CardJob.class);
			log.error(e.getMessage(), e);
		}
	}

	@Async
	@Scheduled(cron = "0 */5 * * * ?")
	public void job2() {
		CardConfig cardConfig = cardConfig();
		if (CardCom.KMC.equals(cardConfig.getUid()))
			try {
				new Thread(new KMCReqDoc()).start();
			} catch (Exception e) {
				Log log = LogFactory.getLog(CardJob.class);
				log.error(e.getMessage(), e);
			}
	}
}
