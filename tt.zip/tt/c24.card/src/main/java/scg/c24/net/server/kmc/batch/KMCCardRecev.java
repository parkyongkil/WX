package scg.c24.net.server.kmc.batch;

import java.io.File;
import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.sql.DataSource;

import scg.c24.ApplicationContextHolder;
import scg.c24.config.CardConfig;
import scg.c24.util.CardSysUtil;

public class KMCCardRecev {

	private static Connection conn = null;
	private static PreparedStatement ps = null;

	private String fileNm = "";

	private static final int MSG_LEN = 700; // 황정현 수정 600 -> 700

	private FileInputStream fis = null;
	private String recevPath = "./recvFile/";

	private DataSource dataSource = ApplicationContextHolder.getBean(DataSource.class);

	public KMCCardRecev(CardConfig cardConfig2, String fileNm) {
		this.fileNm = fileNm;
		this.recevPath = String.format("%s/%s/recvFile/", cardConfig2.getFilePath(), cardConfig2.getUid());
	}

	public void run() {
		try {
			fis = new FileInputStream(new File(recevPath, CardSysUtil.toKMCDatePath(fileNm)));
			byte[] readByte = new byte[MSG_LEN];
			fis.read(readByte, 0, MSG_LEN);
			String strYmd = new String(readByte, 8, 8);
			conn = dataSource.getConnection();
			conn.setAutoCommit(false);
			ps = conn.prepareStatement(sqlInsert);
			int count = 0;
			while (true) {
				int rslt = fis.read(readByte, 0, MSG_LEN);
				String strSeq = new String(readByte, 0, 8);
				if (rslt < 0) {
					break;
				}
				if (strSeq == null || strSeq.trim().equals("") || strSeq.equals("99999999")) {
					continue;
				}
				count++;
				/* 카드발급정보 배치 황정현 주석 추가 */
				String cardNum = new String(readByte, 8, 16); // 카드번호
				String issueYmd = new String(readByte, 24, 8); // 발급일자
				String expireYmd = new String(readByte, 32, 8); // 만료일자
				String cardOwnerFlag = new String(readByte, 40, 1); // 카드소유자구분
				String cardIssueFlag = new String(readByte, 41, 1); // 카드발급구분
				String oldCardNum = new String(readByte, 42, 16).trim(); // 구카드번호
				String ownerCardNum = new String(readByte, 58, 16).trim(); // 본인카드번호
				String socNum = new String(readByte, 74, 13).trim(); // 주민등록번호
				String custNm = new String(readByte, 87, 30, "euc-kr").trim(); // 고객명
				String cpDdd = new String(readByte, 117, 4).trim(); // 휴대전화번호1
				String cpExn = new String(readByte, 121, 4).trim(); // 휴대전화번호2
				String cpNum = new String(readByte, 125, 4).trim(); // 휴대전화번호3
				String ownhouseTelDdd = new String(readByte, 129, 4).trim(); // 자택전화번호1
				String ownhouseTelExn = new String(readByte, 133, 4).trim(); // 자택전화번호2
				String ownhouseTelNum = new String(readByte, 137, 4).trim(); // 자택전화번호3
				String zipNo = new String(readByte, 141, 6); // 자택우편번호
				String zipAddr = new String(readByte, 147, 150, "euc-kr").trim(); // 자택우편주소
				String etcAddr = new String(readByte, 297, 150, "euc-kr").trim(); // 자택상세주소
				String reqEmpid = new String(readByte, 447, 16).trim(); // 모집사원번호
				String autoTransYn = new String(readByte, 463, 1); // 자동납부여부
				String useContNum = new String(readByte, 464, 20).trim(); // 사용계약번호 10 -> 20 수정
				String roleCode = new String(readByte, 484, 3).trim(); // 역할유형코드 추가
				String ci = new String(readByte, 487, 88).trim(); // CI 추가
				String filler = new String(readByte, 575, 125).trim(); // FILLER 추가

				System.out.println("readByte=====>" + readByte);
				System.out.println("cardNum=====>" + cardNum);
				System.out.println("issueYmd=====>" + issueYmd);
				System.out.println("expireYmd=====>" + expireYmd);
				System.out.println("cardOwnerFlag=====>" + cardOwnerFlag);
				System.out.println("cardIssueFlag=====>" + cardIssueFlag);
				System.out.println("oldCardNum=====>" + oldCardNum);
				System.out.println("ownerCardNum=====>" + ownerCardNum);
				System.out.println("socNum=====>" + socNum);
				System.out.println("custNm=====>" + custNm);
				System.out.println("cpDdd=====>" + cpDdd);
				System.out.println("cpExn=====>" + cpExn);
				System.out.println("cpNum=====>" + cpNum);
				System.out.println("ownhouseTelDdd=====>" + ownhouseTelDdd);
				System.out.println("ownhouseTelExn=====>" + ownhouseTelExn);
				System.out.println("ownhouseTelNum=====>" + ownhouseTelNum);
				System.out.println("zipNo=====>" + zipNo);
				System.out.println("zipAddr=====>" + zipAddr);
				System.out.println("etcAddr=====>" + etcAddr);
				System.out.println("reqEmpid=====>" + reqEmpid);
				System.out.println("autoTransYn=====>" + autoTransYn);
				System.out.println("useContNum=====>" + useContNum);
				System.out.println("roleCode=====>" + roleCode);
				System.out.println("ci=====>" + ci);
				System.out.println("filler=====>" + filler);

				ps.setString(1, strYmd);
				ps.setInt(2, count);
				ps.setString(3, cardNum);
				ps.setString(4, issueYmd);
				ps.setString(5, expireYmd);
				ps.setString(6, cardOwnerFlag);
				ps.setString(7, cardIssueFlag);
				ps.setString(8, oldCardNum);
				ps.setString(9, ownerCardNum);
				ps.setString(10, socNum);
				ps.setString(11, custNm);
				ps.setString(12, cpDdd);
				ps.setString(13, cpExn);
				ps.setString(14, cpNum);
				ps.setString(15, ownhouseTelDdd);
				ps.setString(16, ownhouseTelExn);
				ps.setString(17, ownhouseTelNum);
				ps.setString(18, zipNo);
				ps.setString(19, zipAddr);
				ps.setString(20, etcAddr);
				ps.setString(21, reqEmpid);
				ps.setString(22, autoTransYn);
				ps.setString(23, useContNum);

				ps.setString(24, roleCode); // 역할유형코드 추가
				ps.setString(25, ci); // CI 추가
				// ps.setString(26, filler); // FILLER 추가

				ps.executeUpdate();

			}

			ps = conn.prepareStatement(sqlUpdate1);
			int cntTm = ps.executeUpdate();

			ps = conn.prepareStatement(sqlUpdate2);
			int cntReq = ps.executeUpdate();

			ps = conn.prepareStatement(sqlUpdate3);
			int cntHp = ps.executeUpdate();

			System.out.println("TM CNT : " + Integer.toString(cntTm) + ", REQ CNT : " + Integer.toString(cntReq)
					+ ", HP CNT : " + Integer.toString(cntHp));

			int maxCount = Integer.parseInt(new String(readByte, 8, 8));

			if (count != maxCount) {

			}

			conn.commit();

		} catch (Exception e) {
			e.printStackTrace();
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		} finally {
			if (ps != null)
				try {
					ps.close();
				} catch (Exception e) {
				}
			if (conn != null)
				try {
					conn.close();
				} catch (Exception e) {
				}
			if (fis != null)
				try {
					fis.close();
				} catch (Exception e) {
				}
		}

	}

	// @formatter:off
	private final static String sqlInsert = 
			"INSERT INTO "
			+ "       C11.C1BT_CARD_RECEV_INF ( "
			+ "       RECEV_YMD "
			+ "     , SEQ "
			+ "     , CRT_DTM "
			+ "     , CRT_EMPID "
			+ "     , CRT_IP "
			+ "     , CARD_NUM "
			+ "     , ISSUE_YMD "
			+ "     , EXPIRE_YMD "
			+ "     , CARD_OWNER_FLAG "
			+ "     , CARD_ISSUE_FLAG "
			+ "     , OLD_CARD_NUM "
			+ "     , OWNER_CARD_NUM "
			+ "     , SOC_NUM "
			+ "     , CUST_NM "
			+ "     , CP_DDD "
			+ "     , CP_EXN "
			+ "     , CP_NUM "
			+ "     , OWNHOUSE_TEL_DDD "
			+ "     , OWNHOUSE_TEL_EXN "
			+ "     , OWNHOUSE_TEL_NUM "
			+ "     , ZIP_NO "
			+ "     , ZIP_ADDR "
			+ "     , ETC_ADDR "
			+ "     , REQ_MSG "
			+ "     , AUTO_TRANS_YN "
			+ "     , USE_CONT_NUM "
			+ "     , ROLE_TYPE "
			+ "     , CI_NUM "
			+ "     ) "
			+ "VALUES ( "
			+ "       ? "
			+ "     , ? "
			+ "     , sysdate "
			+ "     , 'SYSTEM' "
			+ "     , '**.**.**.**' "
			+ "     , ? "
			+ "     , ? "
			+ "     , ? "
			+ "     , ? "
			+ "     , ? "
			+ "     , ? "
			+ "     , ? "
			+ "     , ? "
			+ "     , ? "
			+ "     , ? "
			+ "     , ? "
			+ "     , ? "
			+ "     , ? "
			+ "     , ? "
			+ "     , ? "
			+ "     , ? "
			+ "     , ? "
			+ "     , ? "
			+ "     , ? "
			+ "     , ? "
			+ "     , ? "
			+ "     , ? "
			+ "     , ? "
			+ "    ) ";


	private final static String sqlUpdate1 = 
			" MERGE INTO C11.C1BT_CARD_RECEV_INF A "
			+ " USING                            "
			+ "     (SELECT * FROM C11.C1BT_CARD_REQ_DOC) B "
			+ " ON               "
			+ "     (    A.SOC_NUM = B.SOC_NUM "
			+ "       AND LENGTH(TRIM(A.REQ_MSG)) = 7 "
			+ "       AND TRIM(A.REQ_MSG) like 'MA0%'   "
			+ "       ) "
			+ " WHEN MATCHED THEN  "
			+ "   UPDATE SET  "
			+ "        A.RECEIVE_CENTER_CD = B.REQ_COM_ID  "
			+ "	  , A.REQ_TYPE_CD = B.REQ_TYPE_CD  "
			+ "	  , A.REQ_EMPID = B.REQ_EMPID  "
			+ "	  , A.REQ_JOB_YMD = B.JOB_YMD  "
			+ "	  , A.REQ_SEQ = B.SEQ  "
			+ "	  , A.REQ_DOC_FLAG = B.REQ_DOC_FLAG "
			+ "  WHERE A.REQ_EMPID IS NULL ";

	private final static String sqlUpdate2 = 
			" UPDATE C11.C1BT_CARD_RECEV_INF "
			+ "SET RECEIVE_CENTER_CD = SUBSTR(REQ_MSG, 10, 2) "
			+ "  , REQ_EMPID = SUBSTR(REQ_MSG, 1, 9) "
			+ "  , REQ_TYPE_CD = SUBSTR(REQ_MSG, 12, 1) "
			+ "  , REQ_DOC_FLAG = '10' "
			+ "  WHERE REQ_MSG IS NOT NULL "
			+ "    AND LENGTH(TRIM(REQ_MSG)) = 12 "
			+ "    AND REQ_EMPID IS NULL";

	private final static String sqlUpdate3 = 
			"UPDATE C11.C1BT_CARD_RECEV_INF "
			+ "   SET RECEIVE_CENTER_CD = decode(trim(REQ_MSG), '2098000', '10', '2099000', '92') "
			+ "     , REQ_EMPID = decode(trim(REQ_MSG), '2098000', 'scgcust01', '2099000', 'scgkib001') "
			+ "     , REQ_TYPE_CD = decode(trim(REQ_MSG), '2098000', 'A', '2099000', 'A') "
			+ "     , REQ_DOC_FLAG = decode(trim(REQ_MSG), '2098000', '10', '2099000', '10') "
			+ " WHERE trim(REQ_MSG) IN('2098000', '2099000') "
			+ "   AND REQ_EMPID IS NULL ";
	// @formatter:on
}
