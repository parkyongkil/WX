package scg.c24.data.shc;

import lombok.Data;
import scg.c24.data.CardData;
import tt.io.annotation.AtLPad;
import tt.io.annotation.AtSize;
import tt.io.annotation.AtUnuse;

@Data
public class SHCData implements CardData {

	public static final int HL = 70;

	/** 전문송수신에서 자동삭제됨 */
	@AtUnuse(print = true)
	public String err;

	/** 트랜잭션번호(9) (고정된 ID값, 예:DSESHC001) */
	@AtSize(9)
	public String a01;

	/** 전문총길이(5) - 입력하지 않음 (바이너리로 전환하여 전송할 때 자동 입력처리함) */
	@AtLPad(value = 5, pad = '0')
	public int a02;

	/** 개시전문(3) 카드사ID(KMC=국민카드, SHC=신한카드, SSC=삼성카드) */
	@AtSize(3)
	public String a03;

	/** 전문번호(4) (9050=카드인증조회, 9150=카드자동납부신청) */
	@AtSize(4)
	public String a04;

	/** 거래번호(22) = XX(2) + yyyyMMddHHmmss(14) + nono초(6) */
	@AtSize(22)
	public String a05;

	/** 전문전송일시(14) yyyyMMddHHmmss */
	@AtSize(14)
	public String a06;

	/** 개별부 길이(4) - 입력하지 않음 (바이너리로 전환하여 전송할 때 자동 입력처리함) */
	@AtLPad(value = 4, pad = '0')
	public int a07;

	/** 응답코드 00=요청할때,정상응답, (83,85,..)=오류 */
	@AtSize(2)
	public String a08;

	/** 카드회원사번호(N3) 110=SHC(신한카드), 120=SSC(삼성카드), KMC(국민은행) 없음 */
	@AtSize(3)
	public String a09;

	/** 거래처제휴코드(N3) 001=SHC, 002=SSC, KMC(국민은행)은 없음 */
	@AtSize(3)
	public String a10;

	/** 필러 */
	@AtSize(1)
	public String a11;

	/** a02(전체전문길이)값을 입력하면 a07(전문개별부길이)값을 자동계산(개별부 = 전체 - 70)입력함 */
	public void setA02(int a02) {
		this.a02 = a02;
		this.a07 = a02 - HL;
	}

	@Override
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}
}
