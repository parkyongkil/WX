package scg.c24.data.kmc.batch;

import lombok.Data;
import lombok.EqualsAndHashCode;
import tt.io.annotation.AtLPad;
import tt.io.annotation.AtSize;

/** FILE SEND */
@Data
@EqualsAndHashCode(callSuper = true)
public class KMCBAT0102 extends KMCBAT0100 {

	@AtSize(10)
	public String fileInfNm;

	@AtLPad(12)
	public long fileInfSize;

	@AtLPad(4)
	public int fileInfByte;
}
