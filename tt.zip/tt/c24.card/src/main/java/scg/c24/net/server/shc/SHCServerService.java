package scg.c24.net.server.shc;

import java.util.ArrayList;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import scg.c24.ApplicationContextHolder;
import scg.c24.config.CardConfig;
import scg.c24.data.shc.SHC8050;
import scg.c24.data.shc.SHC8050Process;
import scg.c24.data.shc.SHC8150;
import scg.c24.data.shc.SHC8150Process;
import scg.c24.data.shc.SHCData;
import scg.c24.mis.data.MIS1000q;
import scg.c24.mis.data.MIS1000r;
import scg.c24.mis.data.MIS2000q;
import scg.c24.mis.data.MIS2000r;
import scg.c24.net.client.shc.SHCClientService;
import scg.c24.net.server.CardServerService;
import scg.c24.util.CardCom;
import tt.lang.string.StringU;

@Service
public class SHCServerService extends CardServerService {

	private SHC8050Process p8050 = ApplicationContextHolder.getBean(SHC8050Process.class);
	private SHC8150Process p8150 = ApplicationContextHolder.getBean(SHC8150Process.class);

	public SHCServerService(CardConfig cardConfig) {
		super(cardConfig);
	}

	@SuppressWarnings("unchecked")
	@Override
	public <Q, R> R call(Q q) throws Exception {

		if (q instanceof SHC8050)
			return (R) call8050((SHC8050) q);
		if (q instanceof SHC8150)
			return (R) call8150((SHC8150) q);

		throw new Exception(String.format("서버에서 처리할 수 없는 전문(%s)입니다.", q == null ? null : q.getClass()));
	}

	@SuppressWarnings("unchecked")
	@Override
	public <Q, R> R callMIS(Q q) throws Exception {
		if (q instanceof MIS1000q)
			return (R) mis1000((MIS1000q) q);
		if (q instanceof MIS2000q)
			return (R) mis2000((MIS2000q) q);
		throw new Exception(String.format("지원하지 않는 구조체(%s)입니다.", q == null ? "X" : q.getClass().getCanonicalName()));
	}

	public SHC8050 call8050(SHC8050 q) throws Exception {
		if (log.isInfoEnabled())
			log.info(
					String.format("\nSQ(%s): %s", q == null ? "X" : q.getClass().getSimpleName(), StringU.toString(q)));

		SHC8050 r = p8050.process(q);

		if (log.isInfoEnabled())
			log.info(
					String.format("\nSR(%s): %s", r == null ? "X" : r.getClass().getSimpleName(), StringU.toString(r)));
		return r;
	}

	public SHC8150 call8150(SHC8150 q) throws Exception {
		if (log.isInfoEnabled())
			log.info(
					String.format("\nSQ(%s): %s", q == null ? "X" : q.getClass().getSimpleName(), StringU.toString(q)));

		SHC8150 r = p8150.process(q);

		if (log.isInfoEnabled())
			log.info(
					String.format("\nSR(%s): %s", r == null ? "X" : r.getClass().getSimpleName(), StringU.toString(r)));
		return r;
	}

	@Override
	public MIS1000r mis1000(MIS1000q mq) throws Exception {

		if (log.isInfoEnabled())
			log.info(String.format("\nMQ(%s): %s", mq == null ? "X" : mq.getClass().getSimpleName(),
					StringU.toString(mq)));

		CardCom c = CardCom.getByBnkCd(mq.CARD_CD);
		SHC8050 q = new SHC8050();
		SHCClientService.setRequestHeader(q, c, "8050");
		q.b01 = mq.CUST_NM;
		q.b02 = mq.CUST_CP_DDD;
		q.b03 = mq.CUST_CP_EXN;
		q.b04 = mq.CUST_CP_NUM;
		q.b05 = mq.USE_CONT_NUM;

		SHC8050 r = call8050(q);

		MIS1000r mr = new MIS1000r();
		mr.RSLT_CD = r.a08;
		mr.USE_CONTS = new ArrayList<>();
		for (SHC8050.Cont a : r.b07) {
			MIS1000r.Cont b = new MIS1000r.Cont();
			b.USE_CONT_NUM = a.c01;
			b.ADDR = a.c02;
			mr.USE_CONTS.add(b);
		}

		if (log.isInfoEnabled())
			log.info(String.format("\nMR(%s): %s", mr == null ? "X" : mr.getClass().getSimpleName(),
					StringU.toString(mr)));

		return mr;
	}

	@Override
	public MIS2000r mis2000(MIS2000q mq) throws Exception {

		if (log.isInfoEnabled())
			log.info(String.format("\nMQ(%s): %s", mq == null ? "X" : mq.getClass().getSimpleName(),
					StringU.toString(mq)));

		CardCom c = CardCom.getByBnkCd(mq.CARD_CD);
		SHC8150 q = new SHC8150();
		SHCClientService.setRequestHeader(q, c, "8150");

		q.b01 = mq.TREAT_FLAG;
		q.b02 = mq.DEFRAY_ACCOUNT_NUM;
		q.b04 = mq.CUST_NM;
		q.b05 = mq.SOC_BIZ_NUM;
		q.b06 = mq.REQ_TEL_DDD;
		q.b07 = mq.REQ_TEL_EXN;
		q.b08 = mq.REQ_TEL_NUM;
		q.b09 = mq.REQ_YMD;
		q.b10 = mq.CUST_RELAT_CD;
		q.b11 = mq.REQ_NM;
		q.b12 = mq.USE_CONT_NUM;
		q.b13 = "00";
		q.b14 = mq.ORIG_APPLY_YM;
		q.b15 = mq.VALID_YM;

		SHC8150 r = call8150(q);

		MIS2000r mr = new MIS2000r();
		mr.RSLT_CD = r.a08;
		mr.VALID_YM = StringUtils.right(r.b15, 4);
		mr.CARD_STS_CD = r.b13;

		if (log.isInfoEnabled())
			log.info(String.format("\nMR(%s): %s", mr == null ? "X" : mr.getClass().getSimpleName(),
					StringU.toString(mr)));

		return mr;
	}

	public static void setResponseHeader(SHCData q, SHCData r) {
		BeanUtils.copyProperties(q, r); // 전체복사
		r.a01 = q.a01.replaceAll("^...", "DSE"); // 첫3글자(SOG)를 (DSE)로 변경
		// a02 전문 전체길이는 네트워크 전송할 때 전송프로그램이 자동 계산하여 입력하므로, 입력할 필요 없음
		r.a03 = q.a03;
		r.a04 = q.a04.replaceAll("0$", "1"); // 마지막글자를 (1)로 변경, 8050 -> 8051
		r.a05 = q.a05;
		r.a06 = DateFormatUtils.format(new Date(), "yyyyMMddHHmmss");
		// a07 전문 개별부길이는 네트워크 전송할 때 전송프로그램이 자동 계산하여 입력하므로, 입력할 필요 없음
		r.a08 = "00";
		r.a09 = q.a09;
		r.a10 = q.a10;
		// a11 필러
	}
}
