package scg.c24.biz.db.kmc.model;

import lombok.Data;

@Data
public class KMCUseContCheck {

	String CHK_1;

	String CHK_2;

	String CHK_3;

	String CHK_4;

	String PAY_METHOD_CD;
}