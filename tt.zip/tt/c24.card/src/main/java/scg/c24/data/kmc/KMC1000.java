package scg.c24.data.kmc;

import lombok.Data;
import lombok.EqualsAndHashCode;
import tt.io.annotation.AtLPad;
import tt.io.annotation.AtSize;

/**
 * @제목 사용계약번호조회 요청,응답 (1000, 8050)
 * 
 * @요청 국민카드
 * @응답 서울도시가스
 */

@Data
@EqualsAndHashCode(callSuper = true)
public class KMC1000 extends KMCData {

	/** 사용계약번호(20) */
	@AtSize(20)
	public String b01;

	/** 계약상태코드(2) 00=없음, 10=정상, 30=해지 */
	@AtSize(2)
	public String b02;

	/** 납부방법코드(2) 10=지로, 20=은행, 30=카드 */
	@AtSize(2)
	public String b03;

	/** 자동이체기관명(100) */
	@AtSize(100)
	public String b04;

	/** 최초출금일(8) yyyyMMdd */
	@AtSize(8)
	public String b05;

	/** 계약고객명(30) */
	@AtSize(30)
	public String b06;

	/** 계약우편번호(6) */
	@AtSize(6)
	public String b07;

	/** 계약우편주소(150) */
	@AtSize(150)
	public String b08;

	/** 계약상세주소(150) */
	@AtSize(150)
	public String b09;

	/** 계약전화번호1(3) */
	@AtLPad(3)
	public String b10;

	/** 계약전화번호1(4) */
	@AtLPad(4)
	public String b11;

	/** 계약전화번호1(4) */
	@AtLPad(4)
	public String b12;

	/** 필러(21) */
	@AtSize(21)
	public String b13;
}
