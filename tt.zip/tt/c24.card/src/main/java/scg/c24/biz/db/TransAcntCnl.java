package scg.c24.biz.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import scg.c24.ApplicationContextHolder;
import scg.c24.data.kmc.KMC3000;
import scg.c24.net.client.CardClientService;
import scg.c24.net.client.CardClientServiceMap;
import scg.c24.net.client.kmc.KMCClientService;
import scg.c24.util.CardCom;
import tt.lang.string.StringU;

public class TransAcntCnl {
	private String reqInfoNum;
	private String cnlWhyCd;
	private String cnlCustNm;
	private String cnlCustSocNum;
	private String cnlCustRelatCd;
	private String cnlTelDdd;
	private String cnlTelExn;
	private String cnlTelNum;
	private String cnlGubn;
	private String ebppCnlYn;
	private String receiveSecCd;
	private String webId;
	// private String ci;

	private String custNum;
	private String accountNum;
	private String bnkCd;
	// private String reqYmd;
	private String tranFlag;
	private String nxtReqInfoNum;
	private String payMethod;
	private boolean isReqIng;

	private CardCom cardCom;

	private DataSource dataSource = ApplicationContextHolder.getBean(DataSource.class);

	private Connection conn = null;
	private PreparedStatement ps = null;
	private ResultSet rs = null;

	private Log log = LogFactory.getLog(getClass());

	public TransAcntCnl(String reqInfoNum, String cnlWhyCd, String cnlCustNm, String cnlCustSocNum,
			String cnlCustRelatCd, String cnlTelDdd, String cnlTelExn, String cnlTelNum, String cnlGubn,
			String ebppCnlYn, String receiveSecCd // 5홈페이지 6카드사
			, String webId, boolean isReqIng, Connection conn, String ci) {
		this.reqInfoNum = reqInfoNum;
		this.cnlWhyCd = cnlWhyCd;
		this.cnlCustNm = cnlCustNm;
		this.cnlCustSocNum = cnlCustSocNum;
		this.cnlCustRelatCd = cnlCustRelatCd;
		this.cnlTelDdd = cnlTelDdd;
		this.cnlTelExn = cnlTelExn;
		this.cnlTelNum = cnlTelNum;
		this.cnlGubn = cnlGubn;
		this.ebppCnlYn = ebppCnlYn;
		this.receiveSecCd = receiveSecCd;
		this.webId = webId;
		this.isReqIng = isReqIng;
		if (isReqIng) {
			this.conn = conn;
		}
		// this.ci = ci;
		this.cardCom = CardCom.getByBnkCd(bnkCd);
	}

	public int start() {
		int chk, rValue = 0;

		//
		chk = validate();
		if (chk != 0) {
			return chk;
		}

		try {
			if (!isReqIng) {
				conn = dataSource.getConnection();
				conn.setAutoCommit(false);

				// TO DO 납부자통합이면 해지 불가 2016-02-18
				chk = chkPayTot();
				if (chk != 0) {
					throw new Exception("납부자통합 고객 해지불가");
				}
			}
			//
			chk = chkUseCont();
			if (chk != 0) {
				throw new Exception("사용계약 상태 오류");
			}

			if (cnlGubn.equals("1")) // 단건 해지
			{
				chk = cnlUseCont(reqInfoNum);
				if (chk != 0)
					throw new Exception("사용계약해지오류 : " + reqInfoNum);
			} else {
				ps = conn.prepareStatement(sqlSelectCont);
				ps.setString(1, reqInfoNum);

				rs = ps.executeQuery();
				while (rs.next()) {
					custNum = rs.getString("CUST_NUM");
					accountNum = rs.getString("DEFRAY_ACCOUNT_NUM");
					// reqYmd = rs.getString("REQ_YMD");
					nxtReqInfoNum = rs.getString("REQ_INFO_NUM");
					bnkCd = rs.getString("BNK_CD");
					tranFlag = rs.getString("TRAN_FLAG");
					chk = cnlUseCont(nxtReqInfoNum);
					if (chk != 0)
						throw new Exception("사용계약해지오류 : " + nxtReqInfoNum);
				}

				chk = cnlAcnt();
				if (chk != 0)
					throw new Exception("계좌해지오류 : " + accountNum);

			}
			if (receiveSecCd.equals("5")) { // 홈페이지 -> 추가인서트
				chk = insertScsTrans();
				if (chk != 0)
					throw new Exception("홈페이지입력오류");
				if (!isReqIng && payMethod != null && payMethod.equals("30")) {
					if (CardCom.KMC.equals(cardCom.getCid()))
						chk = sendKB();
				}
			}

		} catch (Exception e) {
			System.out.println("TransAcntCnl.start() : catch! " + e.toString());
			rValue = chk;
		} finally {
			try {
				if (ps != null)
					ps.close();
				if (rs != null)
					rs.close();

				if (!isReqIng) {
					if (conn != null) {
						if (rValue == 0)
							conn.commit();
						else
							conn.rollback();
					}

					if (conn != null)
						conn.close();
				}
			} catch (Exception e) {

			}
		}

		return rValue;
	}

	// @formatter:off
	private final static String sqlSelectCont =
	"SELECT DEFRAY_ACCOUNT_NUM " +
	"     , CUST_NUM " +
	"     , REQ_INFO_NUM " +
	"     , REQ_YMD " +
	"     , BNK_CD " +
	"     , (SELECT TRAN_FLAG " +
	"          FROM C11.C1AT_TRANS_ACNT X " +
	"         WHERE X.DEFRAY_ACCOUNT_NUM = A.DEFRAY_ACCOUNT_NUM " +
	"           AND X.CUST_NUM = A.CUST_NUM) TRAN_FLAG " +
	"  FROM C11.C1BT_USE_CONT_TRANS A " +
	" WHERE CUST_NUM = (SELECT CUST_NUM " +
	"                     FROM C11.C1BT_USE_CONT " +
	"                    WHERE USE_CONT_NUM = ?) " +
	"   AND RECEIVE_STS_CD IN ('10', '20') " +
	"   AND CNL_YMD = '99991231' ";
	// @formatter:on	

	/* validate() - */
	private int validate() {
		if (reqInfoNum == null || reqInfoNum.length() != 10) {
			System.out.println("!reqInfoNum error : " + reqInfoNum);
			return 98;
		}

		return 0;
	}

	private int chkUseCont() {
		int rValue = 0;
		/* check! 0. 사용계약존재여부 체크 1. 납부방법 체크 */
		try {
			if (cnlWhyCd.equals("10")) { // 해지요청
				ps = conn.prepareStatement(sqlchk_10);
				ps.setString(1, reqInfoNum);
				ps.setString(2, reqInfoNum);
				ps.setString(3, bnkCd);
				ps.setString(4, reqInfoNum);
			} else { // 신규등록에 따른 해지
				ps = conn.prepareStatement(sqlchk_40);
				ps.setString(1, reqInfoNum);
				ps.setString(2, reqInfoNum);
				ps.setString(3, reqInfoNum);
			}
			rs = ps.executeQuery();

			if (rs.next()) {

				if (rs.getString("CHK_0").equals("0")) {
					System.out.println("!사용계약 미존재 오류");
					rValue = 10;
				} else if (rs.getString("CHK_1").equals("0")) {
					System.out.println("!납부방법 오류)");
					rValue = 50;
				}
				payMethod = rs.getString("PAY_METHOD_CD");
			} else {
				rValue = 99;
			}
		} catch (Exception e) {
			System.out.println("TransAcntCnl.chkUseCont() : " + e.toString());
			rValue = 99;
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (ps != null) {
					ps.close();
				}
			} catch (Exception e) {

			}
		}
		return rValue;
	}

	// @formatter:off
	private final static String sqlchk_10 = 
	"SELECT NVL((SELECT '1' " +
	"              FROM C11.C1BT_USE_CONT " +
	"             WHERE USE_CONT_NUM = ?), '0') CHK_0 " +
	"     , NVL((SELECT MAX('1') " +
	"              FROM C11.C1BT_USE_CONT_TRANS " +
	"             WHERE REQ_INFO_NUM = ? " +
	"               AND BNK_CD = ?" +
	"               AND RECEIVE_STS_CD IN('10', '20')), '0') CHK_1 " +
	"     , (SELECT PAY_METHOD_CD FROM C11.C1BT_REQ_INFO WHERE REQ_INFO_NUM = ?) PAY_METHOD_CD " +
	"  FROM DUAL ";
		
	private final static String sqlchk_40 = 
	"SELECT NVL((SELECT '1' " +
	"              FROM C11.C1BT_USE_CONT " +
	"             WHERE USE_CONT_NUM = ?), '0') CHK_0 " +
	"     , NVL((SELECT MAX('1') " +
	"              FROM C11.C1BT_USE_CONT_TRANS " +
	"             WHERE REQ_INFO_NUM = ? " +
	"               AND RECEIVE_STS_CD IN('10', '20')), '0') CHK_1 " +
	"     , (SELECT PAY_METHOD_CD FROM C11.C1BT_REQ_INFO WHERE REQ_INFO_NUM = ?) PAY_METHOD_CD " +
	"  FROM DUAL ";
	// @formatter:on

	private int cnlUseCont(String reqInfoNum) {
		int rValue = 0;
		try {
			ps = conn.prepareStatement(sqlUpdateReqInfo);
			if (ebppCnlYn != null && ebppCnlYn.equals("Y")) {
				ps.setString(1, cardCom.getName());
				ps.setString(2, "10");
				ps.setString(3, "N");
				ps.setString(4, reqInfoNum);
			} else {
				ps.setString(1, cardCom.getName());
				ps.setString(2, null);
				ps.setString(3, null);
				ps.setString(4, reqInfoNum);
			}
			ps.executeUpdate();

			if (ebppCnlYn != null && ebppCnlYn.equals("Y")) {
				ps = conn.prepareStatement(sqlMergeEbpp);
				ps.setString(1, reqInfoNum);
				ps.setString(2, cardCom.getName());
				ps.setString(3, "20");
				ps.setString(4, reqInfoNum);
				ps.setString(5, "20");
				ps.setString(6, cardCom.getName());

				ps.executeUpdate();
			}

			ps = conn.prepareStatement(sqlUpdateUseContTrans);
			ps.setString(1, cardCom.getName());
			ps.setString(2, receiveSecCd);
			ps.setString(3, cnlWhyCd);
			ps.setString(4, cnlCustNm);
			ps.setString(5, cnlCustSocNum);
			ps.setString(6, cnlCustRelatCd);
			ps.setString(7, cnlTelDdd);
			ps.setString(8, cnlTelExn);
			ps.setString(9, cnlTelNum);
			ps.setString(10, reqInfoNum);

			ps.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("TransAcntCnl.cnlUseCont() : " + e.toString());
			rValue = 99;
		} finally {
			try {
				if (ps != null) {
					ps.close();
				}
			} catch (Exception e) {

			}
		}
		return rValue;
	}

	// @formatter:off
	private final static String sqlUpdateReqInfo =
	"UPDATE C11.C1BT_REQ_INFO " +
	"   SET UPD_DTM = SYSDATE " +
	"     , UPD_EMPID = ? " +
	"     , UPD_IP = '**.**.**.**' " +
	"     , PAY_METHOD_CD = '10' " +
	"     , BILL_SEND_METHOD_CD = NVL(?, BILL_SEND_METHOD_CD) " +
	"     , EMAIL_SEND_YN = NVL(?, EMAIL_SEND_YN) " +
	" WHERE REQ_INFO_NUM = ? ";

	private final static String sqlMergeEbpp =
	"MERGE INTO C21.C2DT_EBPP_AUTO_CNL A " +
	"    USING DUAL " +
	"    ON (    A.USE_CONT_NUM = ? " +
	"        AND TRIM(A.JOB_ID) = TO_CHAR(SYSDATE, 'YYYYMMDD') " +
	"        AND A.REQ_YMD = TO_CHAR(SYSDATE, 'YYYYMMDD') " +
	"        AND A.REQ_FLAG = '2') " +
	"    WHEN MATCHED THEN " +
	"        UPDATE " +
	"           SET A.UPD_DTM = SYSDATE " +
	"             , A.UPD_EMPID = ? " +
	"             , A.UPD_IP = '**.**.**.**' " +
	"             , A.RECEIVE_FLAG = ? " +
	"    WHEN NOT MATCHED THEN " +
	"        INSERT(A.JOB_ID, A.REQ_YMD, A.USE_CONT_NUM, A.REQ_FLAG, A.CREATE_YMD, A.CRT_TIME, A.RECEIVE_FLAG, A.CRT_IP, A.CRT_EMPID) " +
	"        VALUES(TO_CHAR(SYSDATE, 'YYYYMMDD') " +
	"             , TO_CHAR(SYSDATE, 'YYYYMMDD') " +
	"             , ? " +
	"             , '2' " +
	"             , TO_CHAR(SYSDATE, 'YYYYMMDD') " +
	"             , TO_CHAR(SYSDATE, 'HH24MISS') " +
	"             , ? " +
	"             , ? " +
	"             , '**.**.**.**') ";

	private final static String sqlUpdateUseContTrans =
	"UPDATE C11.C1BT_USE_CONT_TRANS " +
	"   SET UPD_DTM = SYSDATE " +
	"     , UPD_EMPID = ? " +
	"     , UPD_IP = '**.**.**.**' " +
	"     , RECEIVE_STS_CD = '30' " +
	"     , RECEIVE_SEC_CD = ? " +
	"     , CNL_APPLY_YM = TO_CHAR(SYSDATE, 'YYYYMM') " +
	"     , CNL_YMD = TO_CHAR(SYSDATE, 'YYYYMMDD') " +
	"     , CNL_WHY_CD = NVL(?, CNL_WHY_CD) " +
	"     , CNL_CUST_NM = NVL(?, CNL_CUST_NM) " +
	"     , CNL_CUST_SOC_NUM = NVL(?, CNL_CUST_SOC_NUM) " +
	"     , CNL_CUST_RELAT_CD = NVL(?, CNL_CUST_RELAT_CD) " +
	"     , CNL_TEL_DDD = NVL(?, CNL_TEL_DDD) " +
	"     , CNL_TEL_EXN = NVL(?, CNL_TEL_EXN) " +
	"     , CNL_TEL_NUM = NVL(?, CNL_TEL_NUM) " +
	" WHERE REQ_INFO_NUM = ? " +
	"   AND RECEIVE_STS_CD IN ('10', '20') " +
	"   AND CNL_YMD = '99991231' ";
	// @formatter:on

	private int cnlAcnt() {
		int rValue = 0;
		try {
			ps = conn.prepareStatement(sqlUpdateTransAcnt);
			ps.setString(1, cardCom.getName());
			ps.setString(2, cnlWhyCd);
			ps.setString(3, accountNum);
			ps.setString(4, custNum);
			ps.executeUpdate();

			ps = conn.prepareStatement(sqlInsertTransAcntReq);
			ps.setString(1, accountNum);
			ps.setString(2, custNum);
			ps.setString(3, cardCom.getName());
			ps.setString(4, bnkCd);
			ps.setString(5, tranFlag);
			ps.setString(6, receiveSecCd);
			ps.setString(7, cnlCustRelatCd);
			ps.setString(8, cnlCustNm);
			ps.setString(9, cnlTelDdd);
			ps.setString(10, cnlTelExn);
			ps.setString(11, cnlTelNum);
			ps.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("TransAcntCnl.cnlAcnt() : " + e.toString());
			rValue = 99;
		} finally {
			close(ps);
		}
		return rValue;
	}

	// @formatter:off
	private final static String sqlUpdateTransAcnt =
	"UPDATE C11.C1AT_TRANS_ACNT " +
	"   SET UPD_DTM = SYSDATE " +
	"     , UPD_EMPID = ? " + // 카드사이름
	"     , UPD_IP = '**.**.**.**' " +
	"     , RECEIVE_STS_CD = '30' " +
	"     , CNL_YMD = TO_CHAR(SYSDATE, 'YYYYMMDD') " +
	"     , CNL_WHY_CD = ? " +
	" WHERE DEFRAY_ACCOUNT_NUM = ? " +
	"   AND CUST_NUM = ? ";

 	private final static String sqlInsertTransAcntReq =
	"INSERT INTO C11.C1AT_TRANS_ACNT_REQ " +
	"            (DEFRAY_ACCOUNT_NUM " +
	"           , CUST_NUM " +
	"           , REQ_ITEM_CD " +
	"           , REQ_YMD " +
	"           , CRT_EMPID " +
	"           , CRT_IP " +
	"           , BNK_CD " +
	"           , REQ_RSLT_CD " +
	"           , RECEIVE_SEC_CD " +
	"           , CUST_RELAT_CD " +
	"           , REQ_NM " +
	"           , REQ_TEL_DDD " +
	"           , REQ_TEL_EXN " +
	"           , REQ_TEL_NUM " +
	"           , KFTC_RECEIVE_STS_CD " +
	"           , TRANS_YMD " +
	"           , APPRO_YMD " +
	"            ) " +
	"VALUES      (? " +
	"           , ? " +
	"           , '03' " +
	"           , TO_CHAR(SYSDATE, 'YYYYMMDD') " +
	"           , ? " + // 카드사이름
	"           , '**.**.**.**' " +
	"           , ? " +
	"           , DECODE(?, '10', '10', '20', '30') " +
	"           , ? " +
	"           , NVL(?, ' ') " +
	"           , ? " +
	"           , ? " +
	"           , ? " +
	"           , ? " +
	"           , '03' " +
	"           , TO_CHAR(SYSDATE, 'YYYYMMDD') " +
	"           , TO_CHAR(SYSDATE, 'YYYYMMDD') " +
	"            ) ";
 // @formatter:on

	private int insertScsTrans() {
		int rValue = 0;
		try {
			ps = conn.prepareStatement(sqlInsertScsTrans);
			ps.setString(1, webId);
			ps.setString(2, webId);
			ps.setString(3, cardCom.getName());
			ps.setString(4, custNum);
			ps.setString(5, reqInfoNum);
			ps.setString(6, accountNum);
			ps.executeUpdate();
		} catch (Exception e) {
			System.out.println("insertScsTrans() : " + e.toString());
			rValue = 99;
		} finally {
			close(ps);
		}
		return rValue;
	}

	// @formatter:off
	private static final String sqlInsertScsTrans =
	"INSERT INTO H11.SCS_TRANS_REQ " +
	"            (CUS_CID " +
	"           , REQ_YMD " +
	"           , SEQ " +
	"           , CRT_DTM " +
	"           , CRT_EMPID " +
	"           , CRT_IP " +
	"           , CUST_NUM " +
	"           , USE_CONT_NUM " +
	"           , DEFRAY_ACCOUNT_NUM " +
	"           , TRANS_REQ_FLAG " +
	"            ) " +
	"VALUES      (? " +
	"           , TO_CHAR(SYSDATE, 'YYYYMMDD') " +
	"           , (SELECT NVL(MAX(SEQ), 0) + 1 " +
	"                FROM H11.SCS_TRANS_REQ " +
	"               WHERE CUS_CID = ? " +
	"                 AND REQ_YMD = TO_CHAR(SYSDATE, 'YYYYMMDD')) " +
	"           , SYSDATE " +
	"           , ? " +
	"           , '**.**.**.**' " +
	"           , ? " +
	"           , ? " +
	"           , ? " +
	"           , '30' " +
	"            ) ";
	// @formatter:on

	private int sendKB() {
		CardClientServiceMap map = ApplicationContextHolder.getBean(CardClientServiceMap.class);
		CardClientService<?> clientService = map.get(cardCom.getCid());
		int rValue = 0;
		// KB로 send
		try {
			ps = conn.prepareStatement(sqlselReq);
			ps.setString(1, accountNum);
			ps.setString(2, custNum);
			ps.setString(3, reqInfoNum);
			rs = ps.executeQuery();
			if (rs.next()) {
				KMC3000 q = new KMC3000();
				KMCClientService.setRequestHeader(q, cardCom, "3000");

				q.b01 = "3";
				q.b02 = reqInfoNum;
				q.b03 = accountNum;
				q.b04 = rs.getString("VALID_YM");
				q.b05 = rs.getString("SOC_BIZ_NUM");
				q.b06 = rs.getString("DEPOSITOR_NM");
				q.b07 = rs.getString("CUST_RELAT_CD");
				q.b08 = rs.getString("REQ_NM");
				q.b09 = rs.getString("REQ_TEL_DDD");
				q.b10 = rs.getString("REQ_TEL_EXN");
				q.b11 = rs.getString("REQ_TEL_NUM");
				q.b12 = rs.getString("DEPOSITOR_TEL_DDD");
				q.b13 = rs.getString("DEPOSITOR_TEL_EXN");
				q.b14 = rs.getString("DEPOSITOR_TEL_NUM");
				q.b15 = rs.getString("ORIG_APPLY_YM");
				q.b16 = rs.getString("CUST_NM");
				q.b17 = rs.getString("ZIP_NO");
				q.b18 = rs.getString("ADDR1");
				q.b19 = rs.getString("ADDR2");

				if (log.isInfoEnabled())
					log.info(String.format("CQ: [%s]", StringU.toString(q)));

				KMC3000 r = clientService.call(q);

				if (log.isInfoEnabled())
					log.info(String.format("CR: [%s]", StringU.toString(r)));
			}
		} catch (Exception e) {
			System.out.println("sendKB() : " + e.toString());
			rValue = 99;
		} finally {
			close(rs, ps);
		}
		return rValue;
	}

	// @formatter:off
	private final static String sqlselReq =
	"SELECT '3' TREAT_FLAG " +
	"     , D.USE_CONT_NUM " +
	"     , C.DEFRAY_ACCOUNT_NUM " +
	"     , trim(B.VALID_PERIOD) VALID_YM " +
	"     , B.SOC_BIZ_NUM " +
	"     , B.DEPOSITOR_NM " +
	"     , B.CUST_RELAT_CD " +
	"     , A.REQ_NM " +
	"     , A.REQ_TEL_DDD " +
	"     , A.REQ_TEL_EXN " +
	"     , A.REQ_TEL_NUM " +
	"     , B.DEPOSITOR_TEL_DDD " +
	"     , B.DEPOSITOR_TEL_EXN " +
	"     , B.DEPOSITOR_TEL_NUM " +
	"     , C.ORIG_APPLY_YM " +
	"     , (SELECT CUST_NM " +
	"          FROM C11.C1AT_CUST_INFO X " +
	"         WHERE X.CUST_NUM = D.CUST_NUM) CUST_NM " +
	"     , F.ZIP_NO1 || F.ZIP_NO2 ZIP_NO " +
	"     , F.CITY || ' ' || F.COUNTY || ' ' || F.TOWN ADDR1 " +
	"     , substr(E.CURR_ADDR_UNION, LENGTH(F.CITY || ' ' || F.COUNTY || ' ' || F.TOWN || ' ') + 1) ADDR2 " +
	"  FROM C11.C1AT_TRANS_ACNT_REQ A " +
	"     , C11.C1AT_TRANS_ACNT B " +
	"     , C11.C1BT_USE_CONT_TRANS C " +
	"     , C11.C1BT_USE_CONT D " +
	"     , C31.C3AT_INST_PLACE E " +
	"     , A11.A1AT_ZIP F " +
	" WHERE C.DEFRAY_ACCOUNT_NUM = B.DEFRAY_ACCOUNT_NUM " +
	"   AND C.CUST_NUM = B.CUST_NUM " +
	"   AND A.DEFRAY_ACCOUNT_NUM(+) = C.DEFRAY_ACCOUNT_NUM " +
	"   AND A.CUST_NUM(+) = C.CUST_NUM " +
	"   AND A.REQ_YMD(+) = C.CNL_YMD " +
	"   AND A.REQ_ITEM_CD(+) = '08' " +
	"   AND C.REQ_INFO_NUM = D.REQ_INFO_NUM " +
	"   AND D.INST_PLACE_NUM = E.INST_PLACE_NUM " +
	"   AND E.ZIP_SEQ = F.ZIP_SEQ " +
	"   AND C.DEFRAY_ACCOUNT_NUM = ? " +
	"   AND C.CUST_NUM = ? " +
	"   AND C.REQ_INFO_NUM = ? " +
	"   AND C.CNL_YMD = to_char(SYSDATE, 'YYYYMMDD') ";
	// @formatter:on

	public String convFormat(String str, int len) {
		String formattedstr = new String();
		byte[] buff;
		int filllen = 0;

		buff = str.getBytes();

		filllen = len - buff.length;
		formattedstr = "";

		for (int i = 0; i < filllen; i++) {
			formattedstr += " ";
		}
		formattedstr = str + formattedstr;

		return formattedstr;
	}

	// TO DO 납부자 통합 고객인지 확인 2016-02-18
	private int chkPayTot() {

		int rValue = 0;

		try {
			StringBuffer sb = new StringBuffer();

			sb.append("SELECT 1 ");
			sb.append("FROM C21.C2BT_PAY_TOT_OBJ A ");
			sb.append("WHERE ");
			sb.append("    A.USE_CONT_NUM = ? ");
			sb.append("AND A.ADD_YN ='Y' ");

			String sqlchkPayTot = sb.toString();

			ps = conn.prepareStatement(sqlchkPayTot);

			ps.setString(1, reqInfoNum);

			rs = ps.executeQuery();

			// 건수가 있으면 납부통합고객이므로 해지 불가
			if (rs.next()) {
				rValue = 55;
			} else {
				rValue = 0;// 정상
			}

		} catch (Exception e) {
			System.out.println("!TransAcntReq.chkPayTot() : " + e.toString());
			rValue = 99;
		} finally {
			close(rs, ps);
		}
		return rValue;
	}

	public void close(AutoCloseable... oa) {
		if (oa != null)
			for (AutoCloseable o : oa)
				if (o != null)
					try {
						o.close();
					} catch (Exception e) {
						log.error(e.getMessage(), e);
					}
	}
}
