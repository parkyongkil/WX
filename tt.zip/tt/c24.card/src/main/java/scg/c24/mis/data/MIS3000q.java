package scg.c24.mis.data;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @제목 카드자동납부(신청,변경,해지) 요청 (3000, 9150)
 */

@Data
@EqualsAndHashCode(callSuper = true)
@XmlRootElement(name = "SCGM")
@XmlAccessorType(XmlAccessType.FIELD)
public class MIS3000q extends MISq {

	/** 1=신청, 2=변경, 3=해지 */
	public String TREAT_FLAG;

	public String USE_CONT_NUM;

	public String DEFRAY_ACCOUNT_NUM;

	/** (국민카드만 사용) */
	public String VALID_YM;

	/** (국민카드만 사용) */
	public String SOC_BIZ_NUM;

	/** 카드소유자 이름 */
	public String DEPOSITOR_NM;

	/** 신청인과의 관계 */
	public String CUST_RELAT_CD;

	/** 신청인 이름 (국민카드만 사용) */
	public String REQ_NM;
	public String REQ_TEL_DDD;
	public String REQ_TEL_EXN;
	public String REQ_TEL_NUM;

	/** 요청일자 (삼성,신한카드 사용) (국민카드 사용안함) */
	public String REQ_YMD;

	/** 신청인 전화번호1 */
	public String DEPOSITOR_TEL_DDD;

	/** 신청인 전화번호2 */
	public String DEPOSITOR_TEL_EXN;

	/** 신청인 전화번호3 */
	public String DEPOSITOR_TEL_NUM;

	/** 적용년월 yyyyMM */
	public String ORIG_APPLY_YM;

	public String CUST_NM;

	/** (국민카드만 사용) */
	public String ZIP_NO;

	/** (국민카드만 사용) */
	public String ADDR1;

	/** (국민카드만 사용) */
	public String ADDR2;
}
