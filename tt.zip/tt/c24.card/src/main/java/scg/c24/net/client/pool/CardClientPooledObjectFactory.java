package scg.c24.net.client.pool;

import org.apache.commons.pool2.PooledObject;
import org.apache.commons.pool2.PooledObjectFactory;
import org.apache.commons.pool2.impl.DefaultPooledObject;

import scg.c24.net.client.CardClient;
import scg.c24.net.client.CardClientFactory;

public class CardClientPooledObjectFactory<T extends CardClient> implements PooledObjectFactory<T> {

	private CardClientFactory factory;

	public CardClientPooledObjectFactory(CardClientFactory factory) {
		super();
		this.factory = factory;
	}

	@Override
	public PooledObject<T> makeObject() throws Exception {
		T o = factory.create();
		o.open();
		return new DefaultPooledObject<T>(o);
	}

	@Override
	public void destroyObject(PooledObject<T> p) throws Exception {
		CardClient o = p.getObject();
		o.close();
	}

	@Override
	public boolean validateObject(PooledObject<T> p) {
		CardClient o = p.getObject();
		return o != null && o.validate();
	}

	@Override
	public void activateObject(PooledObject<T> p) throws Exception {
		CardClient o = p.getObject();
		o.clear();
	}

	@Override
	public void passivateObject(PooledObject<T> p) throws Exception {
		// NOTHING
	}
}
