package scg.c24.net.server;

import java.net.Socket;

import org.springframework.stereotype.Component;

import scg.c24.config.CardConfig;

@Component
public class CardServerAcceptorFactory {

	public CardServerAcceptor create(CardConfig cardConfig, CardServerService service, Socket socket) throws Exception {
		return cardConfig.getServer().getAcceptorType()
				.getConstructor(CardConfig.class, CardServerService.class, Socket.class)
				.newInstance(cardConfig, service, socket);
	}
}
