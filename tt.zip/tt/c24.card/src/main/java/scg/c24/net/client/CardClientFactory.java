package scg.c24.net.client;

import scg.c24.config.CardConfig;

public class CardClientFactory {

	private CardConfig cardConfig;

	public CardClientFactory(CardConfig cardConfig) {
		super();
		this.cardConfig = cardConfig;
	}

	@SuppressWarnings("unchecked")
	public <T extends CardClient> T create() throws Exception {
		return (T) cardConfig.getClient().getClientType().getConstructor(CardConfig.class).newInstance(cardConfig);
	}
}
