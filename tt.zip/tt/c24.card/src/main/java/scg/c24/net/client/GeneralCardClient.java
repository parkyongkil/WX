package scg.c24.net.client;

import scg.c24.config.CardConfig;
import scg.c24.data.CardData;
import scg.c24.data.CardDataRemote;
import scg.c24.net.transfer.CardDataTransfer;
import scg.c24.net.transfer.CardDataTransferFactory;
import tt.lang.string.StringU;

public class GeneralCardClient extends CardClient {

	protected CardDataTransfer<CardData> transfer;

	public GeneralCardClient(CardConfig cardConfig) {
		super(cardConfig);
	}

	@Override
	public void open() throws Exception {
		super.open();
		this.transfer = CardDataTransferFactory.create(cardConfig, socket, false);
	}

	@SuppressWarnings("unchecked")
	@Override
	public <Q, R> R call(Q q) throws Exception {

		if (q instanceof CardDataRemote)
			((CardDataRemote) q).toCARD();

		if (log.isInfoEnabled())
			log.info(String.format("\nCQ(%s): %s", q.getClass().getSimpleName(), StringU.toString(q)));

		transfer.writeObject((CardData) q);

		R r = (R) transfer.readObject();

		if (r instanceof CardDataRemote)
			((CardDataRemote) r).toSCGS();

		if (log.isInfoEnabled())
			log.info(String.format("\nCR(%s): %s", r.getClass().getSimpleName(), StringU.toString(r)));

		return r;
	}
}
