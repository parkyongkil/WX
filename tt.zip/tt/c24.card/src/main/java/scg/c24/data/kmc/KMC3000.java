package scg.c24.data.kmc;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @제목 카드자동납부(신청,변경,해지) 요청 (3000, 9150)
 * 
 * @요청 서울도시가스
 * @응답 국민카드
 */
@Data
@EqualsAndHashCode(callSuper = true)
public class KMC3000 extends KMC2000 {

}
