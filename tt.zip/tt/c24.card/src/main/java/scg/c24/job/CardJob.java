package scg.c24.job;

import java.io.Closeable;

public interface CardJob extends Runnable, Closeable {

	void run();

	void close();
}
