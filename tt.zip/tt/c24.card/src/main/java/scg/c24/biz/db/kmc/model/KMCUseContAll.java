package scg.c24.biz.db.kmc.model;

import lombok.Data;

@Data
public class KMCUseContAll {

	String DEFRAY_ACCOUNT_NUM;

	String CUST_NUM;

	String REQ_INFO_NUM;

	String REQ_YMD;

	String BNK_CD;

	String TRAN_FLAG;
}