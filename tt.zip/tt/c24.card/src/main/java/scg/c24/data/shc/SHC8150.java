package scg.c24.data.shc;

import java.util.Date;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;

import lombok.Data;
import lombok.EqualsAndHashCode;
import scg.c24.data.CardDataRemote;
import scg.c24.util.CardCodeUtil;
import scg.c24.util.seed.SeedUtil;
import tt.io.annotation.AtLPad;
import tt.io.annotation.AtSize;
import tt.io.annotation.AtUnuse;

@Data
@EqualsAndHashCode(callSuper = true)
public class SHC8150 extends SHCData implements CardDataRemote {

	/** 거래구분(1) */
	@AtSize(1)
	public String b01;

	/** 카드번호(32) 우측 Blank, 암호화 */
	@AtSize(32)
	public String b02;

	@AtUnuse(print = true)
	public String b02x;

	/** 구)카드번호(32) 우측 Blank, 암호화 */
	@AtSize(32)
	public String b03;

	/** 카드회원명(100) 우측 Blank */
	@AtSize(100)
	public String b04;

	/** 주민번호 생년월일(6), 암호화(32) */
	@AtSize(32)
	public String b05;

	/** 주민번호의 암호화 또는 복호화 이전값 */
	@AtUnuse(print = true)
	public String b05x;

	/** 연락처 1(4) ('010 123 1234') 4-4-4 각 우측BLANK */
	@AtLPad(4)
	public String b06;

	/** 연락처 2(4) 우측BLANK */
	@AtLPad(4)
	public String b07;

	/** 연락처 3(4) 우측BLANK */
	@AtLPad(4)
	public String b08;

	/** 신청일자(8) */
	@AtSize(8)
	public String b09;

	/** 신청인관계(2) 코드값참조 */
	@AtSize(2)
	public String b10;

	@AtUnuse(print = true)
	public String b10x;

	/** 신청인명(100) 카드회원명과 동일 */
	@AtSize(100)
	public String b11;

	/** 사용계약번호(10) */
	@AtSize(10)
	public String b12;

	/** 응답결과(2) */
	@AtSize(2)
	public String b13;

	/** 적용년월(6) yyyyMM */
	@AtSize(6)
	public String b14;

	/** 카드유효년월 암호화(32) */
	@AtSize(32)
	public String b15;

	@AtUnuse(print = true)
	public String b15x;

	/** 필러(131) */
	@AtSize(131)
	public String b16;

	@Override
	public void toSCGS() throws Exception {
		b02x = b02;
		if (StringUtils.length(b02) == 32)
			b02 = SeedUtil.decrypt(a03, b02);

		b05x = b05;
		if (StringUtils.length(b05) == 32)
			b05 = SeedUtil.decrypt(a03, b05);

		b10x = b10;
		b10 = CardCodeUtil.DECODE_RELAT_CD_SCGS(b10);

		b15x = b15;
		if (StringUtils.length(b15) == 32 && b15.matches("^9{32}$") == false) {
			b15 = SeedUtil.decrypt(a03, b15);
			b15 = StringUtils.right(b15, 4);
		}
	}

	@Override
	public void toCARD() throws Exception {
		b02x = b02;
		if (StringUtils.isNotBlank(b02))
			b02 = SeedUtil.encrypt(a03, b02);

		b05x = b05;
		if (StringUtils.isNotBlank(b05))
			b05 = SeedUtil.encrypt(a03, StringUtils.rightPad(b05, 13, '0'));

		b10x = b10;
		b10 = CardCodeUtil.DECODE_RELAT_CD_SCGS(b10);

		b14 = StringUtils.isBlank(b14) ? DateFormatUtils.format(new Date(), "yyyyMM")
				: StringUtils.substring(b14, 0, 6);

		b15x = b15;
		if (StringUtils.isBlank(b15))
			b15 = StringUtils.repeat('9', 32);
		else {
			if (StringUtils.length(b15) == 4)
				b15 = "20" + b15;
			b15 = SeedUtil.encrypt(a03, b15);
		}
	}
}
