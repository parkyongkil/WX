package scg.c24.data;

import tt.io.TData;

public interface CardData extends TData {

}
