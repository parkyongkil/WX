package scg.c24.net.client.pool;

import java.util.HashMap;

import org.springframework.stereotype.Component;

import scg.c24.net.client.CardClient;

@Component
public class CardClientPoolMap extends HashMap<String, CardClientPool<CardClient>> {

}
