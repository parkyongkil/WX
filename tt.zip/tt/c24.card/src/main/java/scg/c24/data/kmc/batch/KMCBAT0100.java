package scg.c24.data.kmc.batch;

import tt.io.annotation.AtSize;

public class KMCBAT0100 implements KMCBAT {

	/** FTP(3) */
	@AtSize(3)
	public String dutyFlag;

	/** SCG(3) */
	@AtSize(4)
	public String instiCd;

	/** 0600(4) */
	@AtSize(4)
	public String msgClass;

	/** S(1) */
	@AtSize(1)
	public String trFlag;

	/** C(1) */
	@AtSize(1)
	public String sndFlag;

	@AtSize(8)
	public String fileNm;

	/** 000(3) */
	@AtSize(3)
	public String rspnCd;
}
