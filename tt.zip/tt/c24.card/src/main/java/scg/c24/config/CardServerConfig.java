package scg.c24.config;

import lombok.Data;
import scg.c24.net.server.CardServerAcceptor;
import scg.c24.net.server.CardServerService;

@Data
public class CardServerConfig {

	private int port;
	private int timeout;
	private Class<? extends CardServerService> serviceType;
	private Class<? extends CardServerAcceptor> acceptorType;
}
