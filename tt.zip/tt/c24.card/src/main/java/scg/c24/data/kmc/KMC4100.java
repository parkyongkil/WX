package scg.c24.data.kmc;

import lombok.Data;
import lombok.EqualsAndHashCode;
import tt.io.annotation.AtSize;

/**
 * @제목 카드인증 요청 (4000, 9050)
 * 
 * @요청 서울도시가스
 * @응답 국민카드
 */

@Data
@EqualsAndHashCode(callSuper = true)
public class KMC4100 extends KMCData {

	/** 카드번호(16) */
	@AtSize(16)
	public String b01;

	/** 카드고객 주민번호(13) 199012310000000 */
	@AtSize(13)
	public String b02;

	/** 카드상태코드(2) 00=없음, 10=수령등록, 20=사용등록, 30=해지, 40=만료, 50=정지 */
	@AtSize(2)
	public String b03;

	/** 제휴카드여부(1) YN */
	@AtSize(1)
	public String b04;

	/** 카드유효기간(4) yyMM */
	@AtSize(4)
	public String b05;

	/** CI(88) */
	@AtSize(88)
	public String b06;

	/** 필러(76) */
	@AtSize(76)
	public String b07;
}
