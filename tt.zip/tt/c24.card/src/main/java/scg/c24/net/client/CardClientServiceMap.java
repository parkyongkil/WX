package scg.c24.net.client;

import java.util.HashMap;

import org.springframework.stereotype.Component;

@Component
public class CardClientServiceMap extends HashMap<String, CardClientService<? extends CardClient>> {

}
