package scg.c24.mis.util;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

public class URLCaller {

	protected URLCaller() {
		// NOTHING
	}

	public static <X> X call(String u, Object o, Class<X> c) throws Exception {
		URL url = new URL(u);
		HttpURLConnection h = (HttpURLConnection) url.openConnection();
		h.setRequestMethod("POST");
		h.setRequestProperty("Content-Type", "application/xml");
		h.setRequestProperty("Accept", "application/xml");
		h.setRequestProperty("Connection", "keep-alive");
		h.setUseCaches(false);
		h.setConnectTimeout(20000);
		h.setAllowUserInteraction(true);
		h.setDoInput(true);
		h.setDoOutput(true);

		OutputStream out = h.getOutputStream();
		writeXml(out, o);

		InputStream in = h.getInputStream();
		X x = readXml(in, c);

		h.disconnect();

		return x;
	}

	private static void writeXml(OutputStream out, Object o) throws Exception {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		JAXBContext jc = JAXBContext.newInstance(o.getClass());
		Marshaller m = jc.createMarshaller();
		m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
		m.marshal(o, baos);
		byte[] b = baos.toByteArray();
		int n = b.length;
		System.out.println(String.format("(%d)>> %s", n, new String(b)));
		out.write(b);
		out.close();
	}

	@SuppressWarnings("unchecked")
	private static <X> X readXml(InputStream in, Class<X> c) throws Exception {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		int n = 4096;
		byte[] b = new byte[n];
		while ((n = in.read(b)) != -1)
			baos.write(b, 0, n);
		b = baos.toByteArray();
		n = b.length;
		System.out.println(String.format("<<(%d) %s", n, new String(b)));
		ByteArrayInputStream bais = new ByteArrayInputStream(b);
		JAXBContext jc = JAXBContext.newInstance(c);
		Unmarshaller m = jc.createUnmarshaller();
		return (X) m.unmarshal(bais);
	}
}
