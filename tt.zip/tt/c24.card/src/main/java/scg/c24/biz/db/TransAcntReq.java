package scg.c24.biz.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.sql.DataSource;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import scg.c24.ApplicationContextHolder;
import scg.c24.data.kmc.KMC3000;
import scg.c24.net.client.CardClientService;
import scg.c24.net.client.CardClientServiceMap;
import scg.c24.net.client.kmc.KMCClientService;
import scg.c24.util.CardCom;
import tt.lang.string.StringU;

public class TransAcntReq {

	private String accountNum;
	private String bnkCd;
	private String useContNum;
	private String validYm;
	private String socBizNum;
	private String depositNm;
	private String relatCd;
	private String reqNm;
	private String reqCpDdd;
	private String reqCpExn;
	private String reqCpNum;
	private String reqTelDdd;
	private String reqTelExn;
	private String reqTelNum;
	private String payMethod;
	private String receiveSecCd; // 5 홈페이지 6 카드사
	private String webId;
	private String ci;
	private String joinYn;

	private String custNum;
	private String receiveStsCd;
	private String applyYmd;
	// private String treatFlag;

	private CardCom cardCom;
	private boolean isKMC;

	private DataSource dataSource = ApplicationContextHolder.getBean(DataSource.class);

	private Connection conn = null;
	private PreparedStatement ps = null;
	private ResultSet rs = null;

	private Log log = LogFactory.getLog(getClass());

	public TransAcntReq(String accountNum, String bnkCd, String useContNum, String validYm, String socBizNum,
			String depositNm, String relatCd, String reqNm, String reqCpDdd, String reqCpExn, String reqCpNum,
			String reqTelDdd, String reqTelExn, String reqTelNum, String payMethod, String receiveSecCd, String webId,
			String ci, String joinYn) {
		this.accountNum = accountNum;
		this.bnkCd = bnkCd;
		this.useContNum = useContNum;
		this.validYm = validYm;
		this.socBizNum = socBizNum;
		this.depositNm = depositNm;
		this.relatCd = relatCd;
		this.reqNm = reqNm;
		this.reqCpDdd = reqCpDdd;
		this.reqCpExn = reqCpExn;
		this.reqCpNum = reqCpNum;
		this.reqTelDdd = reqTelDdd;
		this.reqTelExn = reqTelExn;
		this.reqTelNum = reqTelNum;
		this.payMethod = payMethod;
		this.receiveSecCd = receiveSecCd;
		this.webId = webId;
		this.ci = ci;
		this.joinYn = StringUtils.isBlank(joinYn) ? " " : joinYn;
		this.cardCom = CardCom.getByBnkCd(bnkCd);
		this.isKMC = CardCom.KMC.equals(cardCom.getCid());
	}

	public String getApplyYmd() {
		return applyYmd;
	}

	public int start() {
		int chk, rValue = 0;
		String tmpStsCd;

		chk = validate();
		// parameter 체크
		if (chk != 0) {
			return chk;
		}

		try {

			conn = dataSource.getConnection();
			conn.setAutoCommit(false);
			// 사용계약 상태 체크
			chk = chkUseCont();
			if (chk != 0) {
				throw new Exception("사용계약번호 상태 오류");
			}

			// 이체상태 체크
			chk = chkTrans();
			if (chk == 99) {
				throw new Exception("이체상태 체크 오류");
			}

			if (chk == 10) {

				// TO DO 카드자동이체 변경시(20) 납부자통합 고객 체크 2016-02-18
				chk = chkPayTot("20");

				if (chk != 0) {
					throw new Exception("납부자통합 고객 변경불가");
				}

				TransAcntCnl objCnl = new TransAcntCnl(useContNum, "40", null, null, null, null, null, null, "1", "N",
						"6", null, true, conn, ci);
				chk = objCnl.start();
				if (chk != 0) {
					throw new Exception("사용계약 변경(해지)중 오류");
				}
			} else {

				// TO DO 카드자동이체 신청시(10) 납부자통합 고객 체크 2016-02-18
				chk = chkPayTot("10");
				if (chk != 0) {
					throw new Exception("납부자통합 고객 신청불가");
				}
			}

			// 현재 계좌상태 조회 process
			chk = chkReceiveSts();
			if (chk == 99) {
				throw new Exception("계좌정보 조회 중 오류");
			}

			if (payMethod.equals("20")) // 자동이체는 접수
			{
				tmpStsCd = "10";
			} else // 카드이체는 바로 정상
			{
				tmpStsCd = "20";
			}

			if (receiveStsCd == null || receiveStsCd.equals("")) { // 계좌없음->신규생성
				chk = insertTransAcnt();
				if (chk != 0)
					throw new Exception("이체계좌생성오류");
				chk = insertTransAcntReq();
				if (chk != 0)
					throw new Exception("이체계좌신청생성오류");
				chk = insertUseContTrans(tmpStsCd);
				if (chk != 0)
					throw new Exception("사용계약이체생성오류");

			} else if (receiveStsCd.equals("11") || receiveStsCd.equals("30") || receiveStsCd.equals("40")) { // 접수취소,해지,오류->변경+신규
				chk = updateTransAcnt();
				if (chk != 0)
					throw new Exception("이체계좌변경오류");
				chk = insertTransAcntReq();
				if (chk != 0)
					throw new Exception("이체계좌신청생성오류");
				chk = insertUseContTrans(tmpStsCd);
				if (chk != 0)
					throw new Exception("사용계약이체생성오류");
			} else if (receiveStsCd.equals("10") || receiveStsCd.equals("20")) { // 접수,정상->신규
				chk = insertUseContTrans(receiveStsCd);
				if (chk != 0)
					throw new Exception("사용계약이체생성오류");
			}

			if ((receiveStsCd != null && receiveStsCd.equals("20")) || payMethod.equals("30")) { // 은행이체,정상
																										// &&
																									// 카드이체
																									// ->
																									// 납부방법변경
				chk = updateReqInfo();
				if (chk != 0)
					throw new Exception("청구정보변경오류");
			}

			if (receiveSecCd.equals("5")) { // 홈페이지 -> 추가인서트
				chk = insertScsTrans();
				if (chk != 0)
					throw new Exception("홈페이지입력오류");
				if (payMethod.equals("30")) {
					if (CardCom.KMC.equals(cardCom.getCid()))
						chk = sendKB();
				}
			}

		} catch (Exception e) {
			log.error(e.getMessage(), e);
			rValue = chk;
		} finally {
			try {
				if (conn != null)
					if (rValue == 0)
						conn.commit();
					else
						conn.rollback();
				if (conn != null)
					conn.close();
			} catch (Exception e) {
				log.error(e.getMessage(), e);
			}
		}
		return rValue;
	}

	/* validate() - parameter 체크 */
	private int validate() {
		int n = isKMC ? 20 : 32;
		if (accountNum == null || accountNum.length() > n) {
			log.error("!accountNum error : " + accountNum);
			return 98;
		}
		if (bnkCd == null || bnkCd.length() != 3) {
			log.error("!bnkCd error : " + bnkCd);
			return 98;
		}
		if (useContNum == null || useContNum.length() != 10) {
			log.error("!useContNum error : " + useContNum);
			return 98;
		}
		if (isKMC && validYm != null && validYm.length() != 4) {
			log.error("!validYm error : " + validYm);
			return 98;
		}
		if (isKMC && socBizNum == null || (socBizNum.length() != 13 && socBizNum.length() != 10)) {
			log.error("!socBizNum error : " + socBizNum);
			return 98;
		}
		if (relatCd == null || relatCd.length() != 2) {
			log.error("!relatCd error : " + relatCd);
			return 98;
		}
		if (payMethod == null || payMethod.length() != 2) {
			log.error("!payMethod error : " + payMethod);
			return 98;
		}
		return 0;
	}

	private int chkUseCont() {
		int rValue = 0;
		/* check! 0. 사용계약번호 존재여부 체크 1. 사용계약번호 상태 체크 2. 당일접수자료 체크 3. 임시고객번호 체크 */
		try {
			ps = conn.prepareStatement(sqlChk);
			ps.setString(1, useContNum);
			ps.setString(2, useContNum);
			ps.setString(3, accountNum);
			ps.setString(4, useContNum);
			ps.setString(5, useContNum);
			rs = ps.executeQuery();
			if (rs.next()) {
				if (rs.getString("CHK_0").equals("0")) {
					log.error("!TransAcntReq.chkUseCont:사용계약미존재 오류");
					rValue = 10;
				} else if (rs.getString("CHK_1").equals("0")) {
					log.error("!TransAcntReq.chkUseCont:사용계약 해지상태 오류");
					rValue = 20;
				} else if (rs.getString("CHK_2").equals("0")) {
					log.error("!TransAcntReq.chkUseCont:기신청자료");
					rValue = 30;
				} else if (rs.getString("CHK_3").equals("0")) {
					log.error("!TransAcntReq.chkUseCont:임시고객번호 오류");
					rValue = 40;
				}
			} else {
				rValue = 99;
			}
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			rValue = 99;
		} finally {
			close(rs, ps);
		}
		return rValue;
	}

	// @formatter:off
	private static final String sqlChk =
	"SELECT NVL((SELECT '1' " +
	"              FROM C11.C1BT_USE_CONT " +
	"             WHERE USE_CONT_NUM = ?), '0') CHK_0 " +
	"     , NVL((SELECT '1' " +
	"              FROM C11.C1BT_USE_CONT " +
	"             WHERE USE_CONT_NUM = ? " +
	"               AND CONT_STS_CD != '30'), '0') CHK_1 " +
	"     , NVL((SELECT '0' " +
	"              FROM C11.C1BT_USE_CONT_TRANS " +
	"             WHERE DEFRAY_ACCOUNT_NUM = ? " +
	"               AND REQ_INFO_NUM = ? " +
	"               AND REQ_YMD = TO_CHAR(SYSDATE, 'YYYYMMDD')) " +
	"         , '1') CHK_2 " +
	"     , NVL((SELECT '1' " +
	"              FROM C11.C1BT_USE_CONT " +
	"             WHERE USE_CONT_NUM = ? " +
	"               AND CUST_NUM NOT LIKE '0%'), '0') CHK_3 " +
	"  FROM DUAL ";
	// @formatter:on

	private int chkTrans() {
		int rValue = 0;
		/* check! 현재 이체계좌 상태 체크 및 고객번호 등 조회 */
		try {
			ps = conn.prepareStatement(sqlchkTrans);
			ps.setString(1, bnkCd);
			ps.setString(2, useContNum);
			rs = ps.executeQuery();
			if (rs.next()) {
				this.custNum = rs.getString("CUST_NUM");
				this.applyYmd = rs.getString("APPLY_YMD");
				// this.treatFlag = rs.getString("TREAT_FLAG");
				// 이체중이면 해지 실시
				if (rs.getString("TRANS_YN").equals("Y"))
					rValue = 10;
			} else
				rValue = 99; // 사용계약 없어짐
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			rValue = 99;
		} finally {
			close(rs, ps);
		}
		return rValue;
	}

	// @formatter:off
	private static final String sqlchkTrans =
	"SELECT A.CUST_NUM " +
	"     , B.DEFRAY_ACCOUNT_NUM " +
	"     , B.REQ_INFO_NUM " +
	"     , B.REQ_YMD " +
	"     , CASE WHEN B.BNK_CD = ? THEN '2' ELSE '1' END TREAT_FLAG " +
	"     , CASE " +
	"           WHEN B.DEFRAY_ACCOUNT_NUM IS NULL THEN 'N' " +
	"           ELSE 'Y' " +
	"       END TRANS_YN " +
	"     , C21.PKS_C2_FUNC_4.FUNC_GET_C1_ORIG_APPLY_YMD(A.USE_CONT_NUM) APPLY_YMD " + 
	"  FROM C11.C1BT_USE_CONT A " +
	"     , (SELECT * " +
	"          FROM C11.C1BT_USE_CONT_TRANS B " +
	"         WHERE RECEIVE_STS_CD IN('10', '20') " +
	"           AND CNL_YMD = '99991231') B " +
	" WHERE A.USE_CONT_NUM = ? " +
	"   AND A.REQ_INFO_NUM = B.REQ_INFO_NUM(+) " +
	"   AND A.CUST_NUM = B.CUST_NUM(+) ";
	// @formatter:on

	private int chkReceiveSts() {
		int rValue = 0;
		/* check! 현재계좌상태 체크 */
		try {
			ps = conn.prepareStatement(sqlchkReceiveSts);
			ps.setString(1, accountNum);
			ps.setString(2, custNum);

			rs = ps.executeQuery();

			if (rs.next()) {
				receiveStsCd = rs.getString("RECEIVE_STS_CD");
			} else {
				receiveStsCd = null;
			}
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			rValue = 99;
		} finally {
			close(rs, ps);
		}
		return rValue;
	}

	private static final String sqlchkReceiveSts = "SELECT RECEIVE_STS_CD " + "  FROM C11.C1AT_TRANS_ACNT "
			+ " WHERE DEFRAY_ACCOUNT_NUM = ? " + "   AND CUST_NUM = ? ";

	private int insertTransAcnt() {
		int rValue = 0;
		try {
			ps = conn.prepareStatement(sqlinsertTransAcnt);
			ps.setString(1, accountNum);
			ps.setString(2, custNum);
			ps.setString(3, cardCom.getName());
			ps.setString(4, payMethod);
			ps.setString(5, bnkCd);
			ps.setString(6, receiveSecCd);
			ps.setString(7, payMethod);
			ps.setString(8, payMethod);
			ps.setString(9, custNum);
			ps.setString(10, bnkCd + "0000");
			ps.setString(11, bnkCd + "0000");
			ps.setString(12, socBizNum);
			ps.setString(13, depositNm);
			ps.setString(14, relatCd);
			ps.setString(15, isKMC ? reqTelDdd : reqCpDdd);
			ps.setString(16, isKMC ? reqTelExn : reqCpExn);
			ps.setString(17, isKMC ? reqTelNum : reqCpNum);
			ps.setString(18, validYm);
			ps.executeUpdate();
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			rValue = 99;
		} finally {
			close(ps);
		}
		return rValue;
	}

	// @formatter:off
	private static final String sqlinsertTransAcnt =
	"INSERT INTO C11.C1AT_TRANS_ACNT " +
	"            (DEFRAY_ACCOUNT_NUM " +
	"           , CUST_NUM " +
	"           , CRT_EMPID " +
	"           , CRT_IP " +
	"           , TRAN_FLAG " +
	"           , BNK_CD " +
	"           , RECEIVE_PLC_FLAG_CD " +
	"           , RECEIVE_STS_CD " +
	"           , REQ_YMD " +
	"           , CNL_YMD " +
	"           , PAY_METHOD_CD " +
	"           , BEFO_PAY_MANAGE_NUM " +
	"           , ACCOUNT_BRANCH_CD " +
	"           , BNK_BRANCH_CD " +
	"           , SOC_BIZ_NUM " +
	"           , DEPOSITOR_NM " +
	"           , CUST_RELAT_CD " +
	"           , DEPOSITOR_TEL_DDD " +
	"           , DEPOSITOR_TEL_EXN " +
	"           , DEPOSITOR_TEL_NUM " +
	"           , VALID_PERIOD " +
	"           , TRANS_YMD " +
	"            ) " +
	"VALUES      (? " +
	"           , ? " +
	"           , ? " +
	"           , '**.**.**.**' " +
	"           , DECODE(?, '20', '10', '30', '20', ' ') " +
	"           , ? " +
	"           , DECODE(?, '5', '5', '6', '4', ' ') " +
	"           , DECODE(?, '20', '10', '30', '20') " +
	"           , TO_CHAR(SYSDATE, 'YYYYMMDD') " +
	"           , '99991231' " +
	"           , ? " +
	"           , NVL(?, ' ') " +
	"           , NVL(?, ' ') " +
	"           , NVL(?, ' ') " +
	"           , ? " +
	"           , ? " +
	"           , NVL(?, ' ') " +
	"           , ? " +
	"           , ? " +
	"           , ? " +
	"           , NVL(?, ' ') " +
	"           , TO_CHAR(SYSDATE, 'YYYYMMDD') " +
	"            ) ";
	// @formatter:on

	private int updateTransAcnt() {
		int rValue = 0;
		try {
			ps = conn.prepareStatement(sqlupdateTransAcnt);
			ps.setString(1, cardCom.getName());
			ps.setString(2, payMethod);
			ps.setString(3, bnkCd);
			ps.setString(4, receiveSecCd);
			ps.setString(5, payMethod);
			ps.setString(6, payMethod);
			ps.setString(7, bnkCd + "0000");
			ps.setString(8, bnkCd + "0000");
			ps.setString(9, socBizNum);
			ps.setString(10, depositNm);
			ps.setString(11, relatCd);
			ps.setString(12, isKMC ? reqTelDdd : reqCpDdd);
			ps.setString(13, isKMC ? reqTelExn : reqCpExn);
			ps.setString(14, isKMC ? reqTelNum : reqCpNum);
			ps.setString(15, validYm);
			ps.setString(16, accountNum);
			ps.setString(17, custNum);
			ps.executeUpdate();
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			rValue = 99;
		} finally {
			close(ps);
		}
		return rValue;
	}

	// @formatter:off
	private static final String sqlupdateTransAcnt =
	"UPDATE C11.C1AT_TRANS_ACNT " +
	"   SET UPD_DTM = SYSDATE " +
	"     , UPD_EMPID = ? " +
	"     , UPD_IP = '**.**.**.**' " +
	"     , TRAN_FLAG = DECODE(?, '20', '10', '30', '20', ' ') " +
	"     , BNK_CD = NVL(?, BNK_CD) " +
	"     , RECEIVE_PLC_FLAG_CD = DECODE(?, '5', '5', '6', '4', ' ') " +
	"     , RECEIVE_STS_CD = DECODE(?, '20', '10', '30', '20') " +
	"     , REQ_YMD = TO_CHAR(SYSDATE, 'YYYYMMDD') " +
	"     , TRANS_YMD = TO_CHAR(SYSDATE, 'YYYYMMDD') " +
	"     , CNL_YMD = '99991231' " +
	"     , CNL_WHY_CD = ' ' " +
	"     , PAY_METHOD_CD = NVL(?, PAY_METHOD_CD) " +
	"     , ACCOUNT_BRANCH_CD = NVL(?, ACCOUNT_BRANCH_CD) " +
	"     , BNK_BRANCH_CD = NVL(?, BNK_BRANCH_CD) " +
	"     , SOC_BIZ_NUM = NVL(?, SOC_BIZ_NUM) " +
	"     , DEPOSITOR_NM = NVL(?, DEPOSITOR_NM) " +
	"     , CUST_RELAT_CD = NVL(?, CUST_RELAT_CD) " +
	"     , DEPOSITOR_TEL_DDD = NVL(?, DEPOSITOR_TEL_DDD) " +
	"     , DEPOSITOR_TEL_EXN = NVL(?, DEPOSITOR_TEL_EXN) " +
	"     , DEPOSITOR_TEL_NUM = NVL(?, DEPOSITOR_TEL_NUM) " +
	"     , VALID_PERIOD = NVL(?, VALID_PERIOD) " +
	" WHERE DEFRAY_ACCOUNT_NUM = ? " +
	"   AND CUST_NUM = ? ";
	// @formatter:on

	private int insertTransAcntReq() {
		int rValue = 0;
		try {
			ps = conn.prepareStatement(sqlinsertTransAcntReq);
			ps.setString(1, accountNum);
			ps.setString(2, custNum);
			ps.setString(3, cardCom.getName());
			ps.setString(4, bnkCd);
			ps.setString(5, payMethod);
			ps.setString(6, receiveSecCd);
			ps.setString(7, relatCd);
			ps.setString(8, reqNm);
			ps.setString(9, reqCpDdd);
			ps.setString(10, reqCpExn);
			ps.setString(11, reqCpNum);
			ps.setString(12, validYm);
			ps.executeUpdate();
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			rValue = 99;
		} finally {
			close(ps);
		}
		return rValue;
	}

	// @formatter:off
	private static final String sqlinsertTransAcntReq =
	"INSERT INTO C11.C1AT_TRANS_ACNT_REQ " +
	"            (DEFRAY_ACCOUNT_NUM " +
	"           , CUST_NUM " +
	"           , REQ_ITEM_CD " +
	"           , REQ_YMD " +
	"           , CRT_EMPID " +
	"           , CRT_IP " +
	"           , BNK_CD " +
	"           , REQ_RSLT_CD " +
	"           , RECEIVE_SEC_CD " +
	"           , CUST_RELAT_CD " +
	"           , REQ_NM " +
	"           , REQ_TEL_DDD " +
	"           , REQ_TEL_EXN " +
	"           , REQ_TEL_NUM " +
	"           , KFTC_RECEIVE_STS_CD " +
	"           , VALID_PERIOD " +
	"           , TRANS_YMD " +
	"           , APPRO_YMD " +
	"            ) " +
	"VALUES      (? " +
	"           , ? " +
	"           , '01' " +
	"           , TO_CHAR(SYSDATE, 'YYYYMMDD') " +
	"           , ? " +
	"           , '**.**.**.**' " +
	"           , ? " +
	"           , DECODE(?, '20', '10', '30', '30') " +
	"           , ? " +
	"           , ? " +
	"           , ? " +
	"           , ? " +
	"           , ? " +
	"           , ? " +
	"           , '01' " +
	"           , NVL(?, ' ') " +
	"           , TO_CHAR(SYSDATE, 'YYYYMMDD') " +
	"           , TO_CHAR(SYSDATE, 'YYYYMMDD') " +
	"            ) ";
	// @formatter:on

	private int insertUseContTrans(String parReceiveSts) {
		int rValue = 0;
		try {
			ps = conn.prepareStatement(sqlinsertUseContTrans);
			ps.setString(1, accountNum);
			ps.setString(2, custNum);
			ps.setString(3, useContNum);
			ps.setString(4, cardCom.getName());
			ps.setString(5, bnkCd);
			ps.setString(6, parReceiveSts);
			ps.setString(7, receiveSecCd);
			ps.setString(8, applyYmd);
			ps.setString(9, joinYn);
			ps.executeUpdate();
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			rValue = 99;
		} finally {
			close(ps);
		}
		return rValue;
	}

	// @formatter:off
	private static final String sqlinsertUseContTrans =
	"INSERT INTO C11.C1BT_USE_CONT_TRANS " +
	"            (DEFRAY_ACCOUNT_NUM " +
	"           , CUST_NUM " +
	"           , REQ_INFO_NUM " +
	"           , REQ_YMD " +
	"           , CRT_EMPID " +
	"           , CRT_IP " +
	"           , BNK_CD " +
	"           , RECEIVE_STS_CD " +
	"           , RECEIVE_SEC_CD " +
	"           , ORIG_APPLY_YM " +
	"           , CNL_YMD " +
	"           , JOIN_YN " +
	"            ) " +
	"VALUES      (? " +
	"           , ? " +
	"           , ? " +
	"           , TO_CHAR(SYSDATE, 'YYYYMMDD') " +
	"           , ? " +
	"           , '**.**.**.**' " +
	"           , ? " +
	"           , ? " +
	"           , NVL(?, ' ') " +
	"           , ? " +
	"           , '99991231' " +
	"           , ? " +  //제휴카드여부
	"            ) ";
	// @formatter:on

	private int updateReqInfo() {
		int rValue = 0;
		try {
			ps = conn.prepareStatement(sqlupdateReqInfo);
			ps.setString(1, cardCom.getName());
			ps.setString(2, payMethod);
			ps.setString(3, useContNum);
			ps.executeUpdate();
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			rValue = 99;
		} finally {
			close(ps);
		}
		return rValue;
	}

	// @formatter:off
	private static final String sqlupdateReqInfo = 
	"UPDATE C11.C1BT_REQ_INFO " +
	"   SET UPD_DTM = SYSDATE " +
	"     , UPD_EMPID = ? " +
	"     , UPD_IP = '**.**.**.**' " +
	"     , PAY_METHOD_CD = ? " +
	" WHERE REQ_INFO_NUM = ? ";
	// @formatter:on

	private int insertScsTrans() {
		int rValue = 0;
		try {
			ps = conn.prepareStatement(sqlInsertScsTrans);
			ps.setString(1, webId);
			ps.setString(2, webId);
			ps.setString(3, cardCom.getName());
			ps.setString(4, custNum);
			ps.setString(5, useContNum);
			ps.setString(6, accountNum);
			ps.executeUpdate();
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			rValue = 99;
		} finally {
			close(ps);
		}
		return rValue;
	}

	// @formatter:off
	private static final String sqlInsertScsTrans =
	"INSERT INTO H11.SCS_TRANS_REQ " +
	"            (CUS_CID " +
	"           , REQ_YMD " +
	"           , SEQ " +
	"           , CRT_DTM " +
	"           , CRT_EMPID " +
	"           , CRT_IP " +
	"           , CUST_NUM " +
	"           , USE_CONT_NUM " +
	"           , DEFRAY_ACCOUNT_NUM " +
	"           , TRANS_REQ_FLAG " +
	"            ) " +
	"VALUES      (? " +
	"           , TO_CHAR(SYSDATE, 'YYYYMMDD') " +
	"           , (SELECT NVL(MAX(SEQ), 0) + 1 " +
	"                FROM H11.SCS_TRANS_REQ " +
	"               WHERE CUS_CID = ? " +
	"                 AND REQ_YMD = TO_CHAR(SYSDATE, 'YYYYMMDD')) " +
	"           , SYSDATE " +
	"           , ? " +
	"           , '**.**.**.**' " +
	"           , ? " +
	"           , ? " +
	"           , ? " +
	"           , '10' " +
	"            ) ";
	// @formatter:on

	private int sendKB() {

		CardClientServiceMap map = ApplicationContextHolder.getBean(CardClientServiceMap.class);
		CardClientService<?> service = map.get(cardCom.getCid());

		int rValue = 0;
		/* KB로 send */
		try {
			ps = conn.prepareStatement(sqlselReq);
			ps.setString(1, accountNum);
			ps.setString(2, custNum);
			ps.setString(3, useContNum);

			rs = ps.executeQuery();

			if (rs.next()) {

				KMC3000 q = new KMC3000();
				KMCClientService.setRequestHeader(q, cardCom, "3000");

				q.b01 = "1";
				q.b02 = useContNum;
				q.b03 = accountNum;
				q.b04 = rs.getString("VALID_YM");
				q.b05 = socBizNum;
				q.b06 = depositNm;
				q.b07 = relatCd;
				q.b08 = reqNm;
				q.b09 = reqCpDdd;
				q.b10 = reqCpExn;
				q.b11 = reqCpNum;
				q.b12 = reqTelDdd;
				q.b13 = reqTelExn;
				q.b14 = reqTelNum;
				q.b15 = rs.getString("ORIG_APPLY_YM");
				q.b16 = rs.getString("CUST_NM");
				q.b17 = rs.getString("ZIP_NO");
				q.b18 = rs.getString("ADDR1");
				q.b19 = rs.getString("ADDR2");

				if (log.isInfoEnabled())
					log.info(String.format("CQ: [%s]", StringU.toString(q)));

				KMC3000 r = service.call(q);

				if (log.isInfoEnabled())
					log.info(String.format("CR: [%s]", StringU.toString(r)));
			}
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			rValue = 99;
		} finally {
			close(rs, ps);
		}
		return rValue;
	}

	// @formatter:off
	private final static String sqlselReq =
	"SELECT '1' TREAT_FLAG " +
	"     , D.USE_CONT_NUM " +
	"     , C.DEFRAY_ACCOUNT_NUM " +
	"     , TRIM(B.VALID_PERIOD) VALID_YM " +
	"     , B.SOC_BIZ_NUM " +
	"     , B.DEPOSITOR_NM " +
	"     , B.CUST_RELAT_CD " +
	"     , A.REQ_NM " +
	"     , A.REQ_TEL_DDD " +
	"     , A.REQ_TEL_EXN " +
	"     , A.REQ_TEL_NUM " +
	"     , B.DEPOSITOR_TEL_DDD " +
	"     , B.DEPOSITOR_TEL_EXN " +
	"     , B.DEPOSITOR_TEL_NUM " +
	"     , C.ORIG_APPLY_YM " +
	"     , (SELECT CUST_NM " +
	"          FROM C11.C1AT_CUST_INFO X " +
	"         WHERE X.CUST_NUM = D.CUST_NUM) CUST_NM " +
	"     , F.ZIP_NO1 || F.ZIP_NO2 ZIP_NO " +
	"     , F.CITY || ' ' || F.COUNTY || ' ' || F.TOWN ADDR1 " +
	"     , SUBSTR(E.CURR_ADDR_UNION, LENGTH(F.CITY || ' ' || F.COUNTY || ' ' || F.TOWN || ' ') + 1) ADDR2 " +
	"  FROM C11.C1AT_TRANS_ACNT_REQ A " +
	"     , C11.C1AT_TRANS_ACNT B " +
	"     , C11.C1BT_USE_CONT_TRANS C " +
	"     , C11.C1BT_USE_CONT D " +
	"     , C31.C3AT_INST_PLACE E " +
	"     , A11.A1AT_ZIP F " +
	" WHERE C.DEFRAY_ACCOUNT_NUM = B.DEFRAY_ACCOUNT_NUM " +
	"   AND C.CUST_NUM = B.CUST_NUM " +
	"   AND A.DEFRAY_ACCOUNT_NUM(+) = C.DEFRAY_ACCOUNT_NUM " +
	"   AND A.CUST_NUM(+) = C.CUST_NUM " +
	"   AND A.REQ_YMD(+) = C.REQ_YMD " +
	"   AND A.REQ_ITEM_CD(+) = '02' " +
	"   AND C.REQ_INFO_NUM = D.REQ_INFO_NUM " +
	"   AND D.INST_PLACE_NUM = E.INST_PLACE_NUM " +
	"   AND E.ZIP_SEQ = F.ZIP_SEQ " +
	"   AND C.DEFRAY_ACCOUNT_NUM = ? " +
	"   AND C.CUST_NUM = ? " +
	"   AND C.REQ_INFO_NUM = ? " +
	"   AND C.REQ_YMD = TO_CHAR(SYSDATE, 'YYYYMMDD') ";
	// @formatter:on

	public String convFormat(String str, int len) {
		String formattedstr = new String();
		byte[] buff;
		int filllen = 0;

		buff = str.getBytes();

		filllen = len - buff.length;
		formattedstr = "";

		for (int i = 0; i < filllen; i++) {
			formattedstr += " ";
		}
		formattedstr = str + formattedstr;

		return formattedstr;
	}

	// TO DO 납부자 통합 고객인지 확인 2016-02-18 reqFlag : 카드이체 신청/변경 구분 10 : 신청 20 : 변경
	private int chkPayTot(String reqFlag) {

		int rValue = 0;

		try {
			StringBuffer sb = new StringBuffer();

			if ("10".equals(reqFlag)) {
				// 카드이체 신청시 납부자통합 확인
				sb.append("SELECT 1 ");
				sb.append("FROM C21.C2BT_PAY_TOT_OBJ A ");
				sb.append("WHERE 1=1 ");
				sb.append("AND A.USE_CONT_NUM = ? ");
				sb.append("AND A.ADD_YN ='Y' ");
			} else if ("20".equals(reqFlag)) {
				// 카드이체 변경시 납부자통합 이고 이체구분이 카드가 아닌경우(은행이체::TRAN_FLAG:10) 블락킹
				// 카드 -> 카드 변경은 가능
				sb.append("SELECT 1 ");
				sb.append("FROM    C21.C2BT_PAY_TOT_OBJ A ");
				sb.append("    ,   C11.C1BT_REQ_INFO    B ");
				sb.append("WHERE 1=1 ");
				sb.append("AND A.USE_CONT_NUM = ? ");
				sb.append("AND A.ADD_YN = 'Y' ");
				sb.append("AND A.USE_CONT_NUM = B.REQ_INFO_NUM ");
				sb.append("AND B.PAY_METHOD_CD = '20' ");
			} else {
				throw new Exception("납부자통합 확인 중 FLAG 오류");
			}

			String sqlchkPayTot = sb.toString();

			ps = conn.prepareStatement(sqlchkPayTot);

			if ("10".equals(reqFlag)) {
				ps.setString(1, useContNum);
			} else if ("20".equals(reqFlag)) {
				ps.setString(1, useContNum);
				// ps.setString(2, accountNum);
				// ps.setString(3, custNum);
			}

			rs = ps.executeQuery();

			// 건수가 있으면 납부통합고객이므로 신청 불가
			if (rs.next()) {
				rValue = 55;// 합산청구세대 신청불가
			} else {
				rValue = 0;// 정상
			}

		} catch (Exception e) {
			log.error(e.getMessage(), e);
			rValue = 99;
		} finally {
			close(rs, ps);
		}
		return rValue;
	}

	public void close(AutoCloseable... oa) {
		if (oa != null)
			for (AutoCloseable o : oa)
				if (o != null)
					try {
						o.close();
					} catch (Exception e) {
						log.error(e.getMessage(), e);
					}
	}
}
