package scg.c24.data.kmc;

import lombok.Data;
import scg.c24.data.CardData;
import tt.io.annotation.AtSize;
import tt.io.annotation.AtUnuse;

@Data
public class KMCData implements CardData {

	public static final int HL = 100;

	@AtUnuse(print = true)
	public String err;

	/** 전문구분코드(4) */
	@AtSize(4)
	public String a01;

	/** 송신기관코드(3) */
	@AtSize(3)
	public String a02;

	/** 수신기관코드(3) */
	@AtSize(3)
	public String a03;

	/** 전문추적번호(20) 요청기관 전문고유번호(해당전문1건에 대한 고유 불변값) */
	@AtSize(20)
	public String a04;

	/** 송신일시(14) yyyyMMddHHmmss */
	@AtSize(14)
	public String a05;

	/** 응답코드(4) 응답기관 처리결과코드 0000=정상, 1111=기등록 */
	@AtSize(4)
	public String a06;

	/** 응답내용(52) 응답기관 처리결과내용 */
	@AtSize(52)
	public String a07;
}
