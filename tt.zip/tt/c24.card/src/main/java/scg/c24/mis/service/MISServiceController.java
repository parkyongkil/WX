package scg.c24.mis.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import scg.c24.mis.data.MIS1000q;
import scg.c24.mis.data.MIS1000r;
import scg.c24.mis.data.MIS2000q;
import scg.c24.mis.data.MIS2000r;
import scg.c24.mis.data.MIS3000q;
import scg.c24.mis.data.MIS3000r;
import scg.c24.mis.data.MIS4000q;
import scg.c24.mis.data.MIS4000r;

@RestController
@RequestMapping("mis")
public class MISServiceController {

	@Autowired
	MISService mis;

	// Server

	/**
	 * 사용계약번호조회 요청 (1000, 8050) (카드사 -> SCGS)
	 */
	@RequestMapping(path = "1000", consumes = { MediaType.APPLICATION_XML_VALUE,
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_XML_VALUE,
					MediaType.APPLICATION_JSON_VALUE })
	public MIS1000r mis1000(MIS1000q q) throws Exception {
		return mis.mis1000(q);
	}

	@RequestMapping(path = "1000", produces = { MediaType.APPLICATION_XML_VALUE })
	public MIS1000r mis1000w(@ModelAttribute MIS1000q q) throws Exception {
		return mis.mis1000(q);
	}

	/**
	 * 자동납부신청등록 요청 (2000, 8150) (카드사 -> SCGS)
	 */
	@RequestMapping(path = "2000", consumes = { MediaType.APPLICATION_XML_VALUE,
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_XML_VALUE,
					MediaType.APPLICATION_JSON_VALUE })
	public MIS2000r mis2000(MIS2000q q) throws Exception {
		return mis.mis2000(q);
	}

	@RequestMapping(path = "2000", produces = { MediaType.APPLICATION_XML_VALUE })
	public MIS2000r mis2000w(MIS2000q q) throws Exception {
		return mis.mis2000(q);
	}

	// Client

	/**
	 * 카드자동납부(신청,변경,해지) 요청 (3000, 9150)
	 */
	@RequestMapping(path = "3000", consumes = { MediaType.APPLICATION_XML_VALUE,
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_XML_VALUE,
					MediaType.APPLICATION_JSON_VALUE })
	public MIS3000r mis3000(MIS3000q q) throws Exception {
		return mis.mis3000(q);
	}

	@RequestMapping(path = "3000", produces = { MediaType.APPLICATION_XML_VALUE })
	public MIS3000r mis3000w(@ModelAttribute MIS3000q q) throws Exception {
		return mis.mis3000(q);
	}

	/**
	 * 카드인증 요청 (4000, 9050)
	 */
	@RequestMapping(path = "4000", consumes = { MediaType.APPLICATION_XML_VALUE,
			MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_XML_VALUE,
					MediaType.APPLICATION_JSON_VALUE })
	public MIS4000r mis4000(MIS4000q q) throws Exception {
		return mis.mis4000(q);
	}

	@RequestMapping(path = "4000", produces = { MediaType.APPLICATION_XML_VALUE })
	public MIS4000r mis4000w(MIS4000q q) throws Exception {
		return mis.mis4000(q);
	}
}
