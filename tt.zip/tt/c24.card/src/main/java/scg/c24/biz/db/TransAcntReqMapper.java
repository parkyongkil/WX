package scg.c24.biz.db;

public class TransAcntReqMapper {

}
