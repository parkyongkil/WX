package scg.c24.data.kmc.batch;

import tt.io.annotation.AtLPad;
import tt.io.annotation.AtSize;

public class KMCBAT0201 implements KMCBAT {

	@AtLPad(value = 8, pad = '0')
	public String SEQ_NUM;

	@AtSize(value = 13, pad = '0')
	public String SOC_NUM;

	@AtSize(30)
	public String CUST_NM;

	@AtSize(4)
	public String CP_DDD;

	@AtSize(4)
	public String CP_EXN;

	@AtSize(4)
	public String CP_NUM;

	@AtSize(4)
	public String OWNHOUSE_TEL_DDD;

	@AtSize(4)
	public String OWNHOUSE_TEL_EXN;

	@AtSize(4)
	public String OWNHOUSE_TEL_NUM;

	@AtSize(4)
	public String SPOUSE_TEL_DDD;

	@AtSize(4)
	public String SPOUSE_TEL_EXN;

	@AtSize(4)
	public String SPOUSE_TEL_NUM;

	@AtSize(30)
	public String SPOUSE_NM;

	@AtSize(16)
	public String REQ_EMPID;

	@AtSize(8)
	public String REQ_YMD;

	@AtSize(20)
	public String USE_CONT_NUM;

	@AtSize(30)
	public String CONT_NM;

	@AtSize(6)
	public String ZIP_NO;

	@AtSize(150)
	public String ADDR1;

	@AtSize(150)
	public String ADDR2;

	@AtSize(2)
	public String REQ_PATH_FLAG;

	@AtSize(88)
	public String CI;

	@AtSize(113)
	public String FILLER;
}
