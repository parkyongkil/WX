package scg.c24.data.kmc.batch;

import lombok.Data;
import lombok.EqualsAndHashCode;
import tt.io.annotation.AtSize;

/** FILE SEND */
@Data
@EqualsAndHashCode(callSuper = true)
public class KMCBAT0101 extends KMCBAT0100 {

	/** MMddHHmmss(10) */
	@AtSize(10)
	public String sndTime;

	/** 001/004(3) */
	@AtSize(3)
	public String manInf;

	/** SCG(20) */
	@AtSize(20)
	public String sendId;

	/** empty(16) */
	@AtSize(16)
	public String sendPw;
}
