package scg.c24.net.client.pool;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.commons.pool2.impl.GenericObjectPoolConfig;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import scg.c24.config.CardConfig;
import scg.c24.net.client.CardClient;
import scg.c24.net.client.CardClientFactory;

@Component
public class CardClientPoolFactory {

	@Autowired
	private CardClientPoolMap cardClientPoolMap;
	private Log log = LogFactory.getLog(getClass());

	public CardClientPool<CardClient> create(CardConfig cardConfig) throws Exception {
		String uid = cardConfig.getUid();
		CardClientPool<CardClient> pool = cardClientPoolMap.remove(uid);
		if (pool != null) {
			pool.close();
			if (log.isInfoEnabled())
				log.info(String.format("%s(%s, %s:%d) Closed.", pool.getClass().getSimpleName(), uid,
						cardConfig.getClient().getHost(), cardConfig.getClient().getPort()));
		}
		CardClientFactory clientFactory = new CardClientFactory(cardConfig);
		GenericObjectPoolConfig poolConfig = cardConfig.getClient().getPool();
		poolConfig.setJmxEnabled(false);
		poolConfig.setTestOnBorrow(true);
		CardClientPooledObjectFactory<CardClient> objectFactory = new CardClientPooledObjectFactory<CardClient>(
				clientFactory);
		cardClientPoolMap.put(uid, pool = new CardClientPool<CardClient>(objectFactory, poolConfig));
		if (log.isInfoEnabled())
			log.info(String.format("%s(%s, %s:%d) Created.", pool.getClass().getSimpleName(), uid,
					cardConfig.getClient().getHost(), cardConfig.getClient().getPort()));
		return pool;
	}
}
