package scg.c24.data.kmc.batch;

import lombok.Data;
import lombok.EqualsAndHashCode;
import tt.io.annotation.AtLPad;

@Data
@EqualsAndHashCode(callSuper = true)
public class KMCBAT0104 extends KMCBAT0100 {

	@AtLPad(value = 4, pad = '0')
	public int blockNo;

	@AtLPad(value = 3, pad = '0')
	public int seqNo;
}
