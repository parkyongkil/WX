package scg.c24.net.server.kmc;

import java.util.ArrayList;
import java.util.Date;

import org.apache.commons.lang3.time.DateFormatUtils;
import org.springframework.stereotype.Service;

import scg.c24.ApplicationContextHolder;
import scg.c24.config.CardConfig;
import scg.c24.data.kmc.KMC1000;
import scg.c24.data.kmc.KMC1000Process;
import scg.c24.data.kmc.KMC2000;
import scg.c24.data.kmc.KMC2000Process;
import scg.c24.data.kmc.KMCData;
import scg.c24.mis.data.MIS1000q;
import scg.c24.mis.data.MIS1000r;
import scg.c24.mis.data.MIS2000q;
import scg.c24.mis.data.MIS2000r;
import scg.c24.net.server.CardServerService;
import scg.c24.util.CardCom;
import tt.lang.string.StringU;

@Service
public class KMCServerService extends CardServerService {

	private KMC1000Process p1000 = ApplicationContextHolder.getBean(KMC1000Process.class);
	private KMC2000Process p2000 = ApplicationContextHolder.getBean(KMC2000Process.class);

	public KMCServerService(CardConfig cardConfig) {
		super(cardConfig);
	}

	@SuppressWarnings("unchecked")
	@Override
	public <Q, R> R call(Q q) throws Exception {

		if (q instanceof KMC1000)
			return (R) call1000((KMC1000) q);
		if (q instanceof KMC2000)
			return (R) call2000((KMC2000) q);

		throw new Exception(String.format("서버에서 처리할 수 없는 전문(%s)입니다.", q == null ? null : q.getClass()));
	}

	@SuppressWarnings("unchecked")
	@Override
	public <Q, R> R callMIS(Q q) throws Exception {
		if (q instanceof MIS1000q)
			return (R) mis1000((MIS1000q) q);
		if (q instanceof MIS2000q)
			return (R) mis2000((MIS2000q) q);
		throw new Exception(String.format("지원하지 않는 구조체(%s)입니다.", q == null ? "X" : q.getClass().getCanonicalName()));
	}

	public KMC1000 call1000(KMC1000 q) throws Exception {
		if (log.isInfoEnabled())
			log.info(
					String.format("\nSQ(%s): %s", q == null ? "X" : q.getClass().getSimpleName(), StringU.toString(q)));
		KMC1000 r = p1000.process(q);
		if (log.isInfoEnabled())
			log.info(
					String.format("\nSR(%s): %s", r == null ? "X" : r.getClass().getSimpleName(), StringU.toString(r)));
		return r;
	}

	public KMC2000 call2000(KMC2000 q) throws Exception {
		if (log.isInfoEnabled())
			log.info(
					String.format("\nSQ(%s): %s", q == null ? "X" : q.getClass().getSimpleName(), StringU.toString(q)));
		KMC2000 r = p2000.process(q);
		if (log.isInfoEnabled())
			log.info(
					String.format("\nSR(%s): %s", r == null ? "X" : r.getClass().getSimpleName(), StringU.toString(r)));
		return r;
	}

	@Override
	public MIS1000r mis1000(MIS1000q mq) throws Exception {
		if (log.isInfoEnabled())
			log.info(String.format("\nMQ(%s): %s", mq == null ? "X" : mq.getClass().getSimpleName(),
					StringU.toString(mq)));
		CardCom c = CardCom.getByBnkCd(mq.CARD_CD);
		KMC1000 q = new KMC1000();
		setRequestHeader(q, c, "1000");
		q.b06 = mq.CUST_NM;
		q.b10 = mq.CUST_CP_DDD;
		q.b11 = mq.CUST_CP_EXN;
		q.b12 = mq.CUST_CP_NUM;
		q.b01 = mq.USE_CONT_NUM;
		KMC1000 r = p1000.process(q);
		MIS1000r mr = new MIS1000r();
		mr.RSLT_CD = r.a06;
		mr.RSLT_NM = r.a07;
		if ("0000".equals(r.a06)) {
			mr.USE_CONTS = new ArrayList<MIS1000r.Cont>(1);
			MIS1000r.Cont a = new MIS1000r.Cont();
			a.USE_CONT_NUM = r.b01;
			a.ADDR = String.format("%s %s", r.b08, r.b09);
			mr.USE_CONTS.add(a);
		}
		if (log.isInfoEnabled())
			log.info(String.format("\nMR(%s): %s", mr == null ? "X" : mr.getClass().getSimpleName(),
					StringU.toString(mr)));
		return mr;
	}

	@Override
	public MIS2000r mis2000(MIS2000q mq) throws Exception {

		if (log.isInfoEnabled())
			log.info(String.format("\nMQ(%s): %s", mq == null ? "X" : mq.getClass().getSimpleName(),
					StringU.toString(mq)));
		CardCom c = CardCom.getByBnkCd(mq.CARD_CD);
		KMC2000 q = new KMC2000();
		setRequestHeader(q, c, "2000");
		q.b01 = mq.TREAT_FLAG;
		q.b02 = mq.USE_CONT_NUM;
		q.b03 = mq.DEFRAY_ACCOUNT_NUM;
		q.b04 = mq.VALID_YM;
		q.b05 = mq.SOC_BIZ_NUM;
		q.b06 = mq.CUST_NM;
		q.b07 = mq.CUST_RELAT_CD;
		q.b08 = mq.REQ_NM;
		q.b09 = mq.REQ_TEL_DDD;
		q.b10 = mq.REQ_TEL_EXN;
		q.b11 = mq.REQ_TEL_NUM;
		q.b12 = null;
		q.b13 = null;
		q.b14 = null;
		q.b15 = mq.ORIG_APPLY_YM;
		q.b16 = mq.CUST_NM;
		q.b17 = mq.ZIP_NO;
		q.b18 = mq.ADDR1;
		q.b19 = mq.ADDR2;
		q.b20 = null;
		q.b21 = null;
		q.b22 = null;
		KMC2000 r = p2000.process(q);
		MIS2000r mr = new MIS2000r();
		mr.RSLT_CD = r.a06;
		mr.RSLT_NM = r.a07;
		mr.CARD_STS_CD = null; // TODO CHECK
		mr.VALID_YM = r.b04;
		mr.JOIN_YN = r.b21;
		if (log.isInfoEnabled())
			log.info(String.format("\nMR(%s): %s", mr == null ? "X" : mr.getClass().getSimpleName(),
					StringU.toString(mr)));
		return mr;
	}

	public static void setRequestHeader(KMCData q, CardCom c, String cd) {
		String cid = c.getCid();
		Date d = new Date();
		String dt = DateFormatUtils.format(d, "yyyyMMddHHmmss");
		String nt = String.format("%06d", System.nanoTime() % 1000000);

		q.a01 = cd;
		q.a02 = "TST";
		q.a03 = cid;
		q.a04 = dt + nt;
		q.a05 = dt;
		q.a06 = "0000";
	}

	public static void setResponseHeader(KMCData q, KMCData r) {
		r.a01 = q.a01.replaceAll("^(.)0", "$11");
		r.a02 = q.a03;
		r.a03 = q.a02;
		r.a04 = q.a04;
		r.a05 = DateFormatUtils.format(new Date(), "yyyyMMddHHmmss");
		r.a06 = "0000";
		r.a07 = "정상";
	}
}
