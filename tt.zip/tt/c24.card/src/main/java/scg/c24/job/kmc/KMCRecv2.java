package scg.c24.job.kmc;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import scg.c24.ApplicationContextHolder;
import scg.c24.config.CardConfig;
import scg.c24.job.CardJob;
import scg.c24.net.server.kmc.batch.KMCCardRecev;

public class KMCRecv2 implements CardJob {

	private CardConfig cardConfig2 = ApplicationContextHolder.getBean("cardConfig2", CardConfig.class);
	private Log log = LogFactory.getLog(getClass());

	private String fileName;

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	@Override
	public void run() {
		try {
			if (StringUtils.isBlank(fileName))
				throw new Exception("파일이름(fileName)을 입력하지 않으셨습니다.");
			KMCCardRecev rec = new KMCCardRecev(cardConfig2, fileName);
			rec.run();
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
	}

	@Override
	public void close() {
		// NOTHING
	}
}
