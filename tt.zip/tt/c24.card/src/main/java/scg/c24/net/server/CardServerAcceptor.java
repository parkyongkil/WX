package scg.c24.net.server;

import java.net.Socket;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import scg.c24.ApplicationContextHolder;
import scg.c24.config.CardConfig;

public abstract class CardServerAcceptor extends Thread {

	protected CardServerServiceFactory serviceFactory = ApplicationContextHolder
			.getBean(CardServerServiceFactory.class);
	protected CardConfig cardConfig;
	protected CardServerService service;
	protected Socket socket;
	protected Log log = LogFactory.getLog(getClass());

	public CardServerAcceptor(CardConfig cardConfig, CardServerService service, Socket socket) {
		super();
		this.cardConfig = cardConfig;
		this.service = service;
		this.socket = socket;
		if (log.isInfoEnabled())
			log.info(String.format("%s(%s, %s) Created.", getClass().getSimpleName(), cardConfig.getUid(),
					socket.getRemoteSocketAddress().toString()));
	}

	public void close() {
		try {
			if (socket != null) {
				if (log.isInfoEnabled())
					log.info(String.format("%s(%s, %s) Closed.", getClass().getSimpleName(), cardConfig.getUid(),
							socket.getRemoteSocketAddress().toString()));
				socket.close();
				socket = null;
			}
		} catch (Exception e) {
			if (log.isErrorEnabled())
				log.error(e.getMessage(), e);
		}
	}
}
