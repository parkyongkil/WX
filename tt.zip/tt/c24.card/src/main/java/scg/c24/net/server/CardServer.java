package scg.c24.net.server;

import java.io.Closeable;
import java.net.ServerSocket;
import java.net.Socket;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import scg.c24.ApplicationContextHolder;
import scg.c24.config.CardConfig;
import scg.c24.config.CardServerConfig;

public class CardServer extends Thread implements Closeable {

	private CardServerAcceptorFactory acceptorFactory = ApplicationContextHolder
			.getBean(CardServerAcceptorFactory.class);
	// private CardDataTransferFactory transferFactory =
	// ApplicationContextHolder.getBean(CardDataTransferFactory.class);
	private CardServerServiceFactory serviceFactory = ApplicationContextHolder.getBean(CardServerServiceFactory.class);

	protected CardServerService service;
	protected CardConfig cardConfig;
	protected ServerSocket serverSocket;
	protected ThreadGroup tgCh = new ThreadGroup(CardServerAcceptor.class.getSimpleName());
	protected Log log = LogFactory.getLog(getClass());

	public CardServer(CardConfig cardConfig) throws Exception {
		super();

		this.cardConfig = cardConfig;
		this.setDaemon(true);
		this.setName(String.format("%s(%s)", getClass().getSimpleName(), cardConfig.getServer().getPort()));
		this.service = serviceFactory.create(cardConfig);
	}

	protected void open() throws Exception {
		CardServerConfig sf = cardConfig.getServer();
		serverSocket = new ServerSocket(sf.getPort());
		Runtime.getRuntime().addShutdownHook(new Thread() {
			@Override
			public void run() {
				if (log.isInfoEnabled())
					log.info(String.format("CardServer(%s, %d) Shutdown.", cardConfig.getUid(),
							cardConfig.getClient().getPort()));
				close();
			}
		});
		if (log.isInfoEnabled())
			log.info(String.format("CardServer(%s, %d) Created.", cardConfig.getUid(), sf.getPort()));
	}

	public void close() {
		try {
			tgCh.interrupt();
			if (serverSocket != null) {
				serverSocket.close();
				serverSocket = null;
				if (log.isInfoEnabled())
					log.info(String.format("CardServer(%s, %d) Closed.", cardConfig.getCid(),
							cardConfig.getServer().getPort()));
			}
		} catch (Exception e) {
			if (log.isErrorEnabled())
				log.error(e.getMessage(), e);
		}
	}

	@Override
	public void run() {
		try {
			open();
			int x = 20;
			while (!isInterrupted() && serverSocket != null && !serverSocket.isClosed()) {
				Socket socket = serverSocket.accept();
				if (tgCh.activeCount() > x) {
					if (log.isInfoEnabled())
						log.info(String.format("클라이언트 과다접속(%d건)으로 인하여 새로 접속한 클라이언트(%s)를 종료합니다.", x,
								socket.getInetAddress().toString()));
					socket.close();
				} else {
					socket.setSoTimeout(cardConfig.getClient().getTimeout());
					CardServerAcceptor acceptor = acceptorFactory.create(cardConfig, service, socket);
					Thread t = new Thread(tgCh, acceptor);
					t.start();
				}
			}
		} catch (Exception e) {
			if (log.isErrorEnabled())
				log.error(e.getMessage(), e);
		}
		close();
	}
}
