package scg.c24.data.shc;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import scg.c24.biz.db.shc.model.SHCUseCont;
import scg.c24.biz.db.shc.model.SHCUseContMapper;
import scg.c24.net.process.CardProcess;
import scg.c24.net.server.shc.SHCServerService;
import scg.c24.util.CardCom;

@Component
public class SHC8050Process implements CardProcess<SHC8050, SHC8050> {

	@Autowired
	SHCUseContMapper mUseContMapper;

	@Override
	public SHC8050 process(SHC8050 q) throws Exception {

		if (mUseContMapper == null)
			throw new Exception("mUseContMapper is null");

		SHC8050 r = new SHC8050();
		SHCServerService.setResponseHeader(q, r);
		CardCom c = CardCom.getByCardCid(q.a03);

		List<SHCUseCont> ul = StringUtils.isBlank(q.getB05())
				? mUseContMapper.selectUseContByUseCustNmCp(q.b01, q.b02, q.b03, q.b04, c.getBnkCd())
				: mUseContMapper.selectUseContByUseContNum(q.b05, c.getBnkCd());
		int n = ul == null ? 0 : ul.size();
		if (n == 0) {
			r.a08 = "81"; // 0건 오류
			r.b06 = 0;
			r.err = "(1081)조회결과 0건 오류";
		} else if (n > 5) {
			r.a08 = "82"; // 5건 초과 오류, 83 = 10건 초과 오류
			r.b06 = 0;
			r.err = String.format("(1088)조회결과 5건 초과 오류(총%d건)", n);
		} else {
			r.a08 = "00"; // 성공
			SHCUseCont a = ul.get(0);
			r.b01 = a.getCUST_NM();
			r.b02 = a.getCP_DDD();
			r.b03 = a.getCP_EXN();
			r.b04 = a.getCP_NUM();
			r.b05 = a.getUSE_CONT_NUM();
			r.b06 = n;
			r.b07 = new ArrayList<>(n);
			for (SHCUseCont u : ul) {
				SHC8050.Cont b = new SHC8050.Cont();
				b.c01 = u.getUSE_CONT_NUM();
				String t1 = q.a03.equals(CardCom.SSC) ? u.getNEW_ADDR_UNION() + u.getPAY_METHOD_NM()
						: u.getNEW_ADDR_UNION();
				b.c02 = StringUtils.isNotBlank(t1) ? t1 : u.getCURR_ADDR_UNION();
				r.b07.add(b);
			}
		}

		return r;
	}
}
