package scg.c24.data.kmc;

import lombok.Data;
import lombok.EqualsAndHashCode;
import tt.io.annotation.AtSize;

/**
 * @제목 카드인증 요청 (4000, 9050)
 * 
 * @요청 서울도시가스
 * @응답 국민카드
 */

@Data
@EqualsAndHashCode(callSuper = true)
public class KMC4000 extends KMCData {

	/** 카드번호(16) */
	@AtSize(16)
	public String b01;

	/** 카드고객 주민번호(13) 199012310000000 */
	@AtSize(13)
	public String b02;

	/** CI(88) */
	@AtSize(88)
	public String b06;
}
