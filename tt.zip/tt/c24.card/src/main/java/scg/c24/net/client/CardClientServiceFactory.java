package scg.c24.net.client;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import scg.c24.config.CardConfig;
import scg.c24.net.client.pool.CardClientPool;

@Component
public class CardClientServiceFactory {

	@Autowired
	private CardClientServiceMap serviceMap;

	public CardClientService<? extends CardClient> create(CardConfig cardConfig,
			CardClientPool<? extends CardClient> pool) throws Exception {
		CardClientService<? extends CardClient> service = cardConfig.getClient().getServiceType()
				.getConstructor(CardConfig.class, CardClientPool.class).newInstance(cardConfig, pool);
		serviceMap.put(cardConfig.getUid(), service);
		return service;
	}
}
