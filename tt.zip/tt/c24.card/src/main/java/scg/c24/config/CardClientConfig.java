package scg.c24.config;

import org.apache.commons.pool2.impl.GenericObjectPoolConfig;

import lombok.Data;
import scg.c24.net.client.CardClient;
import scg.c24.net.client.CardClientService;

@Data
public class CardClientConfig {

	private String host;
	private int port;
	private int timeout;
	private Class<CardClientService<? extends CardClient>> serviceType;
	private Class<? extends CardClient> clientType;
	private GenericObjectPoolConfig pool;
}
