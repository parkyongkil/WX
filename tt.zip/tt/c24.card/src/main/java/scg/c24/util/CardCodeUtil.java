package scg.c24.util;

import java.util.HashMap;

import org.apache.commons.lang3.StringUtils;

public class CardCodeUtil {

	private static HashMap<String, String> M1 = new HashMap<>();
	private static HashMap<String, String> M2 = new HashMap<>();
	static {
		M1.put("01", "10");
		M1.put("02", "11");
		M1.put("03", "13");
		M1.put("04", "21");
		M1.put("05", "12");
		M1.put("06", "12");
		M1.put("07", "14");
		M1.put("09", "16");

		M2.put("10", "01");
		M2.put("11", "02");
		M2.put("12", "05");
		M2.put("13", "03");
		M2.put("14", "07");
		M2.put("16", "09");
		M2.put("21", "04");
		M2.put("22", "04");
	}

	public static String DECODE_RELAT_CD_SCGS(String s) {
		return StringUtils.isBlank(s) ? "  " : M1.containsKey(s) ? M1.get(s) : "16";
	}

	public static String DECODE_RELAT_CD_CARD(String s) {
		return StringUtils.isBlank(s) ? "  " : M2.containsKey(s) ? M2.get(s) : "09";
	}

	public static String DECODE_TRAN_FLAG(String s) {
		return "20".equals(s) ? "10" : "30".equals(s) ? "20" : "  ";
	}

	public static String DECODE_RECEIVE_PLC_FLAG_CD(String s) {
		return "5".equals(s) ? "5" : "6".equals(s) ? "4" : " ";
	}

	public static String DECODE_RECEIVE_STS_CD(String s) {
		return "20".equals(s) ? "10" : "30".equals(s) ? "20" : null;
	}

	public static String DECODE_RES_RSLT_CD(String s) {
		return "20".equals(s) ? "10" : "30".equals(s) ? "30" : null;
	}

	public static String DECODE_USE_CONT_TRANS_RECEIVE_CD(String s) {
		return "20".equals(s) ? "10" : "20";
	}

	public static String DECODE_RES_RSLT_CD_FOR_CANCEL(String s) {
		return "10".equals(s) ? "10" : "20".equals(s) ? "30" : null;
	}

	public static String CL() {
		StackTraceElement e = Thread.currentThread().getStackTrace()[2];
		return String.format("%s.%s(%s)", e.getClassName(), e.getMethodName(), e.getLineNumber());
	}

}
