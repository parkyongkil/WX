package scg.c24.data.kmc.batch;

import tt.io.annotation.AtLPad;
import tt.io.annotation.AtSize;

public class KMCBAT0301 implements KMCBAT {

	@AtLPad(value = 8, pad = '0')
	public String SEQ;

	@AtSize(20)
	public String REQ_INFO_NUM;

	@AtSize(16)
	public String DEFRAY_ACCOUNT_NUM;

	@AtSize(value = 13, pad = '0')
	public String SOC_BIZ_NUM;

	@AtSize(30)
	public String DEPOSITOR_NM;

	@AtSize(2)
	public String CUST_RELAT_CD;

	@AtSize(1)
	public String REQ_PATH;

	@AtSize(2)
	public String RECEIVE_STS_CD;

	@AtSize(30)
	public String REQ_NM;

	@AtSize(4)
	public String REQ_TEL_DDD;

	@AtSize(4)
	public String REQ_TEL_EXN;

	@AtSize(4)
	public String REQ_TEL_NUM;

	@AtSize(4)
	public String DEPOSITOR_TEL_DDD;

	@AtSize(4)
	public String DEPOSITOR_TEL_EXN;

	@AtSize(4)
	public String DEPOSITOR_TEL_NUM;

	@AtSize(8)
	public String ORIG_APPLY_YM;

	@AtSize(30)
	public String CUST_NM;

	@AtSize(6)
	public String ZIP_NO;

	@AtSize(150)
	public String ADDR1;

	@AtSize(150)
	public String ADDR2;

	@AtSize(88)
	public String CI;

	@AtSize(122)
	public String FILLER;
}
