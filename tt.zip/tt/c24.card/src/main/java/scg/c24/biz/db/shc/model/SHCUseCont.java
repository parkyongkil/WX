package scg.c24.biz.db.shc.model;

import lombok.Data;

@Data
public class SHCUseCont {

	String CUST_NM;

	String CP_DDD;

	String CP_EXN;

	String CP_NUM;

	String USE_CONT_NUM;

	String NEW_ADDR_UNION;

	String PAY_METHOD_NM;

	String CURR_ADDR_UNION;
}