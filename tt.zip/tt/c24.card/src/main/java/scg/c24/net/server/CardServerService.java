package scg.c24.net.server;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import scg.c24.config.CardConfig;
import scg.c24.mis.data.MIS1000q;
import scg.c24.mis.data.MIS1000r;
import scg.c24.mis.data.MIS2000q;
import scg.c24.mis.data.MIS2000r;

public abstract class CardServerService {

	protected CardConfig cardConfig;
	protected Log log = LogFactory.getLog(getClass());

	public CardServerService(CardConfig cardConfig) {
		super();
		this.cardConfig = cardConfig;
	}

	public abstract <Q, R> R call(Q q) throws Exception;

	public abstract <Q, R> R callMIS(Q q) throws Exception;

	/**
	 * 카드자동납부신청 요청 (3000, 9150)
	 */
	public abstract MIS1000r mis1000(MIS1000q mq) throws Exception;

	/**
	 * 카드인증조회 요청 (4000, 9050)
	 */
	public abstract MIS2000r mis2000(MIS2000q mq) throws Exception;
}
