package scg.c24.job;

import scg.c24.config.CardConfig;

public class TestJob implements CardJob {

	CardConfig cardConfig;

	public TestJob(CardConfig cardConfig) {
		super();
		this.cardConfig = cardConfig;
	}

	@Override
	public void run() {
		System.out.println(String.format("CardConfig = %s", cardConfig));
	}

	@Override
	public void close() {
		Thread.currentThread().interrupt();
	}
}
