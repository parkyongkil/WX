package scg.c24.data.shc;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.springframework.stereotype.Component;

import scg.c24.biz.db.TransAcntCnl;
import scg.c24.biz.db.TransAcntReq;
import scg.c24.net.process.CardProcess;
import scg.c24.net.server.shc.SHCServerService;
import scg.c24.util.CardCom;

@Component
public class SHC8150Process implements CardProcess<SHC8150, SHC8150> {

	@Override
	public SHC8150 process(SHC8150 q) throws Exception {
		int n = NumberUtils.toInt(q.b01);
		CardCom c = CardCom.getByCardCid(q.a03);

		TransAcntReq t1 = null;
		int t = 0;
		switch (n) {
		case 1:
		case 2:
			t1 = new TransAcntReq(q.b02, c.getBnkCd(), q.b12, q.b15, q.b05, q.b04, q.b10, q.b11, q.b06, q.b07, q.b08,
					null, null, null, "30", "6", null, null, " ");
			t1.start();
			break;
		case 3:
			t = new TransAcntCnl(q.b12, "10", q.b11, q.b05, q.b10, q.b06, q.b07, q.b08, "1", "N", "6", null, false,
					null, null).start();
			break;
		default:
			throw new Exception(String.format("처리할 수 없는 요청구분코드(%s)입니다.", q.b01));
		}
		SHC8150 r = new SHC8150();
		SHCServerService.setResponseHeader(q, r);
		switch (t) {
		case 0:
			r.a08 = "00";
			r.err = "정상";
			r.b14 = t1 == null ? r.b14 : StringUtils.substring(t1.getApplyYmd(), 0, 6);
			break;
		case 10:
			r.a08 = "52";
			r.err = "사용계약번호 없음";
			break;
		case 20:
			r.a08 = "14";
			r.err = "계약상태 확인 오류";
			break;
		case 30:
			r.a08 = "19";
			r.err = "이미 신청한 카드 존재";
			break;
		case 40:
			r.a08 = "51";
			r.err = "임시고객번호 오류";
			break;
		case 50:
			r.a08 = "50";
			r.err = "납부방법 오류(해지시)";
			break;
		case 55:
			r.a08 = "55";
			r.err = "합산청구세대 신청불가";
			break;
		case 98:
			r.a08 = "25";
			r.err = "결제신청정보 등록 오류";
			break;
		default:
			r.a08 = "10";
			r.err = "내부시스템 업무 지연 ( DB접속 오류 )";
			break;
		}
		return r;
	}
}
