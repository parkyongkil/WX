package scg.c24.mis.data;

import scg.c24.data.CardData;

public interface MISData extends CardData {

}
