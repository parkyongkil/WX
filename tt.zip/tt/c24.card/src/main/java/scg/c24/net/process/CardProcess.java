package scg.c24.net.process;

public interface CardProcess<Q, R> {

	R process(Q q) throws Exception;
}
