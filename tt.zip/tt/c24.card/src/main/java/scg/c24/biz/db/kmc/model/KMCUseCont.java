package scg.c24.biz.db.kmc.model;

import lombok.Data;

@Data
public class KMCUseCont {

	String CONT_STS;

	String PAY_METHOD_CD;

	String BNK_NM;

	String FIRST_YMD;

	String CUST_NM;

	String ZIP_NO;

	String ADDR1;

	String ADDR2;

	String USE_CONT_NUM;

	String CP_DDD;

	String CP_EXN;

	String CP_NUM;

	String JOIN_YN;
}