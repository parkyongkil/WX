package scg.c24.mis.data;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @제목 사용계약번호조회 요청 (1000, 8050)
 */

@Data
@EqualsAndHashCode(callSuper = true)
@XmlRootElement(name = "SCGM")
@XmlAccessorType(XmlAccessType.FIELD)
public class MIS1000q extends MISq {

	public String USE_CONT_NUM;

	public String CUST_NM;

	public String CUST_CP_DDD;

	public String CUST_CP_EXN;

	public String CUST_CP_NUM;
}
