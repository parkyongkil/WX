package scg.c24.data.kmc.batch;

import scg.c24.data.CardData;

public interface KMCBAT extends CardData {

}
