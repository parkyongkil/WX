package scg.c24.net.server;

import java.util.HashMap;

import org.springframework.stereotype.Component;

@Component
public class CardServerMap extends HashMap<String, CardServer> {

}
