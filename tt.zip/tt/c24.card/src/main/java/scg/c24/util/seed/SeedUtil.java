package scg.c24.util.seed;

import java.nio.charset.Charset;
import java.util.HashMap;
import java.util.Properties;

import org.apache.commons.lang3.StringUtils;
import org.springframework.boot.context.properties.ConfigurationProperties;

import scg.c24.util.CardCom;

@ConfigurationProperties
public class SeedUtil {

	private static Properties p = new Properties();
	private static final HashMap<String, byte[]> KEY_MAP = new HashMap<>();
	private static Charset charset;
	static {
		try {
			p.load(SeedUtil.class.getResourceAsStream("/application.properties"));
		} catch (Exception e) {
			e.printStackTrace(System.err);
			Runtime.getRuntime().exit(1);
		}
		String seedkey = p.getProperty("card.seedkey");
		charset = Charset.forName(p.getProperty("card.charset"));

		System.err.println(String.format("%s.mode = [%s]", SeedUtil.class.getCanonicalName(), seedkey));

		if ("PROD".equals(seedkey)) {
			KEY_MAP.put(CardCom.SSC,
					new byte[] { (byte) 0x65, (byte) 0x68, (byte) 0x74, (byte) 0x6C, (byte) 0x72, (byte) 0x6B,
							(byte) 0x74, (byte) 0x6D, (byte) 0x74, (byte) 0x6AF, (byte) 0x64, (byte) 0x6E, (byte) 0x66,
							(byte) 0x31, (byte) 0x31, (byte) 0x21 });

			KEY_MAP.put(CardCom.SHC,
					new byte[] { (byte) 0x86, (byte) 0x34, (byte) 0xef, (byte) 0x8c, (byte) 0x22, (byte) 0x63,
							(byte) 0xed, (byte) 0x30, (byte) 0x02, (byte) 0x41, (byte) 0xaf, (byte) 0x70, (byte) 0x16,
							(byte) 0xd1, (byte) 0x05, (byte) 0x81 });
		} else {
			// TEST
			KEY_MAP.put(CardCom.SSC,
					new byte[] { (byte) 0x31, (byte) 0x32, (byte) 0x33, (byte) 0x34, (byte) 0x35, (byte) 0x36,
							(byte) 0x37, (byte) 0x38, (byte) 0x39, (byte) 0x30, (byte) 0x61, (byte) 0x62, (byte) 0x63,
							(byte) 0x64, (byte) 0x65, (byte) 0x66 });

			KEY_MAP.put(CardCom.SHC,
					new byte[] { (byte) 0x86, (byte) 0x34, (byte) 0xef, (byte) 0x8c, (byte) 0x22, (byte) 0x63,
							(byte) 0xed, (byte) 0x30, (byte) 0x02, (byte) 0x41, (byte) 0xaf, (byte) 0x70, (byte) 0x16,
							(byte) 0xd1, (byte) 0x05, (byte) 0x81 });
		}
	}

	public static String encrypt(String cid, String s) {
		return Seed.GetSeedEncrypt(getKey(cid), StringUtils.rightPad(s == null ? "" : s, 16, ' '), getCharset(cid));
	}

	public static String decrypt(String cid, String s) throws Exception {
		return Seed.GetSeedDecrypt(getKey(cid), StringUtils.rightPad(s == null ? "" : s, 32, '0'), getCharset(cid))
				.trim();
	}

	private static byte[] getKey(String cid) {
		return KEY_MAP.get(cid);
	}

	private static Charset getCharset(String cid) {
		return charset;
	}
}
