package scg.c24.job.kmc;

import java.io.File;
import java.io.FileOutputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;

import javax.sql.DataSource;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.BeanUtils;

import scg.c24.ApplicationContextHolder;
import scg.c24.config.CardConfig;
import scg.c24.data.kmc.batch.KMCBAT0201;
import scg.c24.job.CardJob;
import scg.c24.net.client.kmc.batch.KMCBatchClient;
import scg.c24.util.CardSysUtil;
import tt.io.TDataOutputStream;

public class KMCReqDoc implements CardJob {

	public static final int CURSOR = -10;

	private DataSource dataSource;
	private CardConfig cardConfig2;

	private Log log = LogFactory.getLog(getClass());

	private static final int MSG_LEN = 700; // 황정현 수정 600 -> 700

	public KMCReqDoc() {
		super();
		Runtime.getRuntime().addShutdownHook(new Thread() {
			@Override
			public void run() {
				close();
			}
		});
		this.dataSource = ApplicationContextHolder.getBean(DataSource.class);
		this.cardConfig2 = ApplicationContextHolder.getBean("cardConfig2", CardConfig.class);
	}

	@Override
	public void run() {
		try {
			process();
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
	}

	@Override
	public void close() {
		// NOTHING
	}

	public void process() throws Exception {
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		FileOutputStream fos = null;
		String strYmd = new SimpleDateFormat("yyyyMMdd").format(new Date());
		String sendPath = String.format("%s/%s/sendFile/", cardConfig2.getFilePath(), cardConfig2.getUid());
		String fileNm = null;
		try {
			fileNm = "TM00" + new SimpleDateFormat("MMdd").format(new Date());
			File f1 = new File(sendPath, CardSysUtil.toKMCDatePath(fileNm));
			f1.getParentFile().mkdirs();

			fos = new FileOutputStream(f1, false);
			TDataOutputStream tdos = new TDataOutputStream(fos, cardConfig2.getCharset());

			conn = dataSource.getConnection();

			ps = conn.prepareStatement(sqlSelect);
			rs = ps.executeQuery();
			ps.close();

			int count = 0;
			String header = StringUtils.leftPad("0", 8, '0') + strYmd;
			tdos.writeNString(MSG_LEN, header);

			ps = conn.prepareStatement(sqlUpdate);

			ResultSetMetaData md = rs.getMetaData();
			int nz = md.getColumnCount();
			String[] ns = new String[nz];
			for (int i = 0; i < nz; i++)
				ns[i] = md.getColumnName(i + 1);
			while (rs.next()) {
				count++;
				HashMap<String, String> m = new HashMap<>();
				for (int i = 0; i < nz; i++)
					m.put(ns[i], rs.getString(i + 1));
				m.put("SEQ_NUM", String.valueOf(count));
				KMCBAT0201 kb1 = new KMCBAT0201();
				BeanUtils.copyProperties(m, kb1);
				tdos.writeObject(kb1);
				boolean isSend = true;
				ps.setString(1, isSend ? "2" : "9");
				ps.setString(2, rs.getString("JOB_YMD"));
				ps.setString(3, rs.getString("SEQ"));
				ps.executeUpdate();
			}
			String tail = "99999999" + StringUtils.leftPad(Integer.toString(count), 8, '0');
			tdos.writeNString(MSG_LEN, tail);
			tdos.close();
			ps.close();
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		} finally {
			try {
				if (fos != null)
					fos.close();
			} catch (Exception e) {
				log.error(e.getMessage(), e);
			}
			try {
				if (rs != null)
					rs.close();
			} catch (Exception e) {
				log.error(e.getMessage(), e);
			}
			try {
				if (ps != null)
					ps.close();
			} catch (Exception e) {
				log.error(e.getMessage(), e);
			}
			try {
				if (conn != null)
					conn.close();
			} catch (Exception e) {
				log.error(e.getMessage(), e);
			}
		}

		KMCBatchClient KBBC = new KMCBatchClient(cardConfig2, fileNm);
		if (KBBC.start()) {
			log.info("fileSend Complete!");
		} else {
			log.error("fileSend Error!!!!");
		}
	}

	// @formatter:off
	private final static String sqlSelect = 
		"SELECT rownum " +
		"     , JOB_YMD " +
		"     , SEQ " +
		"     , SOC_NUM " +
		"     , CUST_NM " +
		"     , CP_DDD " +
		"     , CP_EXN " +
		"     , CP_NUM " +
		"     , OWNHOUSE_TEL_DDD " +
		"     , OWNHOUSE_TEL_EXN " +
		"     , OWNHOUSE_TEL_NUM " +
		"     , SPOUSE_TEL_DDD " +
		"     , SPOUSE_TEL_EXN " +
		"     , SPOUSE_TEL_NUM " +
		"     , SPOUSE_NM " +
		"     , REQ_EMPID || REQ_COM_ID || REQ_TYPE_CD REQ_EMPID " +
		"     , REQ_YMD " +
		"     , USE_CONT_NUM " +
		"     , (SELECT CUST_NM " +
		"          FROM C11.C1BT_USE_CONT X " +
		"             , C11.C1AT_CUST_INFO Y " +
		"         WHERE X.USE_CONT_NUM = A.USE_CONT_NUM " +
		"           AND X.CUST_NUM = Y.CUST_NUM) CONT_NM " +
		"     , ZIP_NO1 || ZIP_NO2 ZIP_NO " +
		"     , ADDR1 " +
		"     , ADDR2 " +
		"     , REQ_PATH_FLAG " +
		"     , (SELECT NVL(CI_NUM, '') FROM C11.C1AT_CERT_MST WHERE CERT_MANAGE_FLAG = '40' AND CERT_MANAGE_NUM  = A.SOC_NUM)  CI_NUM  " +
		"  FROM C11.C1BT_CARD_REQ_DOC A " +
		" WHERE REQ_DOC_FLAG = '20' " +
		"   AND SEND_STS = '1' " +
		" ORDER BY JOB_YMD, SEQ ";
			
	private final static String sqlUpdate = 
		"UPDATE C11.C1BT_CARD_REQ_DOC " +
		"   SET UPD_DTM = sysdate " +
		"     , UPD_EMPID = 'SYSTEM' " +
		"     , UPD_IP = '**.**.**.**' " +
		"     , SEND_DTM = sysdate " +
		"     , SEND_STS = ? " +
		" WHERE JOB_YMD = ? " +
		"   AND SEQ = ? ";
	// @formatter:on
}
