package scg.c24.net.server;

import java.net.Socket;
import java.util.LinkedList;
import java.util.Queue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import scg.c24.config.CardConfig;
import scg.c24.data.CardData;
import scg.c24.data.CardDataRemote;
import scg.c24.net.transfer.CardDataTransfer;
import scg.c24.net.transfer.CardDataTransferFactory;
import tt.io.TDataInputStream;
import tt.lang.string.StringU;

public class GeneralCardServerAcceptor extends CardServerAcceptor {

	protected Queue<byte[]> iqueue = new LinkedList<>();
	protected CardDataTransfer<CardData> transfer;
	protected ExecutorService executor;
	protected Sender sender;

	public GeneralCardServerAcceptor(CardConfig cardConfig, CardServerService service, Socket socket) throws Exception {
		super(cardConfig, service, socket);
	}

	@Override
	public void run() {
		try {
			transfer = CardDataTransferFactory.create(cardConfig, socket, true);
			executor = Executors.newSingleThreadExecutor();
			executor.execute(sender = new Sender());

			TDataInputStream in = this.transfer.getInputStream();

			while (!interrupted() && socket != null && !socket.isClosed() && in.available() != -1) {
				while (in.available() > 0) {
					try {
						byte[] b = transfer.read();
						if (b != null)
							iqueue.offer(b);
						if (log.isDebugEnabled())
							log.debug(String.format("QUEUE.OFFR, SIZE(%d)", iqueue.size()));
					} catch (Exception e) {
						if (log.isErrorEnabled())
							log.error(e.getMessage(), e);
					}
				}
			}
		} catch (Exception e) {
			if (log.isErrorEnabled())
				log.error(e.getMessage(), e);
		}
		close();
	}

	@Override
	public void close() {
		if (sender != null)
			sender.run = false;
		if (executor != null)
			executor.shutdown();
		super.close();
	}

	class Sender implements Runnable {

		boolean run = false;

		@Override
		public void run() {
			run = true;
			while (run) {
				try {
					if (iqueue.size() > 0)
						send(iqueue.poll());
					sleep(1000);
				} catch (Exception e) {
					log.error(e.getMessage(), e);
				}
			}
		}

		public void send(byte[] b) throws Exception {
			if (b != null) {
				CardData q = transfer.toObject(b);

				if (q instanceof CardDataRemote)
					((CardDataRemote) q).toSCGS();

				if (log.isInfoEnabled())
					log.info(String.format("\nAQ:%s", StringU.toString(q)));

				CardData r = service.call(q);

				if (r instanceof CardDataRemote)
					((CardDataRemote) r).toCARD();

				if (log.isInfoEnabled())
					log.info(String.format("\nAR:%s", StringU.toString(r)));

				transfer.writeObject(r);
			}
		}
	}
}
