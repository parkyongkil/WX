package scg.c24.mis.data;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import lombok.Data;

@Data
@XmlRootElement(name = "SCGM")
@XmlAccessorType(XmlAccessType.FIELD)
public abstract class MISr implements MISData {

	/** 0000=정상 */
	public String RSLT_CD;

	/** 처리결과 및 오류내용 */
	public String RSLT_NM;
}
