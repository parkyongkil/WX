package scg.c24.net.client.pool;

import java.io.Closeable;

import org.apache.commons.pool2.PooledObjectFactory;
import org.apache.commons.pool2.impl.AbandonedConfig;
import org.apache.commons.pool2.impl.GenericObjectPool;
import org.apache.commons.pool2.impl.GenericObjectPoolConfig;

import scg.c24.net.client.CardClient;

public class CardClientPool<T extends CardClient> extends GenericObjectPool<T> implements Closeable {

	public CardClientPool(PooledObjectFactory<T> factory, GenericObjectPoolConfig config,
			AbandonedConfig abandonedConfig) {
		super(factory, config, abandonedConfig);
	}

	public CardClientPool(PooledObjectFactory<T> factory, GenericObjectPoolConfig config) {
		super(factory, config);
	}

	public CardClientPool(PooledObjectFactory<T> factory) {
		super(factory);
	}
}
