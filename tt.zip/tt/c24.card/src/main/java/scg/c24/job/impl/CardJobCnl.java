package scg.c24.job.impl;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import oracle.jdbc.OracleCallableStatement;
import scg.c24.ApplicationContextHolder;
import scg.c24.config.CardConfig;
import scg.c24.data.kmc.KMC3000;
import scg.c24.data.shc.SHC9150;
import scg.c24.job.CardJob;
import scg.c24.mis.data.MIS3000q;
import scg.c24.mis.data.MIS3000r;
import scg.c24.mis.service.MISService;
import scg.c24.net.client.kmc.KMCClientService;
import scg.c24.net.client.shc.SHCClientService;
import scg.c24.util.CardCom;
import tt.lang.string.StringU;

@SuppressWarnings({ "rawtypes", "unchecked" })
public class CardJobCnl implements CardJob {

	public static final int CURSOR = -10;

	private DataSource dataSource;
	private MISService mis;
	private CardConfig cardConfig;

	private CardCom cardCom;
	private String bnkCd;

	String mode;
	String spCnt;
	String cnlYmd;
	String treatYmd;

	private Log log = LogFactory.getLog(getClass());

	public CardJobCnl() {
		super();
		Runtime.getRuntime().addShutdownHook(new Thread() {
			@Override
			public void run() {
				close();
			}
		});
		this.dataSource = ApplicationContextHolder.getBean(DataSource.class);
		this.mis = ApplicationContextHolder.getBean(MISService.class);
		this.cardConfig = ApplicationContextHolder.getBean(CardConfig.class);
		this.cardCom = CardCom.getByCardCid(cardConfig.getCid());
		this.bnkCd = cardCom.getBnkCd();
	}

	public String getMode() {
		return mode;
	}

	public void setMode(String mode) {
		this.mode = mode;
	}

	public String getSpCnt() {
		return spCnt;
	}

	public void setSpCnt(String spCnt) {
		this.spCnt = spCnt;
	}

	public String getCnlYmd() {
		return cnlYmd;
	}

	public void setCnlYmd(String cnlYmd) {
		this.cnlYmd = cnlYmd;
	}

	public String getTreatYmd() {
		return treatYmd;
	}

	public void setTreatYmd(String treatYmd) {
		this.treatYmd = treatYmd;
	}

	@Override
	public void run() {
		long start = System.currentTimeMillis();
		log.info(String.format("Job Started(%s)", getClass().getSimpleName()));
		try {
			autoTransCnlSend(this.mode, this.spCnt, this.cnlYmd, this.treatYmd);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
		long end = System.currentTimeMillis();
		log.info(String.format("Job Ended(%s) 소요시간: %s", getClass().getSimpleName(), (end - start) / 1000.0f + "초"));
	}

	public String autoTransCnlSend(String mode, String spCnt, String cnlYmd, String treatYmd) throws Exception {
		// Mode - 처리모드 N:정상, E:에러건처리
		// SpCnt - 특정에러건처리여부 0:에러중 특정건 재수행,1:미처리건 재수행,2:에러,미처리 일괄 재수행

		if (StringUtils.isBlank(mode))
			mode = "N";
		if (StringUtils.isBlank(spCnt))
			spCnt = "0";

		Date date = new Date();

		if (StringUtils.isBlank(cnlYmd))
			cnlYmd = DateFormatUtils.format(DateUtils.addDays(date, -1), "yyyyMMdd");

		if (StringUtils.isBlank(treatYmd))
			treatYmd = DateFormatUtils.format(date, "yyyyMMdd");

		HashMap logParamMap = new HashMap();

		int targetCnt = 0;
		int succCnt = 0;
		int failCnt = 0;

		try {
			String pgmId = "C2B05040";

			List targetList = null;
			HashMap paramMap = new HashMap();

			// 시작 배치 로그 파라미터 셋팅
			String expla = String.format("카드자동이체당사해지처리건카드사전송 [%s]", bnkCd);

			logParamMap.put("pgmId", pgmId);
			logParamMap.put("batchFlag", "20");
			logParamMap.put("procObjYmd", bnkCd);
			logParamMap.put("reqYm", " ");
			logParamMap.put("deadline", " ");
			logParamMap.put("expla", expla);
			logParamMap.put("targetCnt", targetCnt + "");
			logParamMap.put("succCnt", succCnt + "");
			logParamMap.put("failCnt", failCnt + "");
			logParamMap.put("rcBatchLog", null);
			logParamMap.put("errorMsg", expla);
			logParamMap.put("errorCode", "0");
			logParamMap.put("logFlag", "0");

			// 시작 배치 로그 실행
			logParamMap = startLogProc(logParamMap);
			int rtnLog = Integer.parseInt((String) logParamMap.get("RTN"));
			if (rtnLog == -1)
				throw new Exception("시작 로그 에러");

			// 파라미터 체크
			if (mode == null || !mode.matches("[NE]")) {
				// --처리모드 체크
				throw new Exception("처리모드 오류 : " + mode);
			} else if (spCnt == null || !spCnt.matches("[012]")) {
				// --특정에러건처리여부 체크
				throw new Exception("특정에러건처리여부 오류  : " + spCnt);
			} else if ("N".equals(mode) && !"0".equals(spCnt)) {
				// --처리모드가 N일때는 특정에러건처리여부가 0이어야 함.
				throw new Exception("처리모드&특정에러건처리여부 오류  : [" + mode + "] : [" + spCnt + "]");
			}

			paramMap.put("treatYmd", treatYmd);
			paramMap.put("cnlYmd", cnlYmd);
			paramMap.put("spCnt", spCnt);

			int cnt = 0;
			// 모드별 실행
			if ("N".equals(mode)) {
				// insert C11.C1BT_CARD_CNL_SEND
				cnt = insertAutoTransCnl(paramMap);
			} else if ("E".equals(mode)) {
				Map resultMap = selectAutoTrnasCnlSendInfo(paramMap);
				cnt = Integer.parseInt((String) resultMap.get("CMT_CNT"));
			}

			if (cnt > 0) {

				paramMap.put("treatYmd", treatYmd);
				paramMap.put("mode", mode);
				paramMap.put("spCnt", spCnt);

				// 대상 조회
				targetList = selectAutoTrnasCnl(paramMap);

				// 대상자수
				targetCnt = targetList == null ? 0 : targetList.size();

				for (int i = 0; i < targetCnt; i++) {
					HashMap target = (HashMap) targetList.get(i);
					if (bnkCd.equals(target.get("BNK_CD"))) {
						MIS3000q mq = parseData(target);

						int rtn = 0;
						String result = null;

						// send 에러시 3번 다시 시도
						int retry = 3;
						for (int sendFlag = 1; sendFlag <= retry; sendFlag++) {
							try {
								if (i > 0)
									Thread.sleep(10000);

								log.info(String.format("JQ: %s", StringU.toString(mq)));

								MIS3000r mr = mis.mis3000(mq);

								log.info(String.format("JR: %s", StringU.toString(mr)));

								result = mr.RSLT_CD;

								log.info(String.format("result : %s", result));

								break;

							} catch (Exception e) {
								if (sendFlag == retry) {
									rtn = 1;
									failCnt++;
									log.error(String.format("Sending Failed [%s] : %s", sendFlag, e.getMessage()));
								}
							}
						}

						// 업데이트 처리
						if (rtn == 0) {
							paramMap.put("rtnCd", result);
							paramMap.put("treatYmd", treatYmd);
							paramMap.put("defrayAccountNum", target.get("DEFRAY_ACCOUNT_NUM"));
							paramMap.put("custNum", target.get("CUST_NUM"));
							paramMap.put("useContNum", target.get("USE_CONT_NUM"));
							paramMap.put("reqYmd", target.get("REQ_YMD"));
							paramMap.put("cnlYmd", target.get("CNL_YMD"));

							int rtnNum = updateC1btCardCnlSend(paramMap);

							if (rtnNum == 0) {
								failCnt++;
								if (log.isErrorEnabled())
									log.error(String.format("!!!!!!!CardJobCnl ERROR : update ERROR :: rowcount : 0"));
							} else {
								succCnt++;
							}
						}
					}
				}
			}

			// 종료 로그
			logParamMap.put("targetCnt", targetCnt + "");
			logParamMap.put("succCnt", succCnt + "");
			logParamMap.put("failCnt", failCnt + "");
			logParamMap.put("errorMsg", String.format("카드자동이체당사해지처리건카드사전송 완료 [%s]", bnkCd));
			logParamMap.put("errorCode", 0 + "");
			logParamMap.put("logFlag", 1 + "");

			endLogProc(logParamMap);

		} catch (Exception e) {

			if (failCnt == 0)
				failCnt = 1;

			// 에러로그
			logParamMap.put("targetCnt", targetCnt + "");
			logParamMap.put("succCnt", succCnt + "");
			logParamMap.put("failCnt", failCnt + "");
			logParamMap.put("errorMsg", String.format("autoTransCnlSend ERROR [%s] : %s", bnkCd, e.getMessage()));
			logParamMap.put("errorCode", "-1");
			logParamMap.put("logFlag", "1");

			endLogProc(logParamMap);

			log.error(String.format("Sending Failed : %s", e.getMessage()), e);

		} finally {
			logParamMap = null;
		}
		return "0";
	}

	public SHC9150 parseDataSHC(HashMap target) {

		SHC9150 q = new SHC9150();
		SHCClientService.setRequestHeader(q, cardCom, "9150");

		Date d1 = new Date();
		Date d2 = DateUtils.addDays(d1, -1);
		String yesterday = DateFormatUtils.format(d2, "yyyyMMdd");

		q.b01 = "3";
		q.b02 = target.get("DEFRAY_ACCOUNT_NUM").toString();
		q.b03 = null;
		q.b04 = target.get("DEPOSITOR_NM").toString();
		q.b05 = null;
		q.b06 = target.get("DEPOSITOR_TEL_DDD").toString();
		q.b07 = target.get("DEPOSITOR_TEL_EXN").toString();
		q.b08 = target.get("DEPOSITOR_TEL_NUM").toString();
		q.b09 = yesterday;
		q.b10 = target.get("CUST_RELAT_CD").toString();
		q.b11 = target.get("REQ_NM").toString();
		q.b12 = target.get("USE_CONT_NUM").toString();
		q.b13 = "00";
		q.b14 = target.get("ORIG_APPLY_YM").toString().substring(0, 6);

		return q;
	}

	public KMC3000 parseDataKMC(HashMap target) {

		KMC3000 q = new KMC3000();
		KMCClientService.setRequestHeader(q, cardCom, "3000");

		q.b01 = "3";
		q.b02 = target.get("USE_CONT_NUM").toString();
		q.b03 = target.get("DEFRAY_ACCOUNT_NUM").toString();
		q.b04 = target.get("VALID_YM").toString();
		q.b05 = target.get("SOC_BIZ_NUM").toString();
		q.b06 = target.get("DEPOSITOR_NM").toString();
		q.b07 = target.get("CUST_RELAT_CD").toString();
		q.b08 = target.get("REQ_NM").toString();
		q.b09 = target.get("REQ_TEL_DDD").toString();
		q.b10 = target.get("REQ_TEL_EXN").toString();
		q.b11 = target.get("REQ_TEL_NUM").toString();
		q.b12 = target.get("DEPOSITOR_TEL_DDD").toString();
		q.b13 = target.get("DEPOSITOR_TEL_EXN").toString();
		q.b14 = target.get("DEPOSITOR_TEL_NUM").toString();
		q.b15 = target.get("ORIG_APPLY_YM").toString();
		q.b16 = target.get("CUST_NM").toString();
		q.b17 = target.get("ZIP_NO").toString();
		q.b18 = target.get("ADDR1").toString();
		q.b19 = target.get("ADDR2").toString();

		return q;
	}

	private MIS3000q parseData(HashMap target) {

		MIS3000q mq = new MIS3000q();

		Date d1 = new Date();
		Date d2 = DateUtils.addDays(d1, -1);
		String yesterday = DateFormatUtils.format(d2, "yyyyMMdd");
		String cid = cardCom.getCid();

		mq.CARD_CD = cid;
		mq.TREAT_FLAG = "3";
		mq.USE_CONT_NUM = target.get("USE_CONT_NUM").toString();
		mq.DEFRAY_ACCOUNT_NUM = target.get("DEFRAY_ACCOUNT_NUM").toString();
		mq.VALID_YM = target.get("VALID_YM").toString();
		mq.SOC_BIZ_NUM = target.get("SOC_BIZ_NUM").toString();
		mq.DEPOSITOR_NM = target.get("DEPOSITOR_NM").toString();
		mq.CUST_RELAT_CD = target.get("CUST_RELAT_CD").toString();
		mq.REQ_NM = target.get("REQ_NM").toString();
		mq.REQ_TEL_DDD = target.get("REQ_TEL_DDD").toString();
		mq.REQ_TEL_EXN = target.get("REQ_TEL_EXN").toString();
		mq.REQ_TEL_NUM = target.get("REQ_TEL_NUM").toString();
		mq.REQ_YMD = yesterday;
		mq.DEPOSITOR_TEL_DDD = target.get("DEPOSITOR_TEL_DDD").toString();
		mq.DEPOSITOR_TEL_EXN = target.get("DEPOSITOR_TEL_EXN").toString();
		mq.DEPOSITOR_TEL_NUM = target.get("DEPOSITOR_TEL_NUM").toString();
		mq.ORIG_APPLY_YM = target.get("ORIG_APPLY_YM").toString().substring(0, 6);
		mq.CUST_NM = target.get("CUST_NM").toString();
		mq.ZIP_NO = target.get("ZIP_NO").toString();
		mq.ADDR1 = target.get("ADDR1").toString();
		mq.ADDR2 = target.get("ADDR2").toString();

		return mq;
	}

	// 결과 업데이트 C11.C1BT_CARD_CNL_SEND
	private int updateC1btCardCnlSend(Map paramMap) throws Exception {
		int result = 0;
		Connection scg_conn = null;
		PreparedStatement scg_ps = null;
		ResultSet scg_rs = null;
		try {
			scg_conn = dataSource.getConnection();

			StringBuffer sb = new StringBuffer();

			sb.append("UPDATE C11.C1BT_CARD_CNL_SEND");
			sb.append("    SET    RESP_CD   = ?");
			sb.append("         , UPD_EMPID = 'SYSTEM'");
			sb.append("         , UPD_IP    = '*.*.*.*.' ");
			sb.append("         , UPD_DTM   = SYSDATE");
			sb.append("    WHERE  1=1");
			sb.append("    AND    TREAT_YMD          = ?");
			sb.append("    AND    DEFRAY_ACCOUNT_NUM = ?");
			sb.append("    AND    CUST_NUM           = ?");
			sb.append("    AND    REQ_INFO_NUM       = ?");
			sb.append("    AND    REQ_YMD            = ?");
			sb.append("    AND    CNL_YMD            = ?");

			int index = 0;
			scg_ps = scg_conn.prepareStatement(sb.toString());

			scg_ps.setObject(++index, paramMap.get("rtnCd"));
			scg_ps.setObject(++index, paramMap.get("treatYmd"));
			scg_ps.setObject(++index, paramMap.get("defrayAccountNum"));
			scg_ps.setObject(++index, paramMap.get("custNum"));
			scg_ps.setObject(++index, paramMap.get("useContNum"));
			scg_ps.setObject(++index, paramMap.get("reqYmd"));
			scg_ps.setObject(++index, paramMap.get("cnlYmd"));

			result = scg_ps.executeUpdate();

		} catch (Exception e) {
			throw e;
		} finally {
			close(scg_rs, scg_ps, scg_conn);
		}
		return result;
	}

	// insert... C11.C1BT_CARD_CNL_SEND
	private int insertAutoTransCnl(Map paramMap) throws Exception {
		int result = 0;
		Connection scg_conn = null;
		PreparedStatement scg_ps = null;
		ResultSet scg_rs = null;
		try {
			scg_conn = dataSource.getConnection();

			StringBuffer sb = new StringBuffer();
			sb.append("INSERT INTO C11.C1BT_CARD_CNL_SEND                                    ");
			sb.append("(                                                                     ");
			sb.append("      TREAT_YMD                                                       ");
			sb.append("    , DEFRAY_ACCOUNT_NUM                                              ");
			sb.append("    , CUST_NUM                                                        ");
			sb.append("    , REQ_INFO_NUM                                                    ");
			sb.append("    , REQ_YMD                                                         ");
			sb.append("    , CNL_YMD                                                         ");
			sb.append("    , BNK_CD                                                          ");
			sb.append("    , CRT_EMPID                                                       ");
			sb.append("    , CRT_IP                                                          ");
			sb.append("    , CRT_DTM                                                         ");
			sb.append("    , UPD_EMPID                                                       ");
			sb.append("    , UPD_IP                                                          ");
			sb.append("    , UPD_DTM                                                         ");
			sb.append(")                                                                     ");
			sb.append("SELECT /*+ INDEX(A C1BX_2_USE_CONT_TRANS) */                          ");
			sb.append("       TO_CHAR(SYSDATE, 'YYYYMMDD')                                   ");
			sb.append("     , A.DEFRAY_ACCOUNT_NUM                                           ");
			sb.append("     , A.CUST_NUM                                                     ");
			sb.append("     , A.REQ_INFO_NUM                                                 ");
			sb.append("     , A.REQ_YMD                                                      ");
			sb.append("     , A.CNL_YMD                                                      ");
			sb.append("     , A.BNK_CD                                                       ");
			sb.append("     , 'SYSTEM'                                                       ");
			sb.append("     , '*.*.*.*.'                                                     ");
			sb.append("     , SYSDATE                                                        ");
			sb.append("     , 'SYSTEM'                                                       ");
			sb.append("     , '*.*.*.*.'                                                     ");
			sb.append("     , SYSDATE                                                        ");
			sb.append("FROM   C11.C1BT_USE_CONT_TRANS A                                      ");
			sb.append("WHERE  1=1                                                            ");
			sb.append("AND    A.CNL_YMD        = ?                                           ");
			// sb.append("AND A.BNK_CD IN ('808','807','803') ");
			sb.append("AND    A.BNK_CD         IN (?)                                        ");
			sb.append("AND    A.RECEIVE_STS_CD = '30'                                        ");
			// -- sb.append(" AND NOT EXISTS (SELECT 1 ");
			// -- sb.append(" FROM C11.C1AT_TRANS_ACNT_REQ Y ");
			// -- sb.append(" WHERE 1=1 ");
			// -- sb.append(" AND A.DEFRAY_ACCOUNT_NUM = Y.DEFRAY_ACCOUNT_NU");
			// -- sb.append(" AND A.CUST_NUM = Y.CUST_NUM ");
			// -- sb.append(" AND A.CNL_YMD = Y.REQ_YMD ");
			// -- sb.append(" ) ");
			// --당사에서 해지전문 보낼 시 접수내역 생성하지 않아서 의미 없음. 결론은 현재 정상이 아니면 실시간이든, 당사만
			// 처리했든 구분 없이 모두 보냄.
			// --실시간도 카드사에서는 이미 해지가 완료된 건이라 중복적으로 보내더라도 문제는 없음.
			sb.append("AND    NOT EXISTS (SELECT /*+ INDEX(X C1BX_0_USE_CONT_TRANS) */          ");
			sb.append("                          1                                              ");
			sb.append("                   FROM   C11.C1BT_USE_CONT_TRANS X                      ");
			sb.append("                   WHERE  1=1                                            ");
			sb.append("                   AND    A.DEFRAY_ACCOUNT_NUM = X.DEFRAY_ACCOUNT_NUM    ");
			sb.append("                   AND    A.REQ_INFO_NUM       = X.REQ_INFO_NUM          ");
			sb.append("                   AND    X.RECEIVE_STS_CD     = '20'                    ");
			sb.append("                  ) /*정상건이 존재하면 다시 신청된건으로 간주함.*/      ");
			sb.append("AND    NOT EXISTS (SELECT /*+ INDEX(Z C1BX_0_CARD_CNL_SEND) */           ");
			sb.append("                          1                                              ");
			sb.append("                   FROM   C11.C1BT_CARD_CNL_SEND Z                       ");
			sb.append("                   WHERE  1=1                                            ");
			sb.append("                   AND    A.DEFRAY_ACCOUNT_NUM = Z.DEFRAY_ACCOUNT_NUM    ");
			sb.append("                   AND    A.CUST_NUM           = Z.CUST_NUM              ");
			sb.append("                   AND    A.REQ_INFO_NUM       = Z.REQ_INFO_NUM          ");
			sb.append("                   AND    A.REQ_YMD            = Z.REQ_YMD               ");
			sb.append("                   AND    A.CNL_YMD            = Z.CNL_YMD               ");
			sb.append("                   AND    A.BNK_CD             = Z.BNK_CD                ");
			sb.append("                   AND    Z.TREAT_YMD          = ?                       ");
			sb.append("                  )                                                      ");

			int index = 0;
			scg_ps = scg_conn.prepareStatement(sb.toString());
			scg_ps.setObject(++index, paramMap.get("cnlYmd"));
			scg_ps.setObject(++index, bnkCd);
			scg_ps.setObject(++index, paramMap.get("treatYmd"));

			result = scg_ps.executeUpdate();

		} catch (Exception e) {
			throw e;
		} finally {
			close(scg_rs, scg_ps, scg_conn);
		}
		return result;
	}

	// 조건 조회
	private Map selectAutoTrnasCnlSendInfo(Map paramMap) throws Exception {

		Map resultMap = null;

		Connection scg_conn = null;
		PreparedStatement scg_ps = null;
		ResultSet scg_rs = null;
		try {
			scg_conn = dataSource.getConnection();

			StringBuffer sb = new StringBuffer();

			sb.append("SELECT    COUNT(*) 			AS CMT_CNT ");
			// sb.append(" , B.HOST_ADDRESS AS HOST_ADDRESS");
			// sb.append(" , B.HOST_NAME AS HOST_NAME");
			sb.append("    FROM   C11.C1BT_CARD_CNL_SEND A");
			// sb.append(" ,(");
			// sb.append(" SELECT UTL_INADDR.GET_HOST_ADDRESS AS HOST_ADDRESS");
			// sb.append(" , UTL_INADDR.GET_HOST_NAME AS HOST_NAME");
			// sb.append(" FROM DUAL");
			// sb.append(" )B");
			sb.append("    WHERE  1=1");
			sb.append("    AND    A.TREAT_YMD = ?");
			sb.append("    AND    A.CNL_YMD   = ?");
			sb.append(
					"    AND    CASE WHEN ? = 1 AND NVL(A.RESP_CD, ' ') NOT IN ('00','0000') AND UPPER(A.RMK) = 'SPCNT' THEN 'Y' "); // 에러중
																																		// 특정건
																																				// 재수행
			sb.append("                WHEN ? = 2 AND A.RESP_CD IS NULL THEN 'Y' "); /*
																						 * 미처리건
																						 * 재수행
																						 */
			sb.append("                WHEN ? = 0 AND NVL(A.RESP_CD, ' ') NOT IN ('00','0000) THEN 'Y' "); // 에러,
																											// 미처리
																											// 일괄
																											// 재수행
			sb.append("                ELSE 'N'");
			sb.append("           END = 'Y'");
			sb.append("    AND    A.BNK_CD   = ?");

			int index = 0;
			scg_ps = scg_conn.prepareStatement(sb.toString());
			scg_ps.setObject(++index, paramMap.get("treatYmd"));
			scg_ps.setObject(++index, paramMap.get("cnlYmd"));
			scg_ps.setObject(++index, paramMap.get("spCnt"));
			scg_ps.setObject(++index, paramMap.get("spCnt"));
			scg_ps.setObject(++index, paramMap.get("spCnt"));
			scg_ps.setObject(++index, bnkCd);

			scg_rs = scg_ps.executeQuery();

			while (scg_rs.next()) {
				resultMap = new HashMap();
				resultMap.put("CMT_CNT", scg_rs.getString("CMT_CNT"));
				// resultMap.put("HOST_ADDRESS",
				// scg_rs.getString("HOST_ADDRESS"));
				// resultMap.put("HOST_NAME", scg_rs.getString("HOST_NAME"));
			}

		} catch (Exception e) {
			throw e;
		} finally {
			close(scg_rs, scg_ps, scg_conn);
		}
		return resultMap;
	}

	// 대상 조회
	private List selectAutoTrnasCnl(Map paramMap) throws Exception {

		List resultList = null;
		HashMap resultMap = null;

		Connection scg_conn = null;
		PreparedStatement scg_ps = null;
		ResultSet scg_rs = null;

		try {
			scg_conn = dataSource.getConnection();

			StringBuffer sb = new StringBuffer();

			sb.append("SELECT /*+ USE_NL(X Y Z B D F E G) */");
			sb.append(
					"               NVL(D.USE_CONT_NUM,' ')											AS USE_CONT_NUM");
			sb.append(
					"             , NVL(X.DEFRAY_ACCOUNT_NUM,' ')										AS DEFRAY_ACCOUNT_NUM");
			sb.append("             , TRIM(B.VALID_PERIOD)												AS VALID_YM");
			sb.append("             , CASE WHEN LENGTH(B.SOC_BIZ_NUM) = 13 ");
			sb.append("             		THEN SUBSTR(B.SOC_BIZ_NUM,1,6)||'0000000' ");
			sb.append("             		ELSE B.SOC_BIZ_NUM ");
			sb.append(
					"             	END 															AS SOC_BIZ_NUM");
			sb.append(
					"             , NVL(B.DEPOSITOR_NM,' ')											AS DEPOSITOR_NM");
			sb.append("				, CASE WHEN B.CUST_RELAT_CD = '10' THEN '01'");
			sb.append("                    WHEN B.CUST_RELAT_CD = '11' THEN '02'");
			sb.append("                    WHEN B.CUST_RELAT_CD = '12' THEN '05'");
			sb.append("                    WHEN B.CUST_RELAT_CD = '13' THEN '03'");
			sb.append("                    WHEN B.CUST_RELAT_CD = '14' THEN '07'");
			sb.append("                    WHEN B.CUST_RELAT_CD = '16' THEN '09'");
			sb.append("                    WHEN B.CUST_RELAT_CD IN ('21','22') THEN '04'");
			sb.append("                    ELSE '09'										");
			sb.append("               /* (01:본인,02:배우자,03:자녀,04:형제자매,05:부친,06:모친,07:친척,09:기타, 신한,국민 공통) */");
			sb.append(
					"               END			 													AS CUST_RELAT_CD");
			sb.append("				, NVL(RTRIM(Z.REQ_NM),      NVL(RTRIM(Y.CNL_CUST_NM), '시스템'))	AS REQ_NM");
			sb.append(
					"             , NVL(RTRIM(Z.REQ_TEL_DDD), NVL(RTRIM(Y.CNL_TEL_DDD), '010 '))   	AS REQ_TEL_DDD");
			sb.append(
					"             , NVL(RTRIM(Z.REQ_TEL_EXN), NVL(RTRIM(Y.CNL_TEL_EXN), '0000'))   	AS REQ_TEL_EXN");
			sb.append(
					"             , NVL(RTRIM(Z.REQ_TEL_NUM), NVL(RTRIM(Y.CNL_TEL_NUM), '0000'))   	AS REQ_TEL_NUM");
			sb.append(
					"             , NVL(B.DEPOSITOR_TEL_DDD,	 ' ')									AS DEPOSITOR_TEL_DDD");
			sb.append(
					"             , NVL(B.DEPOSITOR_TEL_EXN,	 ' ')									AS DEPOSITOR_TEL_EXN");
			sb.append(
					"             , NVL(B.DEPOSITOR_TEL_NUM,	 ' ')									AS DEPOSITOR_TEL_NUM");
			sb.append(
					"             , NVL(Y.ORIG_APPLY_YM	 ,	 ' ')									AS ORIG_APPLY_YM");
			sb.append("             , NVL(X.BNK_CD									,' ')				AS BNK_CD");
			sb.append("             , NVL(F.CUST_NM									,' ')				AS CUST_NM");
			sb.append("             , NVL(G.ZIP_NO1 || G.ZIP_NO2 					,' ')				AS ZIP_NO");
			sb.append("             , NVL(G.CITY || ' ' || G.COUNTY || ' ' || G.TOWN,' ')				AS ADDR1");
			sb.append("             , SUBSTR(");
			sb.append("             				E.CURR_ADDR_UNION ");
			sb.append("             			,   LENGTH(G.CITY || ' ' || G.COUNTY || ' ' || G.TOWN || ' ') + 1");
			sb.append("             		) 															AS ADDR2");
			sb.append("             , NVL(X.CUST_NUM, ' ')												AS CUST_NUM");
			sb.append("             , NVL(X.REQ_YMD	, ' ')												AS REQ_YMD");
			sb.append("             , NVL(X.CNL_YMD	, ' ')												AS CNL_YMD");
			sb.append("        FROM   C11.C1BT_CARD_CNL_SEND  X");
			sb.append("             , C11.C1BT_USE_CONT_TRANS Y");
			sb.append("             , C11.C1AT_TRANS_ACNT_REQ Z");
			sb.append("             , C11.C1AT_TRANS_ACNT     B");
			sb.append("             , C11.C1BT_USE_CONT       D");
			sb.append("             , C11.C1AT_CUST_INFO      F");
			sb.append("             , C31.C3AT_INST_PLACE     E");
			sb.append("             , A11.A1AT_ZIP            G");
			sb.append("		   WHERE  1=1");
			sb.append("        AND    X.TREAT_YMD          = ?");
			sb.append("        AND    X.DEFRAY_ACCOUNT_NUM = Y.DEFRAY_ACCOUNT_NUM");
			sb.append("        AND    X.CUST_NUM           = Y.CUST_NUM");
			sb.append("        AND    X.REQ_INFO_NUM       = Y.REQ_INFO_NUM");
			sb.append("        AND    X.REQ_YMD            = Y.REQ_YMD");
			sb.append("        AND    X.CNL_YMD            = Y.CNL_YMD");
			sb.append("        AND    X.BNK_CD             = Y.BNK_CD");
			sb.append("        AND    Y.RECEIVE_STS_CD     = '30'");

			sb.append("        AND    X.DEFRAY_ACCOUNT_NUM = Z.DEFRAY_ACCOUNT_NUM(+)");
			sb.append("        AND    X.CUST_NUM           = Z.CUST_NUM(+)");
			sb.append("        AND    X.CNL_YMD            = Z.REQ_YMD(+)");
			sb.append("        AND    Z.REQ_ITEM_CD(+)     = '08'"); /*
																		 * 20151104
																		 * 쿼리수정
																		 */

			sb.append("        AND    X.DEFRAY_ACCOUNT_NUM = B.DEFRAY_ACCOUNT_NUM");
			sb.append("        AND    X.CUST_NUM           = B.CUST_NUM");
			sb.append("        AND    X.REQ_INFO_NUM       = D.REQ_INFO_NUM");
			sb.append("        AND    X.CUST_NUM           = F.CUST_NUM");
			sb.append("        AND    D.INST_PLACE_NUM     = E.INST_PLACE_NUM");
			sb.append("        AND    E.ZIP_SEQ            = G.ZIP_SEQ");

			sb.append("        AND    CASE WHEN ? = 'E' AND NVL(X.RESP_CD, ' ') NOT IN ('00','0000') THEN 'Y'");
			sb.append("                    WHEN ? = 'N' AND X.RESP_CD IS NULL THEN 'Y'");
			sb.append("                    ELSE 'N'");
			sb.append("               END = 'Y'");
			sb.append("        AND    CASE WHEN ? = 'N' THEN 'Y'");
			sb.append(
					"                    WHEN ? = 1 AND NVL(X.RESP_CD, ' ') NOT IN ('00','0000') AND UPPER(X.RMK) = 'SPCNT' THEN 'Y'"); /*
																																		 * 에러중
																																		 * 특정건
																																		 * 재수행
																																		 */
			sb.append("                    WHEN ? = 2 AND X.RESP_CD IS NULL THEN 'Y'"); /*
																						 * 미처리건
																						 * 재수행
																						 */
			sb.append("                    WHEN ? = 0 AND X.RESP_CD NOT IN ('00','0000') THEN 'Y'"); /*
																										 * 에러
																										 * ,
																										 * 미처리
																										 * 일괄
																										 * 재수행
																										 */
			sb.append("                    ELSE 'N'");
			sb.append("               END = 'Y'");
			sb.append("		   AND X.BNK_CD = ?");/* 신한카드 */
			sb.append("        ORDER BY X.BNK_CD DESC");

			int index = 0;
			scg_ps = scg_conn.prepareStatement(sb.toString());
			scg_ps.setObject(++index, paramMap.get("treatYmd"));
			scg_ps.setObject(++index, paramMap.get("mode"));
			scg_ps.setObject(++index, paramMap.get("mode"));
			scg_ps.setObject(++index, paramMap.get("mode"));
			scg_ps.setObject(++index, paramMap.get("spCnt"));
			scg_ps.setObject(++index, paramMap.get("spCnt"));
			scg_ps.setObject(++index, paramMap.get("spCnt"));
			scg_ps.setObject(++index, bnkCd);

			scg_rs = scg_ps.executeQuery();

			resultList = new ArrayList();
			while (scg_rs.next()) {
				resultMap = new HashMap();

				resultMap.put("USE_CONT_NUM", scg_rs.getString("USE_CONT_NUM"));
				resultMap.put("DEFRAY_ACCOUNT_NUM", scg_rs.getString("DEFRAY_ACCOUNT_NUM"));
				resultMap.put("VALID_YM", scg_rs.getString("VALID_YM"));
				resultMap.put("SOC_BIZ_NUM", scg_rs.getString("SOC_BIZ_NUM"));
				resultMap.put("DEPOSITOR_NM", scg_rs.getString("DEPOSITOR_NM"));
				resultMap.put("CUST_RELAT_CD", scg_rs.getString("CUST_RELAT_CD"));
				resultMap.put("REQ_NM", scg_rs.getString("REQ_NM"));
				resultMap.put("REQ_TEL_DDD", scg_rs.getString("REQ_TEL_DDD"));
				resultMap.put("REQ_TEL_EXN", scg_rs.getString("REQ_TEL_EXN"));
				resultMap.put("REQ_TEL_NUM", scg_rs.getString("REQ_TEL_NUM"));
				resultMap.put("DEPOSITOR_TEL_DDD", scg_rs.getString("DEPOSITOR_TEL_DDD"));
				resultMap.put("DEPOSITOR_TEL_EXN", scg_rs.getString("DEPOSITOR_TEL_EXN"));
				resultMap.put("DEPOSITOR_TEL_NUM", scg_rs.getString("DEPOSITOR_TEL_NUM"));
				resultMap.put("ORIG_APPLY_YM", scg_rs.getString("ORIG_APPLY_YM"));
				resultMap.put("BNK_CD", scg_rs.getString("BNK_CD"));
				resultMap.put("CUST_NM", scg_rs.getString("CUST_NM"));
				resultMap.put("ZIP_NO", scg_rs.getString("ZIP_NO"));
				resultMap.put("ADDR1", scg_rs.getString("ADDR1"));
				resultMap.put("ADDR2", scg_rs.getString("ADDR2"));
				resultMap.put("CUST_NUM", scg_rs.getString("CUST_NUM"));
				resultMap.put("REQ_YMD", scg_rs.getString("REQ_YMD"));
				resultMap.put("CNL_YMD", scg_rs.getString("CNL_YMD"));

				resultList.add(resultMap);

			}
		} catch (Exception e) {
			throw e;
		} finally {
			close(scg_rs, scg_ps, scg_conn);
		}
		return resultList;

	}

	// 시작로그
	private HashMap startLogProc(HashMap paramMap) throws Exception {

		log.info("시작로그");
		HashMap resultMap = null;

		Connection scg_conn = null;
		PreparedStatement scg_ps = null;
		ResultSet scg_rs = null;

		CallableStatement scg_cs = null;
		OracleCallableStatement ocstmt = null;

		try {
			scg_conn = dataSource.getConnection();

			StringBuffer sb = new StringBuffer();

			sb.append("DECLARE");
			sb.append("			PROCEDURE PROC_START(");
			sb.append("									  parPgmId			IN VARCHAR2");
			sb.append("									, parBatchFlag		IN VARCHAR2");
			sb.append("									, parProcObjYmd		IN VARCHAR2");
			sb.append("					        		, parReqYm			IN VARCHAR2");
			sb.append("									, parDeadline	  	IN VARCHAR2");
			sb.append("									, parExpla			IN VARCHAR2");
			sb.append("	                        		, parTargetCnt	  	IN NUMBER");
			sb.append("	                        		, parSuccCnt		IN NUMBER");
			sb.append("	                        		, parFailCnt		IN NUMBER");
			sb.append("	                        		, C_LIST			OUT	SYS_REFCURSOR");
			sb.append("	        )IS");
			sb.append("	        	RTN 			NUMBER;");
			sb.append("	        	rcBatchLog	    C21.C2B_REC_TBL2.RecordBatchLog;");
			sb.append("	        BEGIN");
			sb.append("				C21.PKS_C2T_ERROR_LOG.PROC_INIT_BATCH_LOG(	  'SYSTEM'");
			sb.append("	                                                       	, '*.*.*.*'");
			sb.append("															, parPgmId");
			sb.append("															, parProcObjYmd");
			sb.append("															, parReqYm");
			sb.append("	                                                        , parDeadline");
			sb.append("															, parExpla");
			sb.append("															, rcBatchLog );");
			sb.append("	                                                           ");
			sb.append("	            RTN := C21.PKS_C2T_ERROR_LOG.FUNC_SET_BATCH_LOG (  parBatchFlag");
			sb.append("																 , parTargetCnt");
			sb.append("																 , parSuccCnt");
			sb.append("																 , parFailCnt");
			sb.append("														   		 , rcBatchLog );");
			sb.append("				OPEN C_LIST FOR      ");
			sb.append("					SELECT ");
			sb.append("				          rcBatchLog.chId				AS chId   ");
			sb.append("				        , rcBatchLog.chEmpid			AS chEmpid");
			sb.append("				        , rcBatchLog.chIp				AS chIp");
			sb.append("				        , rcBatchLog.chBatchId         	AS chBatchId");
			sb.append("				        , rcBatchLog.chBatchIdFlag     	AS chBatchIdFlag");
			sb.append("				        , rcBatchLog.dtCalcuEndDtm     	AS dtCalcuEndDtm");
			sb.append("				        , rcBatchLog.chStsCd           	AS chStsCd");
			sb.append("				        , rcBatchLog.nObjCnt           	AS nObjCnt");
			sb.append("						, rcBatchLog.nNormalCnt        	AS nNormalCnt");
			sb.append("						, rcBatchLog.nErrorCnt         	AS nErrorCnt");
			sb.append("						, rcBatchLog.chReqYm           	AS chReqYm");
			sb.append("						, rcBatchLog.chDeadlineFlag    	AS chDeadlineFlag");
			sb.append("			          	, rcBatchLog.varDeadlineExpla  	AS varDeadlineExpla");
			sb.append("						, rcBatchLog.varJobRslt        	AS varJobRslt");
			sb.append("						, RTN							AS RTN");
			sb.append("					FROM DUAL;");
			sb.append("	        END; ");
			sb.append("	        ");
			sb.append("		BEGIN");
			sb.append("			PROC_START(   ?");
			sb.append("						, ?");
			sb.append("						, ?");
			sb.append("						, ?");
			sb.append("						, ?");
			sb.append("						, ?");
			sb.append("						, ?");
			sb.append("						, ?");
			sb.append("	                    , ?");
			sb.append("	                    , ?");
			sb.append("						);");
			sb.append("			C21.PKS_C2T_ERROR_LOG.PROC_OUTPUT_PUT_LINE(   ?");
			sb.append("														, ?");
			sb.append("														, ?");
			sb.append("														);");
			sb.append("			C21.PKS_C2T_ERROR_LOG.PROC_OUTPUT_PUT_ALRAM(  ?");
			sb.append("														, ?");
			sb.append("														, ?");
			sb.append("														, ?");
			sb.append("														); ");
			sb.append("		END;");

			int index = 0;
			int cIndex = 0;
			scg_cs = scg_conn.prepareCall(sb.toString());

			scg_cs.setObject(++index, paramMap.get("pgmId"));
			scg_cs.setObject(++index, paramMap.get("batchFlag"));
			scg_cs.setObject(++index, paramMap.get("procObjYmd"));
			scg_cs.setObject(++index, paramMap.get("reqYm"));
			scg_cs.setObject(++index, paramMap.get("deadline"));
			scg_cs.setObject(++index, paramMap.get("expla"));
			scg_cs.setObject(++index, paramMap.get("targetCnt"));
			scg_cs.setObject(++index, paramMap.get("succCnt"));
			scg_cs.setObject(++index, paramMap.get("failCnt"));
			scg_cs.registerOutParameter(cIndex = ++index, CURSOR);
			scg_cs.setObject(++index, paramMap.get("pgmId"));
			scg_cs.setObject(++index, paramMap.get("errorMsg"));
			scg_cs.setObject(++index, paramMap.get("errorCode"));
			scg_cs.setObject(++index, paramMap.get("pgmId"));
			scg_cs.setObject(++index, paramMap.get("logFlag"));
			scg_cs.setObject(++index, paramMap.get("succCnt"));
			scg_cs.setObject(++index, paramMap.get("failCnt"));

			scg_cs.executeQuery();
			// ocstmt = (OracleCallableStatement) scg_cs;
			// scg_rs = ocstmt.getCursor(cIndex);
			scg_rs = (ResultSet) scg_cs.getObject(cIndex);

			while (scg_rs.next()) {
				resultMap = new HashMap();

				resultMap.put("chId", scg_rs.getString("chId"));
				resultMap.put("chEmpid", scg_rs.getString("chEmpid"));
				resultMap.put("chIp", scg_rs.getString("chIp"));
				resultMap.put("chBatchId", scg_rs.getString("chBatchId"));
				resultMap.put("chBatchIdFlag", scg_rs.getString("chBatchIdFlag"));
				resultMap.put("dtCalcuEndDtm", scg_rs.getDate("dtCalcuEndDtm"));
				resultMap.put("chStsCd", scg_rs.getString("chStsCd"));
				resultMap.put("nObjCnt", scg_rs.getString("nObjCnt"));
				resultMap.put("nNormalCnt", scg_rs.getString("nNormalCnt"));
				resultMap.put("nErrorCnt", scg_rs.getString("nErrorCnt"));
				resultMap.put("chReqYm", scg_rs.getString("chReqYm"));
				resultMap.put("chDeadlineFlag", scg_rs.getString("chDeadlineFlag"));
				resultMap.put("varDeadlineExpla", scg_rs.getString("varDeadlineExpla"));
				resultMap.put("varJobRslt", scg_rs.getString("varJobRslt"));
				resultMap.put("RTN", scg_rs.getString("RTN"));

				log.info("resultMap=" + StringU.toString(resultMap));
			}
		} catch (Exception e) {
			throw e;
		} finally {
			close(scg_rs, ocstmt, scg_cs, scg_ps, scg_conn);
		}
		return resultMap;
	}

	// 종료로그
	private int endLogProc(Map paramMap) throws Exception {

		log.info("종료로그");

		int rtn = 0;

		Connection scg_conn = null;
		PreparedStatement scg_ps = null;
		ResultSet scg_rs = null;
		CallableStatement scg_cs = null;
		OracleCallableStatement ocstmt = null;

		try {
			scg_conn = dataSource.getConnection();

			StringBuffer sb = new StringBuffer();

			sb.append("DECLARE");
			sb.append("		rcBatchLog     C21.C2B_REC_TBL2.RecordBatchLog;");
			sb.append("		RTN NUMBER ;");
			sb.append("		CURSOR C_LIST2 IS ");
			sb.append("            SELECT");
			sb.append("            	  ?  AS chId           ");
			sb.append("				, ?  AS chEmpid        ");
			sb.append("				, ?  AS chIp            ");
			sb.append("				, ?  AS chBatchId       ");
			sb.append("				, ?  AS chBatchIdFlag   ");
			sb.append("				, ?  AS dtCalcuEndDtm    ");
			sb.append("				, ?  AS chStsCd         ");
			sb.append("				, ?  AS nObjCnt         ");
			sb.append("				, ?  AS nNormalCnt      ");
			sb.append("				, ?  AS nErrorCnt       ");
			sb.append("				, ?  AS chReqYm         ");
			sb.append("				, ?  AS chDeadlineFlag  ");
			sb.append("				, ?  AS varDeadlineExpla");
			sb.append("				, ?  AS varJobRslt      ");
			sb.append("            FROM DUAL;");
			sb.append("	BEGIN");
			sb.append("        OPEN C_LIST2;");
			sb.append("        FETCH C_LIST2 INTO rcBatchLog;");
			sb.append("        CLOSE C_LIST2;");
			sb.append("		? := C21.PKS_C2T_ERROR_LOG.FUNC_SET_BATCH_LOG ( CASE WHEN ? <> 0 THEN '40' ELSE '30' END");
			sb.append("														   , ?");
			sb.append("                                                        , ?");
			sb.append("                                                        , ?");
			sb.append("														   , rcBatchLog );");
			sb.append("		C21.PKS_C2T_ERROR_LOG.PROC_OUTPUT_PUT_LINE(   ?");
			sb.append("													, ?");
			sb.append("													, ?");
			sb.append("													);");
			sb.append("		C21.PKS_C2T_ERROR_LOG.PROC_OUTPUT_PUT_ALRAM(  ?");
			sb.append("													, ?");
			sb.append("													, ?");
			sb.append("													, ?");
			sb.append("													);");
			sb.append("	END;");

			int index = 0;
			int cIndex = 0;
			scg_cs = scg_conn.prepareCall(sb.toString());

			scg_cs.setObject(++index, paramMap.get("chId"));
			scg_cs.setObject(++index, paramMap.get("chEmpid"));
			scg_cs.setObject(++index, paramMap.get("chIp"));
			scg_cs.setObject(++index, paramMap.get("chBatchId"));
			scg_cs.setObject(++index, paramMap.get("chBatchIdFlag"));
			scg_cs.setObject(++index, paramMap.get("dtCalcuEndDtm"));
			scg_cs.setObject(++index, paramMap.get("chStsCd"));
			scg_cs.setObject(++index, paramMap.get("nObjCnt"));
			scg_cs.setObject(++index, paramMap.get("nNormalCnt"));
			scg_cs.setObject(++index, paramMap.get("nErrorCnt"));
			scg_cs.setObject(++index, paramMap.get("chReqYm"));
			scg_cs.setObject(++index, paramMap.get("chDeadlineFlag"));
			scg_cs.setObject(++index, paramMap.get("varDeadlineExpla"));
			scg_cs.setObject(++index, paramMap.get("varJobRslt"));

			scg_cs.registerOutParameter(cIndex = ++index, Types.INTEGER);

			scg_cs.setObject(++index, paramMap.get("failCnt"));
			scg_cs.setObject(++index, paramMap.get("targetCnt"));
			scg_cs.setObject(++index, paramMap.get("succCnt"));
			scg_cs.setObject(++index, paramMap.get("failCnt"));

			scg_cs.setObject(++index, paramMap.get("pgmId"));
			scg_cs.setObject(++index, paramMap.get("errorMsg"));
			scg_cs.setObject(++index, paramMap.get("errorCode"));

			scg_cs.setObject(++index, paramMap.get("pgmId"));
			scg_cs.setObject(++index, paramMap.get("logFlag"));
			scg_cs.setObject(++index, paramMap.get("succCnt"));
			scg_cs.setObject(++index, paramMap.get("failCnt"));

			scg_cs.executeQuery();
			rtn = scg_cs.getInt(cIndex);

		} catch (Exception e) {
			throw e;
		} finally {
			close(scg_rs, ocstmt, scg_cs, scg_ps, scg_conn);
		}
		return rtn;
	}

	public void close(AutoCloseable... o) {
		if (o != null)
			for (AutoCloseable c : o)
				try {
					if (c != null)
						c.close();
				} catch (Exception e) {
					log.error(e.getMessage(), e);
				}
	}

	@Override
	public void close() {
		Thread.currentThread().interrupt();
	}
}
