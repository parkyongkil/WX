package scg.c24.biz.db.shc.model;

import lombok.Data;

@Data
public class SHCUseContAll {

	String DEFRAY_ACCOUNT_NUM;

	String CUST_NUM;

	String REQ_INFO_NUM;

	String REQ_YMD;

	String BNK_CD;

	String TRAN_FLAG;
}