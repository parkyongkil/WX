package scg.c24.net.transfer.shc;

import java.io.ByteArrayOutputStream;
import java.net.Socket;
import java.util.Arrays;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;

import scg.c24.config.CardConfig;
import scg.c24.data.shc.SHC8050;
import scg.c24.data.shc.SHC8150;
import scg.c24.data.shc.SHC9050;
import scg.c24.data.shc.SHC9150;
import scg.c24.data.shc.SHCData;
import scg.c24.net.transfer.CardDataTransfer;
import tt.io.TDataOutputStream;
import tt.lang.string.StringU;

public class SHCDataTransfer extends CardDataTransfer<SHCData> {

	public static final int HL = SHCData.HL;

	public SHCDataTransfer(CardConfig cardConfig, Socket socket, boolean toSCGS) throws Exception {
		super(cardConfig, socket, toSCGS);
	}

	@Override
	public byte[] read() throws Exception {

		byte[] a = new byte[HL];
		int n0 = in.read(a);
		if (n0 == -1)
			throw new Exception("인풋스트림이 끊겼습니다.");
		if (n0 == 0)
			return null;
		if (n0 != HL)
			throw new Exception(String.format("전문의 공통부의 길이(%d)가 표준(%d)보다 짧습니다.\n[%s]\n%s", n0, HL,
					new String(a, in.getCharset()), Arrays.toString(a)));

		String s1 = new String(a, 9, 5);
		String s2 = new String(a, 57, 4);
		String sx = new String(a, 17, 4);
		int n1 = NumberUtils.toInt(s1);
		int n2 = NumberUtils.toInt(s2);
		int n3 = n1 - HL;

		if (n3 < 0)
			throw new Exception(String.format("전문의 전체길이값(%d)이 공통부의 길이값(%d) 보다 작습니다.\n[%s]\n%s\n%s: %s", n1, HL,
					new String(a, in.getCharset()), Arrays.toString(a), rx,
					StringU.toString(toObject(a, SHCData.class))));

		byte[] b = new byte[n1];
		System.arraycopy(a, 0, b, 0, HL);

		boolean rf = false;
		boolean ef = false;

		int n4 = 0;
		try {
			if (rf)
				in.readFully(b, HL, n3);
			else
				n4 = in.read(b, HL, n3);
		} catch (Exception e) {
			throw new Exception(String.format("%s\n%s: %s (%5d,%4d)\n[%s]\n%s", e.getMessage(), rx, sx, n1, n2,
					new String(b, in.getCharset()), Arrays.toString(b)), e);
		}
		if (ef && n4 != n3) {
			String e1 = String.format("전문의 전체길이가 기대값과 일치하지 않습니다.(기대값=%d,실제값=%d)", HL + n3, HL + n4);
			String e2 = String.format("%s: %s (%5d,%4d)\n[%s]\n%s", rx, sx, n1, n2,
					new String(b, 0, HL + n4, in.getCharset()), Arrays.toString(b));
			throw new Exception(String.format("%s\n%s", e1, e2));
		} else if (log.isInfoEnabled())
			log.info(String.format("\n%s: %s (%5d,%4d)\n[%s]", rx, sx, n1, n2, new String(b, in.getCharset())));

		return b;
	}

	@Override
	public SHCData toObject(byte[] b) throws Exception {
		String sx = new String(b, 17, 4);
		int nx = NumberUtils.toInt(sx);
		Class<? extends SHCData> c = null;
		switch (nx) {
		case 8050:
		case 8051:
			c = SHC8050.class;
			break;
		case 8150:
		case 8151:
			c = SHC8150.class;
			break;
		case 9050:
		case 9051:
			c = SHC9050.class;
			break;
		case 9150:
		case 9151:
			c = SHC9150.class;
			break;
		default:
			throw new Exception(String.format("처리할 수 없는 전문구분번호(%s)입니다.", sx));
		}
		return toObject(b, c);
	}

	@Override
	public void write(byte[] b) throws Exception {
		String s1 = new String(b, 9, 5);
		String s2 = new String(b, 57, 4);
		String sx = new String(b, 17, 4);
		int n1 = NumberUtils.toInt(s1);
		int n2 = NumberUtils.toInt(s2);
		if (log.isInfoEnabled())
			log.info(String.format("\n%s: %s (%5d,%4d)\n[%s]", wx, sx, n1, n2, new String(b, in.getCharset())));
		out.write(b);
		out.flush();
	}

	@Override
	public byte[] toByteArray(SHCData o) throws Exception {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		TDataOutputStream tdos = new TDataOutputStream(baos, charset);
		tdos.writeObject(o);
		tdos.close();
		byte[] b = baos.toByteArray();
		int n1 = b.length;
		int n2 = b.length - HL;
		byte[] a = StringUtils.leftPad(String.valueOf(n1), 5, '0').getBytes();
		System.arraycopy(a, 0, b, 9, 5);
		a = StringUtils.leftPad(String.valueOf(n2), 4, '0').getBytes();
		System.arraycopy(a, 0, b, 57, 4);
		o.a02 = n1;
		o.a07 = n2;
		return b;
	}
}
