package scg.c24.net.transfer;

import java.net.Socket;

import scg.c24.config.CardConfig;
import scg.c24.data.CardData;

public class CardDataTransferFactory {

	public static CardDataTransfer<CardData> create(CardConfig cardConfig, Socket socket, boolean toSCGS)
			throws Exception {
		return cardConfig.getTransferType().getConstructor(CardConfig.class, Socket.class, boolean.class)
				.newInstance(cardConfig, socket, toSCGS);
	}
}
