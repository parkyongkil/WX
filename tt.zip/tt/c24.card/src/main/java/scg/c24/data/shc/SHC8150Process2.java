package scg.c24.data.shc;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.interceptor.TransactionAspectSupport;

import scg.c24.biz.db.gen.model.C1atTransAcnt;
import scg.c24.biz.db.gen.model.C1atTransAcntMapper;
import scg.c24.biz.db.gen.model.C1atTransAcntReq;
import scg.c24.biz.db.gen.model.C1atTransAcntReqMapper;
import scg.c24.biz.db.gen.model.C1btReqInfo;
import scg.c24.biz.db.gen.model.C1btReqInfoMapper;
import scg.c24.biz.db.gen.model.C1btUseContTrans;
import scg.c24.biz.db.gen.model.C1btUseContTransExample;
import scg.c24.biz.db.gen.model.C1btUseContTransMapper;
import scg.c24.biz.db.gen.model.C2dtEbppAutoCnl;
import scg.c24.biz.db.shc.model.SHCUseContAll;
import scg.c24.biz.db.shc.model.SHCUseContCheck;
import scg.c24.biz.db.shc.model.SHCUseContMapper;
import scg.c24.biz.db.shc.model.SHCUseContTrans;
import scg.c24.net.process.CardProcess;
import scg.c24.net.server.shc.SHCServerService;
import scg.c24.util.CardCodeUtil;
import scg.c24.util.CardCom;

@Component
@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Throwable.class)
public class SHC8150Process2 implements CardProcess<SHC8150, SHC8150> {

	@Autowired
	private SHCUseContMapper mUseContMapper;

	@Autowired
	private C1atTransAcntMapper mTransAcnt;

	@Autowired
	private C1atTransAcntReqMapper mTransAcntReq;

	@Autowired
	private C1btUseContTransMapper mUseContTrans;

	@Autowired
	private C1btReqInfoMapper mReqInfo;

	@Override
	public SHC8150 process(SHC8150 q) throws Exception {
		SHC8150 r = new SHC8150();
		SHCServerService.setResponseHeader(q, r);
		if (!process0(q, r))
			TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
		return r;
	}

	private boolean process0(SHC8150 q, SHC8150 r) throws Exception {

		final String payMethodCd = "30"; // 카드신청
		final String receiveSecCd = "6"; // 은행 또는 카드사로부터 유입된 요청
		final String cnlWhyCd = "10"; // 납부방법변경
		final String cnlGubn = "1"; // 1=단건취소(현재계약), 2=전체계약취소

		String s = q.b01;
		if (StringUtils.isBlank(s) || !s.matches("^[123]$")) {
			r.a08 = "99";
			r.err = String.format("(1001)인자값오류(b01=%s)", s);
			return false;
		}

		CardCom c = CardCom.getByCardCid(q.a03);
		if (c == null)
			throw new Exception(String.format("유효하지 않은 카드사아이디(%s)입니다.", q.a03));

		Date d = new Date();

		if (s.matches("^[12]$"))
			return process1(q, r, c, payMethodCd, receiveSecCd, d);
		else
			return process3(q, r, c, payMethodCd, receiveSecCd, cnlWhyCd, cnlGubn, false, false, d);
	}

	private boolean process1(SHC8150 q, SHC8150 r, CardCom c, String payMethodCd, String receiveSecCd, Date d)
			throws Exception {

		String contNum = q.b12;
		String cardNum = q.b02;
		String reqYmd = q.b09;

		SHCUseContCheck u = mUseContMapper.selectUseContCheck(contNum, cardNum, reqYmd);

		if (u == null) {
			r.a08 = "10";
			r.err = "(1101)사용계약미존재오류";
			return false;
			// C11.C1BT_USE_CONT 존재하지 않는 계약번호
		}
		if ("0".equals(u.getCHK_1())) {
			r.a08 = "20";
			r.err = "(1102)사용계약해지상태오류";
			return false;
			// C1BT_USE_CONT.CONT_STS_CD == 30 상태임
		}
		if ("0".equals(u.getCHK_2())) {
			r.a08 = "30";
			r.err = "(1103)기신청자료 ";
			return false;
			// C1BT_USE_CONT_TRANS 테이블에 동일한 (사용계약번호, 카드번호, 신청일자) 데이터가 있음.
		}
		if ("0".equals(u.getCHK_3())) {
			r.a08 = "40";
			r.err = "(1104)임시고객번호오류";
			return false;
			// 고객번호가 "0" 으로 시작함.
		}
		if ("2".equals(u.getCHK_4()) && "30".equals(payMethodCd)) {
			r.a08 = "50";
			r.err = "(1105)비가정용신청오류";
			return false;
			// C21.PKS_C2_FUNC_4.FUNC_GET_PAY_INF(A.USE_CONT_NUM, '7') == 2.
		}

		SHCUseContTrans t = mUseContMapper.selectUseContTrans(contNum, c.getBnkCd());

		if (t == null) {
			r.a08 = "99";
			r.err = "(1205)사용계약유실오류";
			return false;
		}
		if ("Y".equals(t.getTRANS_YN())) {
			// 이체중인 상태로 해지 실시
			int n = mUseContMapper.selectPayPot20(contNum);
			if (n > 0) {
				r.a08 = "55";
				r.err = "(1206)납부자통합고객변경불가";
				return false;
				// C21.C2BT_PAY_TOT_OBJ * C11.C1BT_REQ_INFO 테이블에
				// 동일 계약번호 A.ADD_YN = 'Y', B.PAY_METHOD_CD = '20' 존제
			}
			// 취소 신청처리 (이체중이르모 취소 처리 후 신청 진행)
			if (process3(q, r, c, payMethodCd, receiveSecCd, "40", "1", false, true, d) == false) {
				r.a08 = "55";
				r.err = "(1207)사용계약 변경(해지)중 오류";
				return false;
			}
		} else {
			int n = mUseContMapper.selectPayPot10(contNum);
			if (n > 0) {
				r.a08 = "55";
				r.err = "(1208)납부자통합고객신청불가";
				return false;
			}
		}

		String custNum = t.getCUST_NUM();
		String mst = mUseContMapper.selectReceiveStsCheck(custNum, cardNum);
		// mst 값
		// blank : 계좌없음 -> 신규생성
		// 11, 30, 40 : 접수취소, 해지, 오류 -> 변경 + 신규
		// 10, 20 : 접수, 정상 -> 신규

		// 자동이체는 접수 , 카드이체는 바로 정상, payMethod: 10=지로, 20=은행, 30=카드
		String tmpStsCd = "20".equals(payMethodCd) ? "10" : "20";

		Date date = new Date();
		if (StringUtils.isBlank(mst)) {
			// 신규생성
			if (insertTransAcnt(q, c, t, payMethodCd, receiveSecCd, date) != 1) {
				r.a08 = "99";
				r.err = "(1301)이체계좌생성오류";
				return false;
			}
			if (insertTransAcntReq(q, c, t, payMethodCd, receiveSecCd, date) != 1) {
				r.a08 = "99";
				r.err = "(1302)이체계좌신청생성오류";
				return false;
			}
			if (insertUseContTrans(q, c, t, payMethodCd, tmpStsCd, date) != 1) {
				r.a08 = "99";
				r.err = "(1303)사용계약이체생성오류";
				return false;
			}

		} else if (mst.matches("^(11|30|40)$")) {
			// 변경 + 신규
			if (updateTransAcnt(q, c, t, payMethodCd, receiveSecCd, date) != 1) {
				r.a08 = "99";
				r.err = "(1401)이체계좌변경오류";
				return false;
			}
			if (insertTransAcntReq(q, c, t, payMethodCd, receiveSecCd, date) != 1) {
				r.a08 = "99";
				r.err = "(1402)이체계좌신청생성오류";
				return false;
			}
			if (insertUseContTrans(q, c, t, payMethodCd, tmpStsCd, date) != 1) {
				r.a08 = "99";
				r.err = "(1403)사용계약이체생성오류";
				return false;
			}

		} else if (mst.matches("^(10|20)$")) {
			// 신규
			if (insertUseContTrans(q, c, t, payMethodCd, receiveSecCd, date) != 1) {
				r.a08 = "99";
				r.err = "(1501)사용계약이체생성오류";
				return false;
			}
		}

		if ("20".equals(mst) || "30".equals(payMethodCd)) {
			// 은행이체, 정상 && 카드이체 -> 납부방법변경
			if (updateReqInfo(q, c, payMethodCd, date) == 0) {
				r.a08 = "99";
				r.setErr("(1601)청구정보변경오류");
				return false;
			}
		}
		return true;
	}

	private boolean process3(SHC8150 q, SHC8150 r, CardCom c, String payMethodCd, String receiveSecCd, String cnlWhyCd,
			String cnlGubn, boolean ebppCnl, boolean ing, Date d) throws Exception {

		if (StringUtils.isBlank(cnlWhyCd) || !cnlWhyCd.matches("^(10|40)$")) {
			r.a08 = "99";
			r.err = String.format("(3001)코드오류(cnlWhy=%s)", cnlWhyCd);
			return false;
		}

		if (StringUtils.isBlank(cnlGubn) || !cnlGubn.matches("^(1|2)$")) {
			r.a08 = "99";
			r.err = String.format("(3002)코드오류(cnlGubn=%s)", cnlGubn);
			return false;
		}

		String contNum = q.b12;
		if (!ing && mUseContMapper.selectPayPot10(contNum) > 0) {
			r.a08 = "55";
			r.err = "(3101)납부자통합해지불가";
			return false;
		}

		SHCUseContCheck u = "10".equals(cnlWhyCd) ? mUseContMapper.selectUseContCheck10(contNum, c.getBnkCd())
				: mUseContMapper.selectUseContCheck40(contNum);
		if (u == null) {
			r.a08 = "10";
			r.err = "(3102)사용계약미존재오류";
			return false;
		}
		if ("0".equals(u.getCHK_1())) {
			r.a08 = "50";
			r.err = "(3103)납부방법오류";
			return false;
		}
		final String receiveStsCd = "30";
		if ("1".equals(cnlGubn)) {
			cancel_cont(q, c, payMethodCd, receiveSecCd, receiveStsCd, cnlWhyCd, ebppCnl, d);
		} else {
			List<SHCUseContAll> al = mUseContMapper.selectUseContAllByUseContNum(contNum);
			for (SHCUseContAll a : al) {
				q.setB12(a.getREQ_INFO_NUM());
				cancel_cont(q, c, payMethodCd, receiveSecCd, receiveStsCd, cnlWhyCd, ebppCnl, d);
			}
		}
		return true;
	}

	private void cancel_cont(SHC8150 q, CardCom c, String payMethodCd, String receiveSecCd, String receiveStsCd,
			String cnlWhyCd, boolean ebppCnl, Date d) throws Exception {

		String billSendMethodCd = ebppCnl ? "10" : null;
		String emailSendYn = ebppCnl ? "N" : null;

		if (updateReqInfoForCancel(q, c, payMethodCd, billSendMethodCd, emailSendYn, d) == 0)
			throw new Exception("(8001)기요청수정오류");

		if (ebppCnl) {
			String reqFlag = "2";
			String receiveFlag = "20";
			if (mergeEbppForCancel(q, c, reqFlag, receiveFlag, d) == 0)
				throw new Exception("(8002)기요청처리수정오류");
		}

		if (updateUseContTransForCancel(q, c, receiveSecCd, receiveStsCd, cnlWhyCd, d) == 0)
			throw new Exception("(8002)기요청처리수정오류");
	}

	protected int updateTransAcntForCancel(SHC8150 q, CardCom c, SHCUseContTrans t, String receiveStsCd,
			String cnlWhyCd, Date d) {

		C1atTransAcnt b1 = new C1atTransAcnt();
		b1.setUpdDtm(d);
		b1.setUpdEmpid(c.getName());
		b1.setUpdIp("**.**.**.**");
		b1.setReceiveStsCd(receiveStsCd);
		b1.setCnlYmd(DateFormatUtils.format(d, "yyyyMMdd"));
		b1.setCnlWhyCd(cnlWhyCd);
		b1.setDefrayAccountNum(q.b02);
		b1.setCustNum(t.getCUST_NUM());
		return mTransAcnt.updateByPrimaryKeySelective(b1);
	}

	private int insertTransAcnt(SHC8150 q, CardCom c, SHCUseContTrans t, String payMethodCd, String receiveSecCd,
			Date d) {

		C1atTransAcnt b = new C1atTransAcnt();
		b.setDefrayAccountNum(q.b02);
		b.setCustNum(t.getCUST_NUM());
		b.setCrtEmpid(c.getName());
		b.setUpdIp("**.**.**.**");
		b.setTranFlag(CardCodeUtil.DECODE_TRAN_FLAG(payMethodCd));
		b.setBnkCd(c.getBnkCd());
		b.setReceivePlcFlagCd(CardCodeUtil.DECODE_RECEIVE_PLC_FLAG_CD(receiveSecCd));
		b.setReceiveStsCd(CardCodeUtil.DECODE_RECEIVE_STS_CD(payMethodCd));
		b.setReqYmd(q.b09);
		b.setCnlYmd("99991231");
		b.setCnlWhyCd(" ");
		b.setPayMethodCd(payMethodCd);
		b.setBefoPayManageNum(t.getCUST_NUM());
		b.setAccountBranchCd(String.format("%s0000", c.getBnkCd()));
		b.setBnkBranchCd(b.getAccountBranchCd());
		b.setSocBizNum(q.b05);
		b.setDepositorNm(q.b04);
		b.setCustRelatCd(q.b10);
		b.setDepositorTelDdd(q.b06);
		b.setDepositorTelExn(q.b07);
		b.setDepositorTelNum(q.b08);
		b.setValidPeriod(q.b15);
		b.setTransYmd(DateFormatUtils.format(d, "yyyyMMdd"));
		return mTransAcnt.insertSelective(b);
	}

	private int updateTransAcnt(SHC8150 q, CardCom c, SHCUseContTrans t, String payMethodCd, String receiveSecCd,
			Date d) {

		C1atTransAcnt b = new C1atTransAcnt();
		b.setUpdDtm(d);
		b.setUpdEmpid(c.getName());
		b.setUpdIp("**.**.**.**");
		b.setTranFlag(CardCodeUtil.DECODE_TRAN_FLAG(payMethodCd));
		b.setBnkCd(c.getBnkCd());
		b.setReceivePlcFlagCd(CardCodeUtil.DECODE_RECEIVE_PLC_FLAG_CD(receiveSecCd));
		b.setReceiveStsCd(CardCodeUtil.DECODE_RECEIVE_STS_CD(payMethodCd));
		b.setReqYmd(q.b09);
		b.setTransYmd(b.getReqYmd());
		b.setCnlYmd("99991231");
		b.setCnlWhyCd(" ");
		b.setPayMethodCd(payMethodCd);
		b.setAccountBranchCd(String.format("%s0000", c.getBnkCd()));
		b.setBnkBranchCd(b.getAccountBranchCd());
		b.setSocBizNum(q.b05);
		b.setDepositorNm(q.b04);
		b.setCustRelatCd(q.b10);
		b.setDepositorTelDdd(q.b06);
		b.setDepositorTelExn(q.b07);
		b.setDepositorTelNum(q.b08);
		b.setValidPeriod(q.b15);
		b.setDefrayAccountNum(q.b02);
		b.setCustNum(t.getCUST_NUM());
		return mTransAcnt.updateByPrimaryKeySelective(b);
	}

	private int insertTransAcntReq(SHC8150 q, CardCom c, SHCUseContTrans t, String payMethodCd, String receiveSecCd,
			Date d) {

		C1atTransAcntReq b = new C1atTransAcntReq();
		b.setDefrayAccountNum(q.b02);
		b.setCustNum(t.getCUST_NUM());
		b.setReqItemCd("01");
		b.setReqYmd(q.b09);
		b.setCrtEmpid(c.getName());
		b.setCrtIp("**.**.**.**");
		b.setBnkCd(c.getBnkCd());
		b.setReqRsltCd(CardCodeUtil.DECODE_RES_RSLT_CD(payMethodCd));
		b.setReceiveSecCd(receiveSecCd);
		b.setCustRelatCd(q.b10);
		b.setReqNm(q.b11);
		b.setReqTelDdd(q.b06);
		b.setReqTelExn(q.b07);
		b.setReqTelNum(q.b08);
		b.setKftcReceiveStsCd("01");
		b.setValidPeriod(q.b15);
		b.setTransYmd(DateFormatUtils.format(d, "yyyyMMdd"));
		b.setApproYmd(b.getTransYmd());
		return mTransAcntReq.insertSelective(b);
	}

	protected int insertTransAcntReqForCancel(SHC8150 q, CardCom c, SHCUseContTrans t, String payMethodCd,
			String receiveSecCd, Date d) {

		C1atTransAcntReq b2 = new C1atTransAcntReq();
		b2.setDefrayAccountNum(q.b02);
		b2.setCustNum(t.getCUST_NUM());
		b2.setReqItemCd("03");
		b2.setReqYmd(q.b09);
		b2.setCrtEmpid(c.getName());
		b2.setCrtIp("**.**.**.**");
		b2.setBnkCd(c.getBnkCd());
		b2.setReqRsltCd(CardCodeUtil.DECODE_RES_RSLT_CD_FOR_CANCEL(payMethodCd));
		b2.setReceiveSecCd(receiveSecCd);
		b2.setCustRelatCd(q.b10);
		b2.setReqNm(q.b11);
		b2.setReqTelDdd(q.b06);
		b2.setReqTelExn(q.b07);
		b2.setReqTelNum(q.b08);
		b2.setKftcReceiveStsCd("03");
		b2.setTransYmd(DateFormatUtils.format(d, "yyyyMMdd"));
		b2.setApproYmd(b2.getTransYmd());
		return mTransAcntReq.insertSelective(b2);
	}

	private int insertUseContTrans(SHC8150 q, CardCom c, SHCUseContTrans t, String payMethodCd, String receiveSecCd,
			Date d) {

		C1btUseContTrans b3 = new C1btUseContTrans();
		b3.setDefrayAccountNum(q.b02);
		b3.setCustNum(t.getCUST_NUM());
		b3.setReqInfoNum(q.b12);
		b3.setReqYmd(q.b09);
		b3.setCrtEmpid(c.getName());
		b3.setCrtIp("**.**.**.**");
		b3.setBnkCd(c.getBnkCd());
		b3.setReceiveStsCd(payMethodCd);
		b3.setReceiveSecCd(receiveSecCd);
		b3.setOrigApplyYm(t.getAPPLY_YMD());
		b3.setCnlYmd("99991231");
		C1btUseContTrans a = mUseContTrans.selectByPrimaryKey(b3);
		System.err.println("a=" + a);
		System.err.println("b3=" + b3);
		return mUseContTrans.insertSelective(b3);
	}

	private int updateReqInfo(SHC8150 q, CardCom c, String payMethodCd, Date d) {

		C1btReqInfo b4 = new C1btReqInfo();
		b4.setUpdDtm(d);
		b4.setUpdEmpid(c.getName());
		b4.setUpdIp("**.**.**.**");
		b4.setPayMethodCd(payMethodCd);
		b4.setReqInfoNum(q.b12);
		return mReqInfo.updateByPrimaryKeySelective(b4);
	}

	@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Throwable.class)
	private int updateReqInfoForCancel(SHC8150 q, CardCom c, String payMethodCd, String billSendMethodCd,
			String emailSendYn, Date d) {

		C1btReqInfo b4 = new C1btReqInfo();
		b4.setUpdDtm(d);
		b4.setUpdEmpid(c.getName());
		b4.setUpdIp("**.**.**.**");
		b4.setPayMethodCd(payMethodCd);
		b4.setBillSendMethodCd(billSendMethodCd);
		b4.setEmailSendYn(emailSendYn);
		b4.setReqInfoNum(q.b12);
		return mReqInfo.updateByPrimaryKeySelective(b4);
	}

	private int mergeEbppForCancel(SHC8150 q, CardCom c, String reqFlag, String receiveFlag, Date d) {

		C2dtEbppAutoCnl b = new C2dtEbppAutoCnl();
		b.setJobId(StringUtils.rightPad(q.b09, 19));
		b.setReqYmd(q.b09);
		b.setUseContNum(q.b12);
		b.setReqFlag(reqFlag);
		b.setCreateYmd(DateFormatUtils.format(d, "yyyyMMdd"));
		b.setCrtTime(DateFormatUtils.format(d, "HHmmss"));
		b.setReceiveFlag(receiveFlag);
		b.setCrtIp("**.**.**.**");
		b.setCrtEmpid(c.getName());
		b.setUpdDtm(d);
		b.setUpdIp(b.getCrtIp());
		b.setUpdEmpid(b.getCrtEmpid());
		return mUseContMapper.mergeEbpp(b);
	}

	private int updateUseContTransForCancel(SHC8150 q, CardCom c, String receiveSecCd, String receiveStsCd,
			String cnlWhyCd, Date d) {

		C1btUseContTrans b = new C1btUseContTrans();
		b.setReqInfoNum(q.b12);
		b.setUpdDtm(d);
		b.setUpdEmpid(c.getName());
		b.setUpdIp("**.**.**.**");
		b.setReceiveStsCd(receiveStsCd);
		b.setReceiveSecCd(receiveSecCd);
		b.setCnlApplyYm(DateFormatUtils.format(d, "yyyyMM"));
		b.setCnlYmd(DateFormatUtils.format(d, "yyyyMMdd"));
		b.setCnlWhyCd(cnlWhyCd);
		b.setCnlCustNm(q.b04);
		b.setCnlCustSocNum(q.b05);
		b.setCnlCustRelatCd(q.b10);
		b.setCnlTelDdd(q.b06);
		b.setCnlTelExn(q.b07);
		b.setCnlTelNum(q.b08);

		List<String> sl = new ArrayList<>();
		sl.add("10");
		sl.add("20");

		C1btUseContTransExample x = new C1btUseContTransExample();
		x.createCriteria().andReqInfoNumEqualTo(b.getReqInfoNum()).andReceiveStsCdIn(sl).andCnlYmdEqualTo("99991231");
		return mUseContTrans.updateByExampleSelective(b, x);
	}
}
