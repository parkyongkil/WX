package scg.c24.net.client.shc;

import java.util.Date;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;

import scg.c24.config.CardConfig;
import scg.c24.data.shc.SHC9050;
import scg.c24.data.shc.SHC9150;
import scg.c24.data.shc.SHCData;
import scg.c24.mis.data.MIS3000q;
import scg.c24.mis.data.MIS3000r;
import scg.c24.mis.data.MIS4000q;
import scg.c24.mis.data.MIS4000r;
import scg.c24.net.client.CardClient;
import scg.c24.net.client.CardClientService;
import scg.c24.net.client.pool.CardClientPool;
import scg.c24.util.CardCom;
import tt.lang.string.StringU;

public class SHCClientService extends CardClientService<CardClient> {

	public SHCClientService(CardConfig cardConfig, CardClientPool<CardClient> pool) {
		super(cardConfig, pool);
	}

	/**
	 * 카드자동납부신청 요청 (3000, 9150)
	 */
	@Override
	public MIS3000r mis3000(MIS3000q mq) {

		if (log.isInfoEnabled())
			log.info(String.format("\nMQ(%s): %s", mq == null ? "X" : mq.getClass().getSimpleName(),
					StringU.toString(mq)));

		MIS3000r mr = new MIS3000r();
		SHC9150 cq = new SHC9150();
		SHC9150 cr = new SHC9150();

		setRequestHeader(cq, CardCom.getByBnkCd(mq.CARD_CD), "9150");

		cq.b01 = mq.TREAT_FLAG;
		cq.b02 = mq.DEFRAY_ACCOUNT_NUM;
		// b03 구카드번호 (사용안함)
		cq.b04 = mq.DEPOSITOR_NM;
		// b05 주민번호 (사용안함)
		cq.b06 = mq.REQ_TEL_DDD;
		cq.b07 = mq.REQ_TEL_EXN;
		cq.b08 = mq.REQ_TEL_NUM;
		cq.b09 = DateFormatUtils.format(new Date(), "yyyyMMdd");
		cq.b10 = mq.CUST_RELAT_CD;
		cq.b11 = mq.CUST_NM;
		cq.b12 = mq.USE_CONT_NUM;
		cq.b13 = "00";
		cq.b14 = mq.ORIG_APPLY_YM;

		try {
			cr = call(cq);

			if (StringUtils.equals(cq.a05, cr.a05)) { // 요청과 응답의 거래번호가 일치하여야 함
				mr.RSLT_CD = cr.a08;
				mr.RSLT_NM = "00".equals(cr.a08) ? "정상" : "오류 응답을 수신하였습니다.";
			} else {
				mr.RSLT_CD = "91";
				mr.RSLT_NM = "요청번호가 일치하지 않는 응답을 수신하였습니다.";
			}
			mr.CARD_STS_CD = cr.b13;

		} catch (Exception e) {
			if (log.isErrorEnabled())
				log.error(e.getMessage(), e);
			mr.RSLT_CD = "99";
			mr.RSLT_NM = String.format("카드사에 요청 중 오류가 발생하였습니다.");
		}

		if (log.isInfoEnabled())
			log.info(String.format("\nMR(%s): %s", mq == null ? "X" : mr.getClass().getSimpleName(),
					StringU.toString(mr)));

		return mr;
	}

	/**
	 * 카드인증조회 요청 (9050)
	 */
	@Override
	public MIS4000r mis4000(MIS4000q mq) {

		if (log.isInfoEnabled())
			log.info(String.format("\nMQ(%s): %s", mq == null ? "X" : mq.getClass().getSimpleName(),
					StringU.toString(mq)));

		MIS4000r mr = new MIS4000r();
		SHC9050 cq = new SHC9050();
		SHC9050 cr = new SHC9050();

		setRequestHeader(cq, CardCom.getByBnkCd(mq.CARD_CD), "9050");

		cq.b01 = mq.CARD_NUM;
		cq.b02 = mq.SOC_BIZ_NUM;
		cq.b03 = mq.DEPOSITOR_NM;
		cq.b04 = "00";

		try {
			cr = call(cq);

			if (StringUtils.equals(cq.a05, cr.a05)) {
				mr.RSLT_CD = cr.a08;
				mr.RSLT_NM = "00".equals(cr.a08) ? "정상" : "오류 응답을 수신하였습니다.";
			} else {
				mr.RSLT_CD = "91";
				mr.RSLT_NM = "거래번호가 일치하지 않는 응답을 수신하였습니다.";
			}

			mr.CARD_STS_CD = cr.b04;
			mr.VALID_YM = StringUtils.substring(cr.b05, 2);

		} catch (Exception e) {
			if (log.isErrorEnabled())
				log.error(e.getMessage(), e);
			mr.RSLT_CD = "99";
			mr.RSLT_NM = "카드사에 요청 중 오류가 발생하였습니다.";
		}

		if (log.isInfoEnabled())
			log.info(String.format("\nMR(%s): %s", mq == null ? "X" : mr.getClass().getSimpleName(),
					StringU.toString(mr)));

		return mr;
	}

	public static void setRequestHeader(SHCData cq, CardCom cc, String cd) {
		String ts = DateFormatUtils.format(new Date(), "yyyyMMddHHmmss");
		String ns = String.valueOf(System.nanoTime()).substring(0, 6);
		String cid = cc.getCid();

		cq.a01 = String.format("DSE%s001", cid);
		// a02 (전체전문길이), 바이너리 전송시 자동계산입력처리됨
		cq.a03 = cid;
		cq.a04 = cd;
		cq.a05 = String.format("XX%s%s", ts, ns);
		cq.a06 = ts;
		// a07 (개별부전문길이), 바이너리 전송시 자동계산입력처리됨
		cq.a08 = "00";
		cq.a09 = cc.getMemberCd();
		cq.a10 = cc.getPartnerCd();
	}
}
