package scg.c24.data.kmc.batch;

import tt.io.annotation.AtLPad;
import tt.io.annotation.AtSize;

public class KMCBAT0401 implements KMCBAT {

	@AtLPad(value = 8, pad = '0')
	public String strSeq;

	@AtSize(8)
	public String strYmd;

	/** 사용계약번호(황정현 주석 추가) */
	@AtSize(20)
	public String useContNum;

	/** 카드번호 */
	@AtSize(16)
	public String cardNum;

	/** 카드주민번호 */
	@AtSize(value = 13, pad = '0')
	public String socNum;

	/** 카드고객명 */
	@AtSize(30)
	public String custNm;

	/** 신청인관계코드 */
	@AtSize(2)
	public String relatCd;

	/** 신청채널구분 */
	@AtSize(1)
	public String pathFlag;

	/** 계약상태코드 */
	@AtSize(2)
	public String stsCd;

	/** 신청인명 */
	@AtSize(30)
	public String reqNm;

	/** 신청인휴대전화번호 */
	@AtSize(4)
	public String cpDdd;

	@AtSize(4)
	public String cpExn;

	@AtSize(4)
	public String cpNum;

	/** 신청인자택전화번호1 */
	@AtSize(4)
	public String ownhouseTelDdd;

	@AtSize(4)
	public String ownhouseTelExn;

	@AtSize(4)
	public String ownhouseTelNum;

	/** 최초출금일 */
	@AtSize(8)
	public String applyYm;

	/** 계약고객명 */
	@AtSize(30)
	public String contCustNm;

	/** 계약우편번호 */
	@AtSize(6)
	public String zipNo;

	/** 계약우편주소 */
	@AtSize(150)
	public String zipAddr;

	/** 계약상세주소 */
	@AtSize(150)
	public String etcAddr;

	@AtSize(88)
	public String ci;

	@AtSize(122)
	public String filler;
}
