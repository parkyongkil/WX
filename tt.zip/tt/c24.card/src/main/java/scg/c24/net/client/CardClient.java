package scg.c24.net.client;

import java.io.IOException;
import java.io.InputStream;
import java.net.Socket;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import scg.c24.config.CardClientConfig;
import scg.c24.config.CardConfig;

public abstract class CardClient {

	protected CardConfig cardConfig;
	protected Socket socket;
	protected Log log = LogFactory.getLog(getClass());

	public CardClient(CardConfig cardConfig) {
		super();
		this.cardConfig = cardConfig;
	}

	public void open() throws Exception {
		CardClientConfig cf = cardConfig.getClient();
		socket = new Socket(cf.getHost(), cf.getPort());
		socket.setSoTimeout(cf.getTimeout());
		Runtime.getRuntime().addShutdownHook(new Thread() {
			@Override
			public void run() {
				if (log.isInfoEnabled())
					log.info(String.format("%s(%s, %s:%d) Shutdown.", getClass().getSimpleName(), cardConfig.getUid(),
							cardConfig.getClient().getHost(), cardConfig.getClient().getPort()));
				close();
			}
		});
		if (log.isInfoEnabled())
			log.info(String.format("%s(%s, %s:%d) Created.", getClass().getSimpleName(), cardConfig.getUid(),
					cardConfig.getClient().getHost(), cardConfig.getClient().getPort()));
	}

	public void close() {
		if (socket != null) {
			try {
				socket.close();
			} catch (Exception e) {
				if (log.isErrorEnabled())
					log.error(e.getMessage(), e);
			}
			socket = null;
			if (log.isInfoEnabled())
				log.info(String.format("%s(%s, %s:%d) Closed.", getClass().getSimpleName(), cardConfig.getUid(),
						cardConfig.getClient().getHost(), cardConfig.getClient().getPort()));
		}
	}

	public boolean validate() {
		try {
			return socket != null && socket.isConnected() && socket.getInputStream().available() != -1;
		} catch (Exception e) {
			return false;
		}
	}

	public void clear() throws IOException {
		InputStream in = socket.getInputStream();
		while (in.available() > 0) {
			byte[] b = new byte[in.available()];
			int n = in.read(b);
			if (log.isErrorEnabled())
				log.error(String.format("%s(%s, %s:%d) [%d] Cleared Rest-Data.\n[%s]", getClass().getSimpleName(),
						cardConfig.getUid(), cardConfig.getClient().getHost(), cardConfig.getClient().getPort(), n,
						new String(b, cardConfig.getCharset())));
		}
	}

	public abstract <Q, R> R call(Q q) throws Exception;
}
