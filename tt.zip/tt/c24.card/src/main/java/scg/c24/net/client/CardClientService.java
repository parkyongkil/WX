package scg.c24.net.client;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import scg.c24.config.CardConfig;
import scg.c24.mis.data.MIS3000q;
import scg.c24.mis.data.MIS3000r;
import scg.c24.mis.data.MIS4000q;
import scg.c24.mis.data.MIS4000r;
import scg.c24.net.client.pool.CardClientPool;

public abstract class CardClientService<T extends CardClient> {

	protected CardConfig cardConfig;
	protected CardClientPool<T> pool;
	protected Log log = LogFactory.getLog(getClass());

	public CardClientService(CardConfig cardConfig, CardClientPool<T> pool) {
		super();
		this.cardConfig = cardConfig;
		this.pool = pool;
	}

	public <X> X call(Object q) throws Exception {
		T t = null;
		try {
			t = pool.borrowObject();
			return t.call(q);
		} catch (Exception e) {
			if (t != null) {
				pool.invalidateObject(t);
				t = null;
			}
			throw e;
		} finally {
			if (t != null)
				pool.returnObject(t);
		}
	}

	/**
	 * 카드자동납부신청 요청 (3000, 9150)
	 */
	public abstract MIS3000r mis3000(MIS3000q mq);

	/**
	 * 카드인증조회 요청 (4000, 9050)
	 */
	public abstract MIS4000r mis4000(MIS4000q mq);
}
