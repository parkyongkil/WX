package scg.c24.data.kmc;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import scg.c24.biz.db.kmc.model.KMCUseCont;
import scg.c24.biz.db.kmc.model.KMCUseContMapper;
import scg.c24.net.process.CardProcess;
import scg.c24.net.server.kmc.KMCServerService;

@Component
public class KMC1000Process implements CardProcess<KMC1000, KMC1000> {

	@Autowired
	KMCUseContMapper m1;

	@Override
	public KMC1000 process(KMC1000 q) throws Exception {

		KMC1000 r = new KMC1000();
		KMCServerService.setResponseHeader(q, r);

		List<KMCUseCont> ucs = StringUtils.isNotBlank(q.b01) ? m1.selectUseContByUseContNum(q.b01)
				: m1.selectUseContByUseCustNmCp(q.b06, q.b10, q.b11, q.b12);

		if (ucs != null && ucs.size() > 0) {
			KMCUseCont u = ucs.get(0);

			r.b01 = u.getUSE_CONT_NUM();
			r.b02 = u.getCONT_STS();
			r.b03 = u.getPAY_METHOD_CD();
			r.b04 = u.getBNK_NM();
			r.b05 = u.getFIRST_YMD();
			r.b06 = u.getCUST_NM();
			r.b07 = u.getZIP_NO();
			r.b08 = u.getADDR1();
			r.b09 = u.getADDR2();
			r.b10 = u.getCP_DDD();
			r.b11 = u.getCP_EXN();
			r.b12 = u.getCP_NUM();
		} else {
			r.a07 = "검색결과자료없음";

			r.b01 = "00";
			r.b02 = null;
			r.b03 = null;
			r.b04 = null;
			r.b05 = null;
			r.b06 = null;
			r.b07 = null;
			r.b08 = null;
			r.b09 = null;
			r.b10 = null;
			r.b11 = null;
			r.b12 = null;
		}
		return r;
	}
}
