package scg.c24.data.kmc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.sql.DataSource;

import org.apache.commons.lang3.math.NumberUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import scg.c24.biz.db.TransAcntCnl;
import scg.c24.biz.db.TransAcntReq;
import scg.c24.net.process.CardProcess;
import scg.c24.net.server.kmc.KMCServerService;
import scg.c24.util.CardCom;

@Component
public class KMC2000Process implements CardProcess<KMC2000, KMC2000> {

	private Log log = LogFactory.getLog(getClass());

	@Override
	public KMC2000 process(KMC2000 q) throws Exception {
		KMC2000 r = new KMC2000();
		KMCServerService.setResponseHeader(q, r);

		CardCom c = CardCom.getByCardCid(q.a02);

		switch (NumberUtils.toInt(q.b01)) {
		case 1:
		case 2:
			TransAcntReq objReq = new TransAcntReq(q.b03, c.getBnkCd(), q.b02, q.b04, q.b05, q.b06, q.b07, q.b08, q.b09,
					q.b10, q.b11, q.b12, q.b13, q.b14, "30", "6", null, q.b20, q.b21);
			return process0(q, r, objReq.start());
		case 3:
			TransAcntCnl objCnl = new TransAcntCnl(q.b03, "10", q.b08, q.b05, q.b07, q.b09, q.b10, q.b11, "1", "N", "6",
					null, false, null, q.b21);
			return process0(q, r, objCnl.start());
		case 4:
			return process4(q, r);
		default:
			throw new Exception(String.format("처리할 수 없는 처리요청구분(%s)입니다.", q.b01));
		}
	}

	@Autowired
	DataSource dataSource;

	private KMC2000 process0(KMC2000 q, KMC2000 r, int result) throws Exception {

		Connection scg_conn = null;
		PreparedStatement scg_ps = null;
		ResultSet scg_rs = null;

		String useContNum = q.b02;

		if (result == 0) {
			try {
				scg_conn = dataSource.getConnection();
				scg_ps = scg_conn.prepareStatement(sqlenqUseContNum);
				scg_ps.setString(1, useContNum);
				scg_ps.setString(2, useContNum);
				scg_rs = scg_ps.executeQuery();
				boolean b = !scg_rs.next();

				if (scg_rs.next()) {
					r.b15 = b ? null : scg_rs.getString("FIRST_YMD");
					r.b16 = b ? null : scg_rs.getString("CUST_NM");
					r.b17 = b ? null : scg_rs.getString("ZIP_NO");
					r.b18 = b ? null : scg_rs.getString("ADDR1");
					r.b19 = b ? null : scg_rs.getString("ADDR2");
					r.b21 = b ? null : scg_rs.getString("JOIN_YN");
				} else {
					r.a06 = "1000";
					r.a07 = "카드이체사용안함";
				}

			} catch (Exception e) {
				r.a06 = "2099";
				r.a07 = "SCG전산오류";
				log.error(e.getMessage(), e);
			} finally {
				close(scg_rs, scg_ps, scg_conn);
			}
			return r;
		}

		switch (result) {
		case 10:
			r.a06 = "2010";
			r.a07 = "사용계약번호 없음";
			return r;
		case 20:
			r.a06 = "2020";
			r.a07 = "계약상태 오류";
			return r;
		case 30:
			r.a06 = "2030";
			r.a07 = "기신청자료";
			return r;
		case 40:
			r.a06 = "2040";
			r.a07 = "임시고객번호 오류";
			return r;
		case 50:
			r.a06 = "2050";
			r.a07 = "납부방법 오류(해지시)";
			return r;
		case 55:
			r.a06 = "2055";
			r.a07 = "합산청구세대 신청불가";
			return r;
		case 90:
			r.a06 = "2090";
			r.a07 = "비가정용 신청 오류";
			return r;
		case 98:
			r.a06 = "2098";
			r.a07 = "매개변수 오류";
			return r;
		default:
			r.a06 = "2099";
			r.a07 = "SCG전산오류";
			return r;
		}
	}

	private KMC2000 process4(KMC2000 q, KMC2000 r) throws Exception {

		Connection scg_conn = null;
		PreparedStatement scg_ps = null;
		ResultSet scg_rs = null;

		String useContNum = q.b02;

		try {
			String sqlSelect = "SELECT /*+ index_desc(c C1AX_0_TRANS_ACNT_REQ) */ " + "       D.USE_CONT_NUM "
					+ "     , B.DEFRAY_ACCOUNT_NUM " + "     , trim(B.VALID_PERIOD) VALID_PERIOD "
					+ "     , B.SOC_BIZ_NUM " + "     , B.DEPOSITOR_NM " + "     , C.CUST_RELAT_CD "
					+ "     , C.REQ_NM " + "     , C.REQ_TEL_DDD " + "     , C.REQ_TEL_EXN " + "     , C.REQ_TEL_NUM "
					+ "     , B.DEPOSITOR_TEL_DDD " + "     , B.DEPOSITOR_TEL_EXN " + "     , B.DEPOSITOR_TEL_NUM "
					+ "     , C21.PKS_C2_FUNC_4.FUNC_GET_C1_ORIG_APPLY_YMD(D.USE_CONT_NUM) FIRST_YMD "
					+ "     , E.CUST_NM " + "     , G.ZIP_NO1 || G.ZIP_NO2 ZIP_NO "
					+ "     , G.CITY || ' ' || G.COUNTY || ' ' || G.TOWN ADDR1 "
					+ "     , substr(F.CURR_ADDR_UNION, LENGTH(G.CITY || ' ' || G.COUNTY || ' ' || G.TOWN || ' ') + 1) ADDR2 "
					+ "     , C.REQ_YMD " + "     , A.JOIN_YN " + "  FROM C11.C1BT_USE_CONT_TRANS A "
					+ "     , C11.C1AT_TRANS_ACNT B " + "     , C11.C1AT_TRANS_ACNT_REQ C "
					+ "     , C11.C1BT_USE_CONT D " + "     , C11.C1AT_CUST_INFO E " + "     , C31.C3AT_INST_PLACE F "
					+ "     , A11.A1AT_ZIP G " + " WHERE A.CUST_NUM = B.CUST_NUM "
					+ "   AND A.DEFRAY_ACCOUNT_NUM = B.DEFRAY_ACCOUNT_NUM " + "   AND A.RECEIVE_STS_CD = '20' "
					+ "   AND B.TRAN_FLAG = '20' " + "   AND B.BNK_CD = '807' "
					+ "   AND B.DEFRAY_ACCOUNT_NUM = C.DEFRAY_ACCOUNT_NUM " + "   AND B.CUST_NUM = C.CUST_NUM "
					+ "   AND C.REQ_ITEM_CD IN('01', '02') " + "   AND A.REQ_INFO_NUM = D.REQ_INFO_NUM "
					+ "   AND D.USE_CONT_NUM = ? " + "   AND D.CUST_NUM = E.CUST_NUM "
					+ "   AND D.INST_PLACE_NUM = F.INST_PLACE_NUM " + "   AND F.ZIP_SEQ = G.ZIP_SEQ "
					+ "   AND rownum = 1 ";

			scg_conn = dataSource.getConnection();
			scg_ps = scg_conn.prepareStatement(sqlSelect);
			scg_ps.setString(1, useContNum);
			scg_rs = scg_ps.executeQuery();

			if (scg_rs.next()) {
				r.b03 = scg_rs.getString("DEFRAY_ACCOUNT_NUM");
				r.b04 = scg_rs.getString("VALID_PERIOD");
				r.b05 = scg_rs.getString("SOC_BIZ_NUM");
				r.b06 = scg_rs.getString("DEPOSITOR_NM");
				r.b07 = scg_rs.getString("CUST_RELAT_CD");
				r.b08 = scg_rs.getString("REQ_NM");
				r.b09 = scg_rs.getString("REQ_TEL_DDD");
				r.b10 = scg_rs.getString("REQ_TEL_EXN");
				r.b11 = scg_rs.getString("REQ_TEL_NUM");
				r.b12 = scg_rs.getString("DEPOSITOR_TEL_DDD");
				r.b13 = scg_rs.getString("DEPOSITOR_TEL_EXN");
				r.b14 = scg_rs.getString("DEPOSITOR_TEL_NUM");
				r.b15 = scg_rs.getString("FIRST_YMD");
				r.b16 = scg_rs.getString("CUST_NM");
				r.b17 = scg_rs.getString("ZIP_NO");
				r.b18 = scg_rs.getString("ADDR1");
				r.b19 = scg_rs.getString("ADDR2");
				r.b21 = scg_rs.getString("JOIN_YN");
			} else {
				r.a06 = "1000";
				r.a07 = "카드이체사용안함";
			}

		} catch (Exception e) {
			r.a06 = "2099";
			r.a07 = "SCG전산오류";
			log.error(e.getMessage(), e);
			return r;
		} finally {
			close(scg_rs, scg_ps, scg_conn);
		}

		return r;
	}

	private final static String sqlenqUseContNum = "SELECT decode(A.CONT_STS_CD, '20', '10', A.CONT_STS_CD) CONT_STS "
			+ "     , C.PAY_METHOD_CD " + "     , (SELECT MAX(X.BNK_BRANCH_NM) " + "          FROM E41.E4BT_BANK X "
			+ "             , C11.C1BT_USE_CONT_TRANS Y " + "         WHERE X.BNK_BRANCH_CD = Y.BNK_CD "
			+ "           AND X.USE_YN = 'Y' " + "           AND Y.CUST_NUM = A.CUST_NUM "
			+ "           AND Y.REQ_INFO_NUM = A.REQ_INFO_NUM " + "           AND Y.RECEIVE_STS_CD = '20') BNK_NM "
			+ "     , C21.PKS_C2_FUNC_4.FUNC_GET_C1_ORIG_APPLY_YMD(A.USE_CONT_NUM) FIRST_YMD " + "     , B.CUST_NM "
			+ "     , E.ZIP_NO1 || E.ZIP_NO2 ZIP_NO " + "     , E.CITY || ' ' || E.COUNTY || ' ' || E.TOWN ADDR1 "
			+ "     , substr(D.CURR_ADDR_UNION, LENGTH(E.CITY || ' ' || E.COUNTY || ' ' || E.TOWN || ' ') + 1) ADDR2 "
			+ "      ,A.USE_CONT_NUM " + "      ,B.CP_DDD " + "      ,B.CP_EXN " + "      ,B.CP_NUM "
			+ ",(SELECT Y.JOIN_YN  " + "        FROM C11.C1BT_USE_CONT_TRANS Y "
			+ "        WHERE  Y.CUST_NUM = A.CUST_NUM  " + "        AND Y.REQ_INFO_NUM = A.REQ_INFO_NUM  "
			+ "        AND Y.RECEIVE_STS_CD = '20') AS JOIN_YN " + "  FROM C11.C1BT_USE_CONT A "
			+ "     , C11.C1AT_CUST_INFO B " + "     , C11.C1BT_REQ_INFO C " + "     , C31.C3AT_INST_PLACE D "
			+ "     , A11.A1AT_ZIP E " + " WHERE A.CUST_NUM = B.CUST_NUM " + "   AND A.REQ_INFO_NUM = C.REQ_INFO_NUM "
			+ "   AND A.INST_PLACE_NUM = D.INST_PLACE_NUM " + "   AND D.ZIP_SEQ = E.ZIP_SEQ "
			+ "   AND A.USE_CONT_NUM = ? " + "UNION ALL "
			+ "SELECT '00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL " + "  FROM dual "
			+ " WHERE NOT EXISTS(SELECT 1 " + "                    FROM C11.C1BT_USE_CONT "
			+ "                   WHERE USE_CONT_NUM = ?) ";

	public void close(AutoCloseable... oa) {
		if (oa != null)
			for (AutoCloseable o : oa)
				if (o != null)
					try {
						o.close();
					} catch (Exception e) {
						log.error(e.getMessage(), e);
					}
	}
}
