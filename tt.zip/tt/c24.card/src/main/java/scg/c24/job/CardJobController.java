package scg.c24.job;

import java.util.Properties;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import scg.c24.config.CardConfig;

@RestController
@RequestMapping("job")
public class CardJobController {

	Log log = LogFactory.getLog(getClass());

	@Autowired
	CardConfig cardConfig;

	@RequestMapping("run")
	public String run(String jobName, String jobValues) {
		try {
			String s = String.format("%s.%s", CardJob.class.getPackage().getName(), jobName);
			Class<?> c = Class.forName(s);
			CardJob j = (CardJob) c.newInstance();
			if (jobValues != null) {
				Properties p = new Properties();
				String[] aa = jobValues.split("[\n\r]+");
				for (String a : aa) {
					String[] b = a.split("=", 2);
					if (b.length == 2)
						p.setProperty(b[0], b[1]);
				}
				BeanUtils.copyProperties(p, j);
			}
			Thread t = new Thread(j);
			t.start();
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			return e.getMessage();
		}
		return "OK";
	}
}
