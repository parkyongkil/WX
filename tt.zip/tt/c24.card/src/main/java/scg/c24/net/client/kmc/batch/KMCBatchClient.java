package scg.c24.net.client.kmc.batch;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import scg.c24.config.CardClientConfig;
import scg.c24.config.CardConfig;
import scg.c24.util.CardSysUtil;

public class KMCBatchClient {

	private static final int MSG_LEN = 700; // 황정현 수정 600 -> 700
	// 최대전문길이
	private static final int MAX_LEN = 4096;
	// 최대파일갯수
	private static final int MAX_FILE_NO = 2;
	// 1블록당 seq 갯수
	private static final int MAX_SEQ_NO = 100;
	// 1seq당 전문라인 갯수
	private static final int BLOCK_SEQ_NO = 5;
	// 송신파일폴더
	// private static final String SEND_PATH = "./sendFile/";

	private CardConfig cardConfig;

	private Socket sock;
	private String host;
	private int port;
	private int timeout;
	private BufferedInputStream bis;
	private BufferedOutputStream bos;
	private FileInputStream fis;
	private Log log = LogFactory.getLog(getClass());

	private String SEND_PATH;
	private String[] sendFileNm = new String[MAX_FILE_NO];
	private int[] sendFileSize = new int[MAX_FILE_NO];

	public KMCBatchClient(CardConfig cardConfig, String fileNm) {
		this.cardConfig = cardConfig;
		this.sendFileNm[0] = fileNm;
		this.sendFileNm[1] = null;
		this.init();
	}

	public KMCBatchClient(CardConfig cardConfig, String fileNm1, String fileNm2) {
		this.cardConfig = cardConfig;
		this.sendFileNm[0] = fileNm1;
		this.sendFileNm[1] = fileNm2;
		this.init();
	}

	private void init() {
		String uid = cardConfig.getUid();
		this.SEND_PATH = String.format("%s/%s/sendFile/", cardConfig.getFilePath(), uid);
		CardClientConfig cf = cardConfig.getClient();
		this.host = cf.getHost();
		this.port = cf.getPort();
		this.timeout = cf.getTimeout();
	}

	public boolean start() throws Exception {
		for (int i = 0; i < MAX_FILE_NO; i++) {
			if (sendFileNm[i] != null) {
				File tempfile = new File(SEND_PATH, CardSysUtil.toKMCDatePath(sendFileNm[i]));
				if (!tempfile.exists()) {
					log.error("!KBBatchClient.fileCheck error : " + sendFileNm[i]);
					return false;
				}
				sendFileSize[i] = (int) tempfile.length();
			}
		}

		try {
			sock = new Socket();
			sock.connect(new InetSocketAddress(host, port), timeout);
			// sock.setSoTimeout(timeout);
			sock.setSoTimeout(300000);
			bis = new BufferedInputStream(sock.getInputStream());
			bos = new BufferedOutputStream(sock.getOutputStream());

			if (!handle()) {
				log.error("!KBBatchClient.Process error");
			} else {
				log.error("KBBatchClient.Process success");
			}

		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (fis != null)
				try {
					fis.close();
				} catch (Exception e) {
				}
			if (bis != null)
				try {
					bis.close();
				} catch (Exception e) {
				}
			if (bos != null)
				try {
					bos.close();
				} catch (Exception e) {
				}
			if (sock != null)
				try {
					sock.close();
				} catch (Exception e) {
				}
		}

		return true;
	}

	private boolean handle() {

		byte[] readByte = new byte[MAX_LEN];

		String dutyFlag = "FTP";
		String instiCd = "SCG";
		String msgClass;
		String trFlag = "S";
		String sndFlag = "C";
		String fileNm;
		String rspnCd;

		/*
		 * START! send 600/001 -> receive 610/001
		 */

		try {
			msgClass = "0600";
			fileNm = "";
			rspnCd = "000";

			String manInf = "001";
			String sendId = "SCG";
			String sendPw = "";

			String outMsg = dutyFlag + StringUtils.rightPad(instiCd, 4) + msgClass + trFlag + sndFlag
					+ StringUtils.rightPad(fileNm, 8) + rspnCd + new SimpleDateFormat("MMddHHmmss").format(new Date())
					+ manInf + StringUtils.rightPad(sendId, 20) + StringUtils.rightPad(sendPw, 16);

			write(outMsg);

			readByte = read();

			log.info(String.format("read: [%s]", new String(readByte)));

		} catch (Exception e) {
			log.error("KBBatchClient.handle().Exception(START) :" + e.toString(), e);
			return false;
		}
		/*
		 * File send process
		 */
		if (!fileSend()) {
			return false;
		}

		/*
		 * END! send 600/004 -> receive 610/004
		 */
		try {
			msgClass = "0600";
			fileNm = "";
			rspnCd = "000";

			String manInf = "004";
			String sendId = "SCG";
			String sendPw = "";

			String outMsg = dutyFlag + StringUtils.rightPad(instiCd, 4) + msgClass + trFlag + sndFlag
					+ StringUtils.rightPad(fileNm, 8) + rspnCd + new SimpleDateFormat("MMddHHmmss").format(new Date())
					+ manInf + StringUtils.rightPad(sendId, 20) + StringUtils.rightPad(sendPw, 16);

			write(outMsg);

			readByte = read();

		} catch (Exception e) {
			log.error("KBBatchClient.handle().Exception(END) :" + e.toString(), e);
			return false;
		}

		return true;
	}

	private boolean fileSend() {
		byte[] readByte = new byte[MAX_LEN];

		String dutyFlag = "FTP";
		String instiCd = "SCG";
		String msgClass;
		String trFlag = "S";
		String sndFlag = "C";
		String fileNm;
		String rspnCd;

		String manInf;

		int blockNo = 0;
		int blockSeq = 0;
		int seqNo = 0;
		int realByte = BLOCK_SEQ_NO * 700;

		for (int i = 0; i < MAX_FILE_NO; i++) {
			if (sendFileNm[i] == null) {
				break;
			}
			blockNo = 1;
			blockSeq = 1;

			/*
			 * 2! send 630 -> receive 640
			 */
			try {
				msgClass = "0630";
				fileNm = sendFileNm[i];
				rspnCd = "000";
				String fileInfNm = sendFileNm[i];

				String outMsg = dutyFlag + StringUtils.rightPad(instiCd, 4) + msgClass + trFlag + sndFlag
						+ StringUtils.rightPad(fileNm, 8) + rspnCd + StringUtils.rightPad(fileInfNm, 8)
						+ StringUtils.leftPad(Integer.toString(sendFileSize[i]), 12, '0')
						+ StringUtils.leftPad("3000", 4, '0');

				write(outMsg);

				readByte = read();
			} catch (Exception e) {
				log.error("KBBatchClient.fileSend().Exception(2) :" + e.toString(), e);
				return false;
			}

			try {
				fis = new FileInputStream(new File(SEND_PATH, CardSysUtil.toKMCDatePath(sendFileNm[i])));
			} catch (Exception e) {
				log.error("KBBatchClient.fileSend().Exception(file_open) :" + e.toString(), e);
				return false;
			}

			/*
			 * 3! send 320 send 620 -> receive 300 send 310
			 */
			try {
				String fileInf = "";

				seqNo = 0;

				byte[] fileByte = new byte[MSG_LEN];
				while (fis.read(fileByte, 0, MSG_LEN) > 0) {
					seqNo++;
					fileInf = fileInf + new String(fileByte, 0, MSG_LEN, "euc-kr");
					if (seqNo == 5) {
						msgClass = "0320";
						String outMsg = dutyFlag + StringUtils.leftPad(instiCd, 4) + msgClass + trFlag + sndFlag
								+ StringUtils.leftPad(fileNm, 8) + rspnCd
								+ StringUtils.rightPad(Integer.toString(blockNo), 4, '0')
								+ StringUtils.rightPad(Integer.toString(blockSeq), 3, '0')
								+ StringUtils.rightPad(Integer.toString(realByte), 4, '0')
								+ StringUtils.leftPad(fileInf, realByte);

						write(outMsg);

						seqNo = 0;
						fileInf = "";

						blockSeq++;

						if (blockSeq > MAX_SEQ_NO) {
							msgClass = "0620";

							outMsg = dutyFlag + StringUtils.leftPad(instiCd, 4) + msgClass + trFlag + sndFlag
									+ StringUtils.leftPad(fileNm, 8) + rspnCd
									+ StringUtils.rightPad(Integer.toString(blockNo), 4, '0')
									+ StringUtils.rightPad(Integer.toString(MAX_SEQ_NO), 3, '0');

							write(outMsg);

							readByte = read();

							String emptyNo = new String(readByte, 31, 3);
							// String emptyChk = new String(readByte, 34,
							// MAX_SEQ_NO);
							if (emptyNo != null && !emptyNo.equals("000")) {
								// TODO : 결번 재송신 프로세스
							}

							blockNo++;
							blockSeq = 1;
						}
					}

				}

				if (seqNo != 0) {
					msgClass = "0320";

					String outMsg = dutyFlag + StringUtils.leftPad(instiCd, 4) + msgClass + trFlag + sndFlag
							+ StringUtils.leftPad(fileNm, 8) + rspnCd
							+ StringUtils.rightPad(Integer.toString(blockNo), 4, '0')
							+ StringUtils.rightPad(Integer.toString(blockSeq), 3, '0')
							+ StringUtils.rightPad(Integer.toString(realByte), 4, '0')
							+ StringUtils.leftPad(fileInf, realByte);

					write(outMsg);
				}

				msgClass = "0620";

				String outMsg = dutyFlag + StringUtils.rightPad(instiCd, 4) + msgClass + trFlag + sndFlag
						+ StringUtils.rightPad(fileNm, 8) + rspnCd
						+ StringUtils.leftPad(Integer.toString(blockNo), 4, '0')
						+ StringUtils.leftPad(Integer.toString(blockSeq), 3, '0');

				write(outMsg);

				readByte = read();

				String emptyNo = new String(readByte, 31, 3);
				// String emptyChk = new String(readByte, 34, blockSeq);
				if (emptyNo != null && !emptyNo.equals("000")) {
					// TODO : 결번 재송신 프로세스
				}
			} catch (Exception e) {
				log.error("KBBatchClient.fileSend().Exception(file_read) :" + e.toString(), e);
				return false;
			}

			/*
			 * 4! send 600/002 or 600/003 receive 610
			 */
			try {
				if (i + 1 < MAX_FILE_NO && sendFileNm[i + 1] != null) {
					manInf = "002";
				} else {
					manInf = "003";
				}
				msgClass = "0600";
				String sendId = "SCG";
				String sendPw = "";
				String outMsg = dutyFlag + StringUtils.leftPad(instiCd, 4) + msgClass + trFlag + sndFlag
						+ StringUtils.leftPad(fileNm, 8) + rspnCd
						+ new SimpleDateFormat("MMddHHmmss").format(new Date()) + manInf
						+ StringUtils.leftPad(sendId, 20) + StringUtils.leftPad(sendPw, 16);

				write(outMsg);

				readByte = read();
			} catch (Exception e) {
				log.error("KBBatchClient.fileSend().Exception(4) :" + e.toString());
				return false;
			}

		}
		return true;
	}

	private byte[] read() throws Exception {
		int errCnt = 0;
		while (true) {
			try {
				int len1 = bis.read();
				int len2 = bis.read();
				int msgLen = len1 * 256 + len2;

				byte[] readByte = new byte[msgLen];
				bis.read(readByte, 0, msgLen);

				System.out.println("read! : [" + new String(readByte) + "]");

				return readByte;
			} catch (IOException e) {
				errCnt++;
			}
			if (errCnt == 3) {
				throw new Exception("timeout 3회 발생!");
			}
		}
	}

	private boolean write(String msg) throws IOException {
		int msgLen = msg.length();
		int len1 = (int) Math.floor(msgLen / 256);
		int len2 = msgLen % 256;

		bos.write(len1);
		bos.write(len2);
		bos.write(msg.getBytes("euc-kr"), 0, msgLen);

		bos.flush();

		System.out.println("write : [" + msg + "]");

		return true;

	}

}
