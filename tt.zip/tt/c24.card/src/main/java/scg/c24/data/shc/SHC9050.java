package scg.c24.data.shc;

import org.apache.commons.lang3.StringUtils;

import lombok.Data;
import lombok.EqualsAndHashCode;
import scg.c24.data.CardDataRemote;
import scg.c24.util.seed.SeedUtil;
import tt.io.annotation.AtLPad;
import tt.io.annotation.AtSize;
import tt.io.annotation.AtUnuse;

/**
 * @제목 제휴카드인증조회 요청,응답
 * 
 * @요청 서울도시가스
 * @응답 카드사(신한,삼성)
 */

@Data
@EqualsAndHashCode(callSuper = true)
public class SHC9050 extends SHCData implements CardDataRemote {

	/** 카드번호(32) */
	@AtSize(32)
	public String b01;

	/** 카드번호 암호화 또는 복호화 이전 값 */
	@AtUnuse(print = true)
	public String b01x;

	/** 카드소유자 주민번호(32) 8901021(년월일 + 성별 = 7자리) */
	@AtSize(32)
	public String b02;

	@AtUnuse(print = true)
	public String b02x;

	/** 카드소유자 이름(100) */
	@AtLPad(100)
	public String b03;

	/** 응답결과(2) 00=요청, (10,20)=카드상태응닶정상, (기타)=오류 */
	@AtSize(2)
	public String b04;

	/** 카드유효기간(6) yyMM 암호화 (요청시 9로채움) */
	@AtSize(32)
	public String b05;

	@AtUnuse(print = true)
	public String b05x;

	/** 필러(163) */
	@AtSize(163)
	public String b06;

	@Override
	public void toSCGS() throws Exception {
		b01x = b01;
		if (StringUtils.length(b01) == 32)
			b01 = SeedUtil.decrypt(a03, b01);

		b02x = b02;
		if (StringUtils.length(b02) == 32)
			b02 = SeedUtil.decrypt(a03, b02);

		b05x = b05;
		if (StringUtils.length(b05) == 32 && b05.matches("^9{32}$") == false) {
			b05 = SeedUtil.decrypt(a03, b05);
			b05 = StringUtils.right(b05, 4);
		}
	}

	@Override
	public void toCARD() throws Exception {
		b01x = b01;
		if (StringUtils.isNotBlank(b01))
			b01 = SeedUtil.encrypt(a03, b01);

		b02x = b02;
		if (StringUtils.isNotBlank(b02))
			b02 = SeedUtil.encrypt(a03, StringUtils.rightPad(b02, 13, '0'));

		b05x = b05;
		if (StringUtils.isBlank(b05))
			b05 = StringUtils.repeat('9', 32);
		else {
			if (StringUtils.length(b05) == 4)
				b05 = "20" + b05;
			b05 = SeedUtil.encrypt(a03, b05);
		}
	}
}
