package scg.c24.config;

import java.nio.charset.Charset;

import lombok.Data;
import scg.c24.data.CardData;
import scg.c24.net.transfer.CardDataTransfer;

@Data
public class CardConfig {
	private String uid;
	private String cid;
	private Charset charset;
	private Class<CardDataTransfer<CardData>> transferType;
	private CardClientConfig client;
	private CardServerConfig server;
	private String seedkey;
	private String filePath;
}
