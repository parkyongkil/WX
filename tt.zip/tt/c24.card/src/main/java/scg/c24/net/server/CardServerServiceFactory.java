package scg.c24.net.server;

import org.springframework.stereotype.Component;

import scg.c24.ApplicationContextHolder;
import scg.c24.config.CardConfig;

@Component
public class CardServerServiceFactory {

	CardServerServiceMap cardServerServiceMap = ApplicationContextHolder.getBean(CardServerServiceMap.class);

	public CardServerService create(CardConfig cardConfig) throws Exception {
		String uid = cardConfig.getUid();

		if (!cardServerServiceMap.containsKey(uid)) {
			CardServerService service = cardConfig.getServer().getServiceType().getConstructor(CardConfig.class)
					.newInstance(cardConfig);
			cardServerServiceMap.put(uid, service);
		}
		return cardServerServiceMap.get(uid);
	}
}
