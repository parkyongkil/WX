package scg.c24.util;

import java.util.Calendar;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;

public class CardSysUtil {

	public static String toKMCDatePath(String s) throws Exception {
		Date d1 = DateUtils.truncate(new Date(), Calendar.DATE);
		String y = DateFormatUtils.format(d1, "yyyy");
		String Md = StringUtils.right(s, 4);
		Date d2 = DateUtils.parseDate(y + Md, "yyyyMMdd");
		if (d1.getTime() < d2.getTime()) {
			d2 = DateUtils.addYears(d2, -1);
			y = DateFormatUtils.format(d2, "yyyy");
		}
		return s.replaceAll("^((.+)(..)(..)(..))$", y + "/$4/$5/$1");
	}
}
