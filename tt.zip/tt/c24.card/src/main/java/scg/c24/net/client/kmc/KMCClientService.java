package scg.c24.net.client.kmc;

import java.util.Date;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;

import scg.c24.config.CardConfig;
import scg.c24.data.kmc.KMC3000;
import scg.c24.data.kmc.KMC4000;
import scg.c24.data.kmc.KMC4100;
import scg.c24.data.kmc.KMCData;
import scg.c24.mis.data.MIS3000q;
import scg.c24.mis.data.MIS3000r;
import scg.c24.mis.data.MIS4000q;
import scg.c24.mis.data.MIS4000r;
import scg.c24.net.client.CardClient;
import scg.c24.net.client.CardClientService;
import scg.c24.net.client.pool.CardClientPool;
import scg.c24.util.CardCom;
import tt.lang.string.StringU;

public class KMCClientService extends CardClientService<CardClient> {

	public KMCClientService(CardConfig cardConfig, CardClientPool<CardClient> pool) {
		super(cardConfig, pool);
	}

	/**
	 * 카드자동납부신청 요청 (3000, 9150)
	 */
	@Override
	public MIS3000r mis3000(MIS3000q mq) {

		if (log.isInfoEnabled())
			log.info(String.format("\nMQ(%s): %s", mq == null ? "X" : mq.getClass().getSimpleName(),
					StringU.toString(mq)));

		MIS3000r mr = new MIS3000r();
		KMC3000 cq = new KMC3000();
		KMC3000 cr = new KMC3000();

		setRequestHeader(cq, CardCom.getByBnkCd(mq.CARD_CD), "9150");

		cq.b01 = mq.TREAT_FLAG;
		cq.b02 = mq.USE_CONT_NUM;
		cq.b03 = mq.DEFRAY_ACCOUNT_NUM;
		cq.b04 = mq.VALID_YM;
		cq.b05 = mq.SOC_BIZ_NUM;
		cq.b06 = mq.DEPOSITOR_NM;
		cq.b07 = mq.CUST_RELAT_CD;
		cq.b08 = mq.REQ_NM;
		cq.b09 = mq.REQ_TEL_DDD;
		cq.b10 = mq.REQ_TEL_EXN;
		cq.b11 = mq.REQ_TEL_NUM;
		cq.b12 = mq.DEPOSITOR_TEL_DDD;
		cq.b13 = mq.DEPOSITOR_TEL_EXN;
		cq.b14 = mq.DEPOSITOR_TEL_NUM;
		cq.b15 = mq.ORIG_APPLY_YM;
		cq.b16 = mq.CUST_NM;
		cq.b17 = mq.ZIP_NO;
		cq.b18 = mq.ADDR1;
		cq.b19 = mq.ADDR2;

		try {
			cr = call(cq);

			// 요청과 응답의 거래번호(전문추적번호)가 일치하여야 함
			if (StringUtils.equals(cq.a04, cr.a04)) {
				boolean b = "0000".equals(cr.a06);
				mr.RSLT_CD = cr.a06;
				mr.RSLT_NM = b ? "정상" : String.format("오류: %s", cr.a07);
			} else {
				mr.RSLT_CD = "91";
				mr.RSLT_NM = "요청번호가 일치하지 않는 응답을 수신하였습니다.";
			}
		} catch (Exception e) {
			if (log.isErrorEnabled())
				log.error(e.getMessage(), e);
			mr.RSLT_CD = "99";
			mr.RSLT_NM = String.format("카드사에 요청 중 오류가 발생하였습니다.");
		}

		if (log.isInfoEnabled())
			log.info(String.format("\nMR(%s): %s", mq == null ? "X" : mr.getClass().getSimpleName(),
					StringU.toString(mr)));

		return mr;
	}

	/**
	 * 카드인증조회 요청 (4000, 9050)
	 */
	@Override
	public MIS4000r mis4000(MIS4000q mq) {

		if (log.isInfoEnabled())
			log.info(String.format("\nMQ(%s): %s", mq == null ? "X" : mq.getClass().getSimpleName(),
					StringU.toString(mq)));

		MIS4000r mr = new MIS4000r();
		KMC4000 cq = new KMC4000();
		KMC4100 cr = new KMC4100();

		setRequestHeader(cq, CardCom.getByBnkCd(mq.CARD_CD), "9050");

		cq.b01 = mq.CARD_NUM;
		cq.b02 = mq.SOC_BIZ_NUM;

		try {
			cr = call(cq);

			if (StringUtils.equals(cq.a04, cr.a04)) {
				boolean b = "0000".equals(cr.a06);
				mr.RSLT_CD = cr.a06;
				mr.RSLT_NM = b ? "정상" : String.format("오류: %s", cr.a07);
			} else {
				mr.RSLT_CD = "91";
				mr.RSLT_NM = "거래번호가 일치하지 않는 응답을 수신하였습니다.";
			}

			mr.CARD_STS_CD = cr.b03;
			mr.JOIN_YN = cr.b04;
			mr.VALID_YM = StringUtils.substring(cr.b05, 2);

		} catch (Exception e) {
			if (log.isErrorEnabled())
				log.error(e.getMessage(), e);
			mr.RSLT_CD = "99";
			mr.RSLT_NM = "카드사에 요청 중 오류가 발생하였습니다.";
		}

		if (log.isInfoEnabled())
			log.info(String.format("\nMR(%s): %s", mq == null ? "X" : mr.getClass().getSimpleName(),
					StringU.toString(mr)));

		return mr;
	}

	public static void setRequestHeader(KMCData cq, CardCom cc, String cd) {
		String ts = DateFormatUtils.format(new Date(), "yyyyMMddHHmmss");
		String ns = String.valueOf(System.nanoTime()).substring(0, 6);
		String cid = cc.getCid();

		cq.a01 = cd;
		cq.a02 = "SCG";
		cq.a03 = cid;
		cq.a04 = String.format("%s%s", ts, ns);
		cq.a05 = ts;
	}
}
