package scg.c24.biz.db.kmc.model;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import scg.c24.biz.db.gen.model.C2dtEbppAutoCnl;

public interface KMCUseContMapper {

	public List<KMCUseCont> selectUseContByUseCustNmCp(@Param("useCustNm") String useCustNm, @Param("cp1") String cp1,
			@Param("cp2") String cp2, @Param("cp3") String cp3);

	public List<KMCUseCont> selectUseContByUseContNum(@Param("useContNum") String useContNum);

	public List<KMCUseContAll> selectUseContAllByUseContNum(@Param("useContNum") String useContNum);

	public KMCUseContCheck selectUseContCheck(@Param("useContNum") String useContNum, @Param("cardNum") String cardNum,
			@Param("reqYmd") String reqYmd);

	public KMCUseContCheck selectUseContCheck10(@Param("useContNum") String useContNum, @Param("bnkCd") String bnkCd);

	public KMCUseContCheck selectUseContCheck40(@Param("useContNum") String useContNum);

	public KMCUseContTrans selectUseContTrans(@Param("useContNum") String useContNum, @Param("bnkCd") String bnkCd);

	@Select("SELECT COUNT(*) AS CNT FROM C21.C2BT_PAY_TOT_OBJ A WHERE A.USE_CONT_NUM = #{useContNum} AND A.ADD_YN = 'Y'")
	public int selectPayPot10(@Param("useContNum") String useContNum);

	@Select("SELECT COUNT(*) AS CNT FROM C21.C2BT_PAY_TOT_OBJ A INNER JOIN C11.C1BT_REQ_INFO B ON ( A.USE_CONT_NUM = B.REQ_INFO_NUM AND B.PAY_METHOD_CD = '20' ) WHERE A.USE_CONT_NUM = #{useContNum} AND A.ADD_YN = 'Y'")
	public int selectPayPot20(@Param("useContNum") String useContNum);

	@Select("SELECT RECEIVE_STS_CD FROM C11.C1AT_TRANS_ACNT WHERE DEFRAY_ACCOUNT_NUM = #{cardNum} AND CUST_NUM = #{custNum}")
	public String selectReceiveStsCheck(@Param("custNum") String custNum, @Param("cardNum") String cardNum);

	public int mergeEbpp(C2dtEbppAutoCnl b);
}