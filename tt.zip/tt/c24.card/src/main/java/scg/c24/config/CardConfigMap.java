package scg.c24.config;

import java.util.HashMap;

import org.springframework.stereotype.Component;

@Component
public class CardConfigMap extends HashMap<String, CardConfig> {

}
