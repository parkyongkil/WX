package scg.c24.test.card.mis;

public class ThreadGroupTest {

	public static void main(String[] args) {
		ThreadGroup tg1 = new ThreadGroup("selani");
		ThreadGroup tg2 = new ThreadGroup("selani");

		A a1 = new A();
		A a2 = new A();
		Thread t1 = new Thread(tg1, a1);
		t1.start();
		Thread t2 = new Thread(tg1, a2);
		t2.start();

		p("T1");
		tg1.list();
		p("T ------------------");
		p("T2");
		tg2.list();
		p("T ------------------");

		System.out.println(tg1);
		System.out.println(tg2);
	}

	public static class A extends Thread {

		@Override
		public void run() {
			String name = this.getName();
			p(String.format("Start [%s]", name));
			while (true) {
				if (isInterrupted()) {
					p(String.format("Interupted [%s]", name));
					break;
				}
				try {
					p(String.format("Waiting [%s]", name));
					sleep(1000);
				} catch (Exception e) {
					p(String.format("Error [%s]", name));
					e.printStackTrace(System.err);
					break;
				}
			}
			p(String.format("End [%s]", name));
		}
	}

	static void p(Object o) {
		System.out.println(o);
	}
}
