package scg.c24.test.card.mis;

import scg.c24.mis.data.MIS3000q;
import scg.c24.mis.data.MIS3000r;
import scg.c24.mis.util.URLCaller;
import tt.lang.string.StringU;

public class MISTest {

	public static void main(String[] args) {
		test_MISController();
	}

	public static void test_MISController() {
		try {
			MIS3000q q = new MIS3000q();
			System.out.println(StringU.toString(q));
			MIS3000r r = URLCaller.call("http://localhost:9080/card/MIS3000", q, MIS3000r.class);
			System.out.println(StringU.toString(r));
		} catch (Exception e) {
			e.printStackTrace(System.err);
		}
	}
}
