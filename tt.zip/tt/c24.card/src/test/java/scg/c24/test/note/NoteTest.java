package scg.c24.test.note;

import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.lang.reflect.Type;

public class NoteTest {

	public static void main(String[] args) throws Exception {
		Field f = NoteTest.class.getDeclaredField("test");
		Annotation[] aa = f.getDeclaredAnnotations();
		System.out.println("SIZE=" + aa.length);
		for (Annotation a : aa) {
			Type t = a.annotationType();
			System.out.println(String.format("t = %s", t.getTypeName()));
		}
	}

	/** test() */
	protected String test;
}
