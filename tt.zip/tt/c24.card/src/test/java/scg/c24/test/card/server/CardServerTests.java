package scg.c24.test.card.server;

import java.net.Socket;

public class CardServerTests {

	public static void main(String[] args) throws Exception {
		CardServerTests t = new CardServerTests();
		t.test1();
	}

	void test1() throws Exception {
		String s = "SOGSSC00102760SSC8050SS2016101309364964200020161013093649269000120SOG                                                                                                                6000611005                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         ";
		String host = "10.20.1.59";
		int port = 57406;
		Socket socket = new Socket(host, port);
		socket.setSoTimeout(5000);
		socket.getOutputStream().write(s.getBytes("euc-kr"));
		byte[] b = new byte[8196];
		int i = socket.getInputStream().read(b);
		socket.close();
		String r = new String(b, "euc-kr");
		System.out.println(i);
		System.out.println(r);
	}
}
