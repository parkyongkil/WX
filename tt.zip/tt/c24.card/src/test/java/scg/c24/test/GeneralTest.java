package scg.c24.test;

public class GeneralTest {

	public static void main(String[] args) {
		// NOTHING
	}
}
