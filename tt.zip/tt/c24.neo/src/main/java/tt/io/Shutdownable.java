package tt.io;

public interface Shutdownable {

	void shutdown();
}
