package scg.c24.data.ssc;

import org.apache.commons.lang3.StringUtils;

import lombok.Data;
import lombok.EqualsAndHashCode;
import scg.c24.data.CardDataRemote;
import scg.c24.util.CardCodeUtil;
import scg.c24.util.seed.SeedUtil;
import tt.io.annotation.AtLPad;
import tt.io.annotation.AtSize;
import tt.io.annotation.AtUnuse;

/**
 * @제목 카드자동납부신청 요청,응답
 * 
 * @요청 서울도시가스
 * @응답 카드사(신한,삼성)
 */

@Data
@EqualsAndHashCode(callSuper = true)
public class SSC9150 extends SSCData implements CardDataRemote {

	/** 거래구분(1) 1=신규, 2=변경, 3=해지 */
	@AtSize(1)
	public String b01;

	/** 카드번호(32) 암호화 */
	@AtSize(32)
	public String b02;

	@AtUnuse(print = true)
	public String b02x;

	/** (구)카드번호(32) (사용안함) */
	@AtSize(32)
	public String b03;

	/** 카드소유자 이름(100) */
	@AtSize(100)
	public String b04;

	/** 주민번호(32) 암호화 (사용안함) */
	@AtSize(32)
	public String b05;

	/** 신청인 전화번호1(4) */
	@AtLPad(4)
	public String b06;

	/** 신청인 전화번호2(4) */
	@AtLPad(4)
	public String b07;

	/** 신청인 전화번호3(4) */
	@AtLPad(4)
	public String b08;

	/** 신청일자(8) yyyyMMdd */
	@AtSize(8)
	public String b09;

	/** 신청인과의 관계(2) 01=본인, 02=배우자, 03=자녀, 04=형제자매, 05=부친, 06=모친, 07=친척, 09=기타 */
	@AtSize(2)
	public String b10;

	@AtUnuse(print = true)
	public String b10x;

	/** 카드소유자 이름(100) */
	@AtSize(100)
	public String b11;

	/** 사용계약번호(10) */
	@AtSize(10)
	public String b12;

	/** 응답결과(2) 00=요청할때, 응답값: */
	@AtSize(2)
	public String b13;

	/** 적용년월(6) yyyyMM */
	@AtSize(6)
	public String b14;

	/** 필러(163) */
	@AtSize(163)
	public String b15;

	@Override
	public void toSCGS() throws Exception {
		b02x = b02;
		if (StringUtils.length(b02) == 32)
			b02 = SeedUtil.decrypt(a03, b02);

		b10x = b10;
		b10 = CardCodeUtil.DECODE_RELAT_CD_SCGS(b10);
	}

	@Override
	public void toCARD() throws Exception {
		b02x = b02;
		if (StringUtils.isNotBlank(b02))
			b02 = SeedUtil.encrypt(a03, b02);

		b10x = b10;
		b10 = CardCodeUtil.DECODE_RELAT_CD_CARD(b10);
	}
}
