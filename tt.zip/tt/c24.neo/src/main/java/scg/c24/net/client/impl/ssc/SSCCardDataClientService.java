package scg.c24.net.client.impl.ssc;

import java.util.Date;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import scg.c24.config.CardDataConfig;
import scg.c24.data.ssc.SSC9050;
import scg.c24.data.ssc.SSC9150;
import scg.c24.data.ssc.SSCData;
import scg.c24.mis.data.MIS3000q;
import scg.c24.mis.data.MIS3000r;
import scg.c24.mis.data.MIS4000q;
import scg.c24.mis.data.MIS4000r;
import scg.c24.net.client.CardDataClient;
import scg.c24.net.client.CardDataClientService;
import scg.c24.net.client.pool.CardDataClientPool;
import scg.c24.util.CardCom;

public class SSCCardDataClientService implements CardDataClientService {

	protected CardDataConfig config;
	private CardDataClientPool pool;
	private Logger logger = LoggerFactory.getLogger(CardDataClientService.class);

	public SSCCardDataClientService(CardDataConfig config, CardDataClientPool pool) {
		super();
		this.config = config;
		this.pool = pool;
	}

	@Override
	public <Q, R> R call(Q q) throws Exception {
		CardDataClient client = pool.borrowObject();
		try {
			return client.call(q);
		} catch (Exception e) {
			pool.invalidateObject(client);
			client = null;
			throw e;
		} finally {
			if (client != null)
				pool.returnObject(client);
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public <Q, R> R callMis(Q q) throws Exception {
		if (q instanceof MIS3000q)
			return (R) mis3000((MIS3000q) q);
		if (q instanceof MIS4000q)
			return (R) mis4000((MIS4000q) q);
		throw new Exception(String.format("처리할수 없는 구조체(%s)입니다.", q == null ? "X" : q.getClass().getSimpleName()));
	}

	@Override
	public void close() {
		// NOTHING
	}

	public static void setRequestHeader(SSCData cq, CardCom cc, String cd) {
		String ts = DateFormatUtils.format(new Date(), "yyyyMMddHHmmss");
		String ns = String.valueOf(System.nanoTime()).substring(0, 6);
		String cid = cc.getCid();

		cq.a01 = String.format("DSE%s001", cid);
		// a02 (전체전문길이), 바이너리 전송시 자동계산입력처리됨
		cq.a03 = cid;
		cq.a04 = cd;
		cq.a05 = String.format("XX%s%s", ts, ns);
		cq.a06 = ts;
		// a07 (개별부전문길이), 바이너리 전송시 자동계산입력처리됨
		cq.a08 = "00";
		cq.a09 = cc.getMemberCd();
		cq.a10 = cc.getPartnerCd();
	}

	public MIS3000r mis3000(MIS3000q mq) {

		MIS3000r mr = new MIS3000r();
		SSC9150 q = new SSC9150();
		SSC9150 r = new SSC9150();

		setRequestHeader(q, CardCom.getByCardCd(mq.CARD_CD), "9150");

		q.b01 = mq.TREAT_FLAG;
		q.b02 = mq.DEFRAY_ACCOUNT_NUM;
		// b03 구카드번호 (사용안함)
		q.b04 = mq.DEPOSITOR_NM;
		// b05 주민번호 (사용안함)
		q.b06 = mq.REQ_TEL_DDD;
		q.b07 = mq.REQ_TEL_EXN;
		q.b08 = mq.REQ_TEL_NUM;
		q.b09 = DateFormatUtils.format(new Date(), "yyyyMMdd");
		q.b10 = mq.CUST_RELAT_CD;
		q.b11 = mq.CUST_NM;
		q.b12 = mq.USE_CONT_NUM;
		q.b13 = "00";
		q.b14 = mq.ORIG_APPLY_YM;

		try {
			r = call(q);

			if (StringUtils.equals(q.a05, r.a05)) {
				mr.RSLT_CD = r.a08;
				mr.RSLT_NM = "00".equals(r.a08) ? "정상" : "오류 응답을 수신하였습니다.";
			} else {
				mr.RSLT_CD = "91";
				mr.RSLT_NM = "거래번호가 일치하지 않는 응답을 수신하였습니다.";
			}
			mr.CARD_STS_CD = r.b13;

		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			mr.RSLT_CD = "99";
			mr.RSLT_NM = "카드사에 요청 중 오류가 발생하였습니다.";
		}
		return mr;
	}

	public MIS4000r mis4000(MIS4000q mq) {

		MIS4000r mr = new MIS4000r();
		SSC9050 q = new SSC9050();
		SSC9050 r = new SSC9050();

		setRequestHeader(q, CardCom.getByCardCd(mq.CARD_CD), "9050");

		q.b01 = mq.CARD_NUM;
		q.b02 = mq.SOC_BIZ_NUM;
		q.b03 = mq.DEPOSITOR_NM;
		q.b04 = "00";

		try {
			r = call(q);

			if (StringUtils.equals(q.a05, r.a05)) {
				mr.RSLT_CD = r.a08;
				mr.RSLT_NM = "00".equals(r.a08) ? "정상" : "오류 응답을 수신하였습니다.";
			} else {
				mr.RSLT_CD = "91";
				mr.RSLT_NM = "거래번호가 일치하지 않는 응답을 수신하였습니다.";
			}

			mr.CARD_STS_CD = r.b04;
			mr.VALID_YM = StringUtils.substring(r.b05, 2);

		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			mr.RSLT_CD = "99";
			mr.RSLT_NM = "카드사에 요청 중 오류가 발생하였습니다.";
		}
		return mr;
	}
}
