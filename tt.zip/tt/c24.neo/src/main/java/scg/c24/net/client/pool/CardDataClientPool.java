package scg.c24.net.client.pool;

import java.io.Closeable;

import org.apache.commons.pool2.PooledObjectFactory;
import org.apache.commons.pool2.impl.AbandonedConfig;
import org.apache.commons.pool2.impl.GenericObjectPool;
import org.apache.commons.pool2.impl.GenericObjectPoolConfig;

import scg.c24.net.client.CardDataClient;

public class CardDataClientPool extends GenericObjectPool<CardDataClient> implements Closeable {

	public CardDataClientPool(PooledObjectFactory<CardDataClient> factory, GenericObjectPoolConfig config,
			AbandonedConfig abandonedConfig) {
		super(factory, config, abandonedConfig);
		initShutdown();
	}

	public CardDataClientPool(PooledObjectFactory<CardDataClient> factory, GenericObjectPoolConfig config) {
		super(factory, config);
		initShutdown();
	}

	public CardDataClientPool(PooledObjectFactory<CardDataClient> factory) {
		super(factory);
		initShutdown();
	}

	private void initShutdown() {
		Runtime.getRuntime().addShutdownHook(new Thread() {

			@Override
			public void run() {
				close();
			}
		});
	}
}
