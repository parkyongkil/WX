package scg.c24.net.server.impl;

import java.util.HashMap;

import org.springframework.stereotype.Component;

import scg.c24.net.server.CardDataServer;
import scg.c24.net.server.CardDataServerMap;

@Component
public class CardDataServerMapImpl extends HashMap<String, CardDataServer> implements CardDataServerMap {

	@Override
	public CardDataServer get(String uid) {
		return super.get(uid);
	}

	@Override
	public CardDataServer put(String uid, CardDataServer server) {
		super.put(uid, server);
		return server;
	}

	@Override
	public CardDataServer remove(String uid) {
		return super.remove(uid);
	}

	@Override
	public void close() {
		for (CardDataServer server : super.values())
			if (server != null)
				server.close();
		super.clear();
	}
}
