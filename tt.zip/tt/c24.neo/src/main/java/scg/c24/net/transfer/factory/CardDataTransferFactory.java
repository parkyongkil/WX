package scg.c24.net.transfer.factory;

import java.nio.channels.SocketChannel;

import scg.c24.config.CardDataConfig;
import scg.c24.net.transfer.CardDataTransfer;

public class CardDataTransferFactory {

	public static CardDataTransfer create(CardDataConfig config, SocketChannel socketChannel, boolean forServer)
			throws Exception {
		return config.getTransferType().getConstructor(CardDataConfig.class, SocketChannel.class, boolean.class)
				.newInstance(config, socketChannel, forServer);
	}
}
