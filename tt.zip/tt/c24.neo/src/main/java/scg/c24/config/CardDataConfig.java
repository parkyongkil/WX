package scg.c24.config;

import java.nio.charset.Charset;

import lombok.Data;
import scg.c24.net.transfer.CardDataTransfer;

@Data
public class CardDataConfig {

	private String uid;
	private String cid;
	private String seedkey;
	private Charset charset;
	private Class<CardDataTransfer> transferType;
	private CardDataClientConfig client;
	private CardDataServerConfig server;
}
