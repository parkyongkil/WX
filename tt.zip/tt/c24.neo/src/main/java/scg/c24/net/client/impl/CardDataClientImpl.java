package scg.c24.net.client.impl;

import java.net.InetSocketAddress;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.SocketChannel;
import java.util.Iterator;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import scg.c24.config.CardDataConfig;
import scg.c24.data.CardDataRemote;
import scg.c24.net.client.CardDataClient;
import scg.c24.net.transfer.CardDataTransfer;
import scg.c24.net.transfer.factory.CardDataTransferFactory;
import tt.lang.string.StringU;

public class CardDataClientImpl implements CardDataClient {

	private CardDataConfig config;

	private Selector selector;
	private SocketChannel socketChannel;
	private InetSocketAddress address;
	private CardDataTransfer transfer;

	private Logger logger = LoggerFactory.getLogger(CardDataClient.class);

	public CardDataClientImpl(CardDataConfig config) {
		super();
		this.config = config;
	}

	@Override
	public void open() throws Exception {
		Selector selector = Selector.open();
		socketChannel = SocketChannel
				.open(address = new InetSocketAddress(config.getClient().getHost(), config.getClient().getPort()));
		socketChannel.configureBlocking(false);
		socketChannel.socket().setSoTimeout(config.getClient().getTimeout());
		socketChannel.register(selector, SelectionKey.OP_READ, null);
		transfer = CardDataTransferFactory.create(config, socketChannel, false);
		if (logger.isInfoEnabled())
			logger.info("Client({}) Opened.", address);
	}

	@Override
	public boolean validate() {
		return socketChannel != null && socketChannel.isConnected();
	}

	@Override
	public void clear() {
		if (transfer != null)
			transfer.clear();
	}

	@Override
	public void close() {
		if (selector != null)
			try {
				selector.close();
				selector = null;
			} catch (Exception e) {
				logger.error(e.getMessage(), e);
			}
		if (socketChannel != null)
			try {
				socketChannel.close();
				if (logger.isInfoEnabled())
					logger.info("Client({}) Closed.", address);
				socketChannel = null;
				transfer = null;
			} catch (Exception e) {
				logger.error(e.getMessage(), e);
			}
	}

	@Override
	public <Q, R> R call(Q q) throws Exception {
		if (q instanceof CardDataRemote)
			((CardDataRemote) q).toSCGS();
		if (logger.isInfoEnabled())
			logger.info("\nCQ({}): {}", q == null ? "X" : q.getClass().getSimpleName(), StringU.toString(q));
		transfer.writeObject(q);
		int n = selector.select(config.getClient().getTimeout());
		if (n == 0)
			throw new Exception("Selctor Timeout.");
		Iterator<SelectionKey> ks = selector.selectedKeys().iterator();
		R r = null;
		while (ks.hasNext()) {
			SelectionKey k = ks.next();
			ks.remove();
			if (k == null || k.isReadable() == false)
				continue;
			r = transfer.readObject();
			if (r != null)
				break;
		}
		if (r == null)
			throw new Exception("Failed to Read.");
		if (r instanceof CardDataRemote)
			((CardDataRemote) r).toCARD();
		if (logger.isInfoEnabled())
			logger.info("\nCR({}): {}", r == null ? "X" : r.getClass().getSimpleName(), StringU.toString(r));
		return r;
	}
}
