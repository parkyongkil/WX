package scg.c24.net.transfer.impl;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.nio.channels.SocketChannel;
import java.nio.charset.Charset;

import org.slf4j.Logger;

import scg.c24.config.CardDataConfig;
import scg.c24.net.client.CardDataClient;
import scg.c24.net.server.CardDataServer;
import scg.c24.net.transfer.CardDataTransfer;
import scg.c24.util.CardLoggerUtil;
import tt.io.TDataInputStream;
import tt.io.TDataOutputStream;

public abstract class CardDataTransferBase implements CardDataTransfer {

	protected CardDataConfig config;
	protected SocketChannel socketChannel;
	protected Logger logger;
	protected boolean forServer;
	protected String tr;
	protected String tw;
	protected Charset charset;

	public CardDataTransferBase(CardDataConfig config, SocketChannel socketChannel, boolean forServer) {
		super();
		this.config = config;
		this.socketChannel = socketChannel;
		this.forServer = forServer;
		this.charset = config.getCharset();
		this.logger = CardLoggerUtil.getLogger(config.getUid(), String.format("%sTransfer",
				forServer ? CardDataServer.class.getSimpleName() : CardDataClient.class.getSimpleName()));
		this.tr = forServer ? "TQ" : "TR";
		this.tw = forServer ? "TR" : "TQ";
	}

	protected <X> X toObject(byte[] b, Class<X> c) throws Exception {
		ByteArrayInputStream bais = new ByteArrayInputStream(b);
		TDataInputStream tdis = new TDataInputStream(bais, config.getCharset());
		X x = tdis.readObject(c);
		tdis.close();
		return x;
	}

	protected <X> byte[] toBytes(X o) throws Exception {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		TDataOutputStream tdos = new TDataOutputStream(baos, config.getCharset());
		tdos.writeObject(o);
		tdos.close();
		return baos.toByteArray();
	}
}
