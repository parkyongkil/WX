package scg.c24.config;

import org.apache.commons.pool2.impl.GenericObjectPoolConfig;

import lombok.Data;
import scg.c24.net.client.CardDataClient;
import scg.c24.net.client.CardDataClientService;

@Data
public class CardDataClientConfig {

	private String host;
	private int port;
	private int timeout;
	private Class<CardDataClient> clientType;
	private Class<CardDataClientService> serviceType;
	private GenericObjectPoolConfig pool;
}
