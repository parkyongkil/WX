package scg.c24.net.client.factory;

import scg.c24.config.CardDataConfig;
import scg.c24.net.client.CardDataClient;

public class CardDataClientFactory {

	public static CardDataClient create(CardDataConfig config) throws Exception {
		return config.getClient().getClientType().getConstructor(CardDataConfig.class).newInstance(config);
	}
}
