package scg.c24.net.client.pool.factory;

import org.apache.commons.pool2.impl.GenericObjectPoolConfig;

import scg.c24.config.CardDataConfig;
import scg.c24.net.client.pool.CardDataClientPool;
import scg.c24.net.client.pool.CardDataClientPoolMap;

public class CardDataClientPoolFactory {

	public static CardDataClientPool create(CardDataConfig config) throws Exception {
		String uid = config.getUid();
		CardDataClientPoolMap map = CardDataClientPoolMapFactory.create();
		CardDataClientPool pool = map.remove(uid);
		if (pool != null)
			pool.close();
		GenericObjectPoolConfig poolConfig = config.getClient().getPool();
		poolConfig.setJmxEnabled(false);
		poolConfig.setTestOnCreate(true);
		poolConfig.setTestOnBorrow(true);
		CardDataClientPooledObjectFactory poolFactory = new CardDataClientPooledObjectFactory(config);
		pool = new CardDataClientPool(poolFactory, poolConfig);
		map.put(uid, pool);
		return pool;
	}
}
