package scg.c24.biz;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.net.Socket;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.sql.DataSource;

import scg.c24.ApplicationContextHolder;

public class TransAcntCnl {
	private String reqInfoNum;
	private String cnlWhyCd;
	private String cnlCustNm;
	private String cnlCustSocNum;
	private String cnlCustRelatCd;
	private String cnlTelDdd;
	private String cnlTelExn;
	private String cnlTelNum;
	private String cnlGubn;
	private String ebppCnlYn;
	private String receiveSecCd;
	private String webId;
	// private String ci;

	private String custNum;
	private String accountNum;
	private String bnkCd;
	// private String reqYmd;
	private String tranFlag;
	private String nxtReqInfoNum;
	private String payMethod;
	private boolean isReqIng;

	private Connection conn = null;
	private PreparedStatement ps = null;
	private ResultSet rs = null;

	private DataSource dataSource;

	public TransAcntCnl(String reqInfoNum, String cnlWhyCd, String cnlCustNm, String cnlCustSocNum,
			String cnlCustRelatCd, String cnlTelDdd, String cnlTelExn, String cnlTelNum, String cnlGubn,
			String ebppCnlYn, String receiveSecCd // 5홈페이지 6카드사
			, String webId, boolean isReqIng, Connection conn, String ci) {
		this.reqInfoNum = reqInfoNum;
		this.cnlWhyCd = cnlWhyCd;
		this.cnlCustNm = cnlCustNm;
		this.cnlCustSocNum = cnlCustSocNum;
		this.cnlCustRelatCd = cnlCustRelatCd;
		this.cnlTelDdd = cnlTelDdd;
		this.cnlTelExn = cnlTelExn;
		this.cnlTelNum = cnlTelNum;
		this.cnlGubn = cnlGubn;
		this.ebppCnlYn = ebppCnlYn;
		this.receiveSecCd = receiveSecCd;
		this.webId = webId;
		this.isReqIng = isReqIng;
		if (isReqIng) {
			this.conn = conn;
		}
		// this.ci = ci;
		this.dataSource = ApplicationContextHolder.getBean(DataSource.class);
	}

	public int start() {
		int chk, rValue = 0;
		chk = validate();
		if (chk != 0)
			return chk;
		try {
			if (!isReqIng) {
				conn = dataSource.getConnection();
				conn.setAutoCommit(false);
				// TODO 납부자통합이면 해지 불가 2016-02-18
				chk = chkPayTot();
				if (chk != 0) {
					throw new Exception("납부자통합 고객 해지불가");
				}
			}
			//
			chk = chkUseCont();
			if (chk != 0) {
				throw new Exception("사용계약 상태 오류");
			}

			if (cnlGubn.equals("1")) // 단건 해지
			{
				chk = cnlUseCont(reqInfoNum);
				if (chk != 0)
					throw new Exception("사용계약해지오류 : " + reqInfoNum);
			} else {
				ps = conn.prepareStatement(sqlSelectCont);
				ps.setString(1, reqInfoNum);

				rs = ps.executeQuery();
				while (rs.next()) {
					custNum = rs.getString("CUST_NUM");
					accountNum = rs.getString("DEFRAY_ACCOUNT_NUM");
					// reqYmd = rs.getString("REQ_YMD");
					nxtReqInfoNum = rs.getString("REQ_INFO_NUM");
					bnkCd = rs.getString("BNK_CD");
					tranFlag = rs.getString("TRAN_FLAG");
					chk = cnlUseCont(nxtReqInfoNum);
					if (chk != 0)
						throw new Exception("사용계약해지오류 : " + nxtReqInfoNum);
				}

				chk = cnlAcnt();
				if (chk != 0)
					throw new Exception("계좌해지오류 : " + accountNum);

			}
			if (receiveSecCd.equals("5")) { // 홈페이지 -> 추가인서트
				chk = insertScsTrans();
				if (chk != 0)
					throw new Exception("홈페이지입력오류");
				if (!isReqIng && payMethod != null && payMethod.equals("30")) {
					chk = sendKB();
				}
			}

		} catch (Exception e) {
			System.out.println("TransAcntCnl.start() : catch! " + e.toString());
			rValue = chk;
		} finally {
			try {
				if (ps != null)
					ps.close();
				if (rs != null)
					rs.close();

				if (!isReqIng) {
					if (conn != null) {
						if (rValue == 0)
							conn.commit();
						else
							conn.rollback();
					}

					if (conn != null)
						conn.close();
				}
			} catch (Exception e) {

			}
		}

		return rValue;
	}

	private final static String sqlSelectCont = "SELECT DEFRAY_ACCOUNT_NUM " + "     , CUST_NUM "
			+ "     , REQ_INFO_NUM " + "     , REQ_YMD " + "     , BNK_CD " + "     , (SELECT TRAN_FLAG "
			+ "          FROM C11.C1AT_TRANS_ACNT X " + "         WHERE X.DEFRAY_ACCOUNT_NUM = A.DEFRAY_ACCOUNT_NUM "
			+ "           AND X.CUST_NUM = A.CUST_NUM) TRAN_FLAG " + "  FROM C11.C1BT_USE_CONT_TRANS A "
			+ " WHERE CUST_NUM = (SELECT CUST_NUM " + "                     FROM C11.C1BT_USE_CONT "
			+ "                    WHERE USE_CONT_NUM = ?) " + "   AND RECEIVE_STS_CD in ('10', '20') "
			+ "   AND CNL_YMD = '99991231' ";

	/*
	 * validate() -
	 */
	private int validate() {
		if (reqInfoNum == null || reqInfoNum.length() != 10) {
			System.out.println("!reqInfoNum error : " + reqInfoNum);
			return 98;
		}

		return 0;
	}

	private int chkUseCont() {
		int rValue = 0;
		/*
		 * check! 0. 사용계약존재여부 체크 1. 납부방법 체크
		 */
		try {
			if (cnlWhyCd.equals("10")) { // 해지요청
				ps = conn.prepareStatement(sqlchk_10);
			} else { // 신규등록에 따른 해지
				ps = conn.prepareStatement(sqlchk_40);
			}

			ps.setString(1, reqInfoNum);
			ps.setString(2, reqInfoNum);
			ps.setString(3, reqInfoNum);

			rs = ps.executeQuery();

			if (rs.next()) {

				if (rs.getString("CHK_0").equals("0")) {
					System.out.println("!사용계약 미존재 오류");
					rValue = 10;
				} else if (rs.getString("CHK_1").equals("0")) {
					System.out.println("!납부방법 오류)");
					rValue = 50;
				}
				payMethod = rs.getString("PAY_METHOD_CD");
			} else {
				rValue = 99;
			}
		} catch (Exception e) {
			System.out.println("TransAcntCnl.chkUseCont() : " + e.toString());
			rValue = 99;
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (ps != null) {
					ps.close();
				}
			} catch (Exception e) {

			}
		}
		return rValue;
	}

	private final static String sqlchk_10 = "SELECT nvl((SELECT '1' " + "              FROM C11.C1BT_USE_CONT "
			+ "             WHERE USE_CONT_NUM = ?), '0') CHK_0 " + "     , nvl((SELECT MAX('1') "
			+ "              FROM C11.C1BT_USE_CONT_TRANS " + "             WHERE REQ_INFO_NUM = ? "
			+ "               AND BNK_CD = '807'" + "               AND RECEIVE_STS_CD IN('10', '20')), '0') CHK_1 "
			+ "     , (SELECT PAY_METHOD_CD FROM C11.C1BT_REQ_INFO WHERE REQ_INFO_NUM = ?) PAY_METHOD_CD "
			+ "  FROM dual ";

	private final static String sqlchk_40 = "SELECT nvl((SELECT '1' " + "              FROM C11.C1BT_USE_CONT "
			+ "             WHERE USE_CONT_NUM = ?), '0') CHK_0 " + "     , nvl((SELECT MAX('1') "
			+ "              FROM C11.C1BT_USE_CONT_TRANS " + "             WHERE REQ_INFO_NUM = ? "
			+ "               AND RECEIVE_STS_CD IN('10', '20')), '0') CHK_1 "
			+ "     , (SELECT PAY_METHOD_CD FROM C11.C1BT_REQ_INFO WHERE REQ_INFO_NUM = ?) PAY_METHOD_CD "
			+ "  FROM dual ";

	private int cnlUseCont(String reqInfoNum) {
		int rValue = 0;
		/*
		 * 
		 */
		try {
			ps = conn.prepareStatement(sqlUpdateReqInfo);

			if (ebppCnlYn != null && ebppCnlYn.equals("Y")) {
				ps.setString(1, "10");
				ps.setString(2, "N");
			} else {
				ps.setString(1, null);
				ps.setString(2, null);
			}
			ps.setString(3, reqInfoNum);

			ps.executeUpdate();

			if (ebppCnlYn != null && ebppCnlYn.equals("Y")) {
				ps = conn.prepareStatement(sqlMergeEbpp);
				ps.setString(1, reqInfoNum);
				ps.setString(2, "20");
				ps.setString(3, reqInfoNum);
				ps.setString(4, "20");

				ps.executeUpdate();
			}

			ps = conn.prepareStatement(sqlUpdateUseContTrans);
			ps.setString(1, receiveSecCd);
			ps.setString(2, cnlWhyCd);
			ps.setString(3, cnlCustNm);
			ps.setString(4, cnlCustSocNum);
			ps.setString(5, cnlCustRelatCd);
			ps.setString(6, cnlTelDdd);
			ps.setString(7, cnlTelExn);
			ps.setString(8, cnlTelNum);
			ps.setString(9, reqInfoNum);

			ps.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("TransAcntCnl.cnlUseCont() : " + e.toString());
			rValue = 99;
		} finally {
			try {
				if (ps != null) {
					ps.close();
				}
			} catch (Exception e) {

			}
		}
		return rValue;
	}

	private final static String sqlUpdateReqInfo = "UPDATE C11.C1BT_REQ_INFO " + "   SET UPD_DTM = sysdate "
			+ "     , UPD_EMPID = 'SYSTEM' " + "     , UPD_IP = '**.**.**.**' " + "     , PAY_METHOD_CD = '10' "
			+ "     , BILL_SEND_METHOD_CD = nvl(?, BILL_SEND_METHOD_CD) "
			+ "     , EMAIL_SEND_YN = nvl(?, EMAIL_SEND_YN) " + " WHERE REQ_INFO_NUM = ? ";

	private final static String sqlMergeEbpp = "MERGE INTO C21.C2DT_EBPP_AUTO_CNL A " + "    USING dual "
			+ "    ON (    A.USE_CONT_NUM = ? " + "        AND trim(A.JOB_ID) = to_char(sysdate, 'YYYYMMDD') "
			+ "        AND A.REQ_YMD = to_char(sysdate, 'YYYYMMDD') " + "        AND A.REQ_FLAG = '2') "
			+ "    WHEN MATCHED THEN " + "        UPDATE " + "           SET A.UPD_DTM = sysdate "
			+ "             , A.UPD_EMPID = 'SYSTEM' " + "             , A.UPD_IP = '**.**.**.**' "
			+ "             , A.RECEIVE_FLAG = ? " + "    WHEN NOT MATCHED THEN "
			+ "        INSERT(A.JOB_ID, A.REQ_YMD, A.USE_CONT_NUM, A.REQ_FLAG, A.CREATE_YMD, A.CRT_TIME, A.RECEIVE_FLAG, A.CRT_IP, A.CRT_EMPID) "
			+ "        VALUES(to_char(sysdate, 'YYYYMMDD') " + "             , to_char(sysdate, 'YYYYMMDD') "
			+ "             , ? " + "             , '2' " + "             , to_char(sysdate, 'YYYYMMDD') "
			+ "             , to_char(sysdate, 'HH24MISS') " + "             , ? " + "             , 'SYSTEM' "
			+ "             , '**.**.**.**') ";

	private final static String sqlUpdateUseContTrans = "UPDATE C11.C1BT_USE_CONT_TRANS " + "   SET UPD_DTM = sysdate "
			+ "     , UPD_EMPID = 'KBCard' " + "     , UPD_IP = '**.**.**.**' " + "     , RECEIVE_STS_CD = '30' "
			+ "     , RECEIVE_SEC_CD = ? " + "     , CNL_APPLY_YM = to_char(sysdate, 'YYYYMM') "
			+ "     , CNL_YMD = to_char(sysdate, 'YYYYMMDD') " + "     , CNL_WHY_CD = nvl(?, CNL_WHY_CD) "
			+ "     , CNL_CUST_NM = nvl(?, CNL_CUST_NM) " + "     , CNL_CUST_SOC_NUM = nvl(?, CNL_CUST_SOC_NUM) "
			+ "     , CNL_CUST_RELAT_CD = nvl(?, CNL_CUST_RELAT_CD) " + "     , CNL_TEL_DDD = nvl(?, CNL_TEL_DDD) "
			+ "     , CNL_TEL_EXN = nvl(?, CNL_TEL_EXN) " + "     , CNL_TEL_NUM = nvl(?, CNL_TEL_NUM) "
			+ " WHERE REQ_INFO_NUM = ? " + "   AND RECEIVE_STS_CD in ('10', '20') " + "   AND CNL_YMD = '99991231' ";

	private int cnlAcnt() {
		int rValue = 0, result = 0;
		/*
		 * 
		 */
		try {
			ps = conn.prepareStatement(sqlUpdateTransAcnt);

			ps.setString(1, cnlWhyCd);
			ps.setString(2, accountNum);
			ps.setString(3, custNum);

			result = ps.executeUpdate();

			ps = conn.prepareStatement(sqlInsertTransAcntReq);
			ps.setString(1, accountNum);
			ps.setString(2, custNum);
			ps.setString(3, bnkCd);
			ps.setString(4, tranFlag);
			ps.setString(5, receiveSecCd);
			ps.setString(6, cnlCustRelatCd);
			ps.setString(7, cnlCustNm);
			ps.setString(8, cnlTelDdd);
			ps.setString(9, cnlTelExn);
			ps.setString(10, cnlTelNum);

			result = ps.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("TransAcntCnl.cnlAcnt() : " + e.toString());
			rValue = 99;
		} finally {
			try {
				if (ps != null) {
					ps.close();
				}
			} catch (Exception e) {

			}
		}
		return rValue;
	}

	private final static String sqlUpdateTransAcnt = "UPDATE C11.C1AT_TRANS_ACNT " + "   SET UPD_DTM = sysdate "
			+ "     , UPD_EMPID = 'KBCard' " + "     , UPD_IP = '**.**.**.**' " + "     , RECEIVE_STS_CD = '30' "
			+ "     , CNL_YMD = to_char(sysdate, 'YYYYMMDD') " + "     , CNL_WHY_CD = ? "
			+ " WHERE DEFRAY_ACCOUNT_NUM = ? " + "   AND CUST_NUM = ? ";

	private final static String sqlInsertTransAcntReq = "INSERT INTO C11.C1AT_TRANS_ACNT_REQ "
			+ "            (DEFRAY_ACCOUNT_NUM " + "           , CUST_NUM " + "           , REQ_ITEM_CD "
			+ "           , REQ_YMD " + "           , CRT_EMPID " + "           , CRT_IP " + "           , BNK_CD "
			+ "           , REQ_RSLT_CD " + "           , RECEIVE_SEC_CD " + "           , CUST_RELAT_CD "
			+ "           , REQ_NM " + "           , REQ_TEL_DDD " + "           , REQ_TEL_EXN "
			+ "           , REQ_TEL_NUM " + "           , KFTC_RECEIVE_STS_CD " + "           , TRANS_YMD "
			+ "           , APPRO_YMD " + "            ) " + "VALUES      (? " + "           , ? "
			+ "           , '03' " + "           , to_char(sysdate, 'YYYYMMDD') " + "           , 'KBCard' "
			+ "           , '**.**.**.**' " + "           , ? " + "           , decode(?, '10', '10', '20', '30') "
			+ "           , ? " + "           , nvl(?, ' ') " + "           , ? " + "           , ? "
			+ "           , ? " + "           , ? " + "           , '03' "
			+ "           , to_char(sysdate, 'YYYYMMDD') " + "           , to_char(sysdate, 'YYYYMMDD') "
			+ "            ) ";

	private int insertScsTrans() {
		int rValue = 0, result = 0;
		/*
		 * 
		 */
		try {
			ps = conn.prepareStatement(sqlInsertScsTrans);
			ps.setString(1, webId);
			ps.setString(2, webId);
			ps.setString(3, custNum);
			ps.setString(4, reqInfoNum);
			ps.setString(5, accountNum);

			result = ps.executeUpdate();

		} catch (Exception e) {
			System.out.println("insertScsTrans() : " + e.toString());
			rValue = 99;
		} finally {
			try {
				if (ps != null) {
					ps.close();
				}
			} catch (Exception e) {

			}
		}
		return rValue;
	}

	private static final String sqlInsertScsTrans = "INSERT INTO H11.SCS_TRANS_REQ " + "            (CUS_CID "
			+ "           , REQ_YMD " + "           , SEQ " + "           , CRT_DTM " + "           , CRT_EMPID "
			+ "           , CRT_IP " + "           , CUST_NUM " + "           , USE_CONT_NUM "
			+ "           , DEFRAY_ACCOUNT_NUM " + "           , TRANS_REQ_FLAG " + "            ) " + "VALUES      (? "
			+ "           , to_char(sysdate, 'YYYYMMDD') " + "           , (SELECT nvl(MAX(SEQ), 0) + 1 "
			+ "                FROM H11.SCS_TRANS_REQ " + "               WHERE CUS_CID = ? "
			+ "                 AND REQ_YMD = to_char(sysdate, 'YYYYMMDD')) " + "           , sysdate "
			+ "           , 'SYSTEM' " + "           , '**.**.**.**' " + "           , ? " + "           , ? "
			+ "           , ? " + "           , '30' " + "            ) ";

	private int sendKB() {
		int rValue = 0;

		// KB로 send

		try {
			ps = conn.prepareStatement(sqlselReq);
			ps.setString(1, accountNum);
			ps.setString(2, custNum);
			ps.setString(3, reqInfoNum);

			rs = ps.executeQuery();

			if (rs.next()) {
				String outMsg = "3000" + convFormat("3", 1) + convFormat(reqInfoNum, 20) + convFormat(accountNum, 16)
						+ convFormat(rs.getString("VALID_YM"), 4)
						// +
						// convFormat(rs.getString("SOC_BIZ_NUM").substring(0,7)
						// + "000000", 13) //황정현 수정 8111250000000
						+ convFormat(rs.getString("SOC_BIZ_NUM").substring(0, 6) + "0000000", 13) // 2015-03-13
																									// 주민번호
																									// 미수집에
																									// 따라
																									// 성별
																									// 0
																									// 처리
						+ convFormat(rs.getString("DEPOSITOR_NM"), 30)
						+ convFormat(convRelatCd(rs.getString("CUST_RELAT_CD"), 1), 2)
						+ convFormat(rs.getString("REQ_NM"), 30) + convFormat(rs.getString("REQ_TEL_DDD"), 4)
						+ convFormat(rs.getString("REQ_TEL_EXN"), 4) + convFormat(rs.getString("REQ_TEL_NUM"), 4)
						+ convFormat(rs.getString("DEPOSITOR_TEL_DDD"), 4)
						+ convFormat(rs.getString("DEPOSITOR_TEL_EXN"), 4)
						+ convFormat(rs.getString("DEPOSITOR_TEL_NUM"), 4)
						+ convFormat(rs.getString("ORIG_APPLY_YM"), 8) + convFormat(rs.getString("CUST_NM"), 30)
						+ convFormat(rs.getString("ZIP_NO"), 6) + convFormat(rs.getString("ADDR1"), 150)
						+ convFormat(rs.getString("ADDR2"), 150)
						// + convFormat(ci, 88) //황정현 CI 추가
						+ convFormat(" ", 88) // 2015-03-13 주민번호 미수집에 따른 CI정책 폐기
						+ convFormat(" ", 128) // 황정현 FILLER 추가
				;

				Socket socket = new Socket(kbIp, kbPort);
				socket.setSoTimeout(1000);

				BufferedInputStream bis = new BufferedInputStream(socket.getInputStream());
				BufferedOutputStream bos = new BufferedOutputStream(socket.getOutputStream());

				bos.write(2);
				bos.write(88); // 2 X 256 + 88 = 600

				bos.write(outMsg.getBytes("euc-kr"));
				bos.flush();

				byte[] readbyte = new byte[700]; // 황정현 수정 600 -> 700
				int len1 = bis.read();
				int len2 = bis.read();

				bis.read(readbyte, 0, 700); // 황정현 수정 600 -> 700

				if (bos != null)
					bos.close();
				if (bis != null)
					bis.close();
				if (socket != null)
					socket.close();

			}
		} catch (Exception e) {
			System.out.println("sendKB() : " + e.toString());
			rValue = 99;
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (ps != null) {
					ps.close();
				}
			} catch (Exception e) {
			}
		}
		return rValue;
	}

	private static final String kbIp = "10.20.1.55";
	private static final int kbPort = 23001;

	private final static String sqlselReq = "SELECT '3' TREAT_FLAG " + "     , D.USE_CONT_NUM "
			+ "     , C.DEFRAY_ACCOUNT_NUM " + "     , trim(B.VALID_PERIOD) VALID_YM " + "     , B.SOC_BIZ_NUM "
			+ "     , B.DEPOSITOR_NM " + "     , B.CUST_RELAT_CD " + "     , A.REQ_NM " + "     , A.REQ_TEL_DDD "
			+ "     , A.REQ_TEL_EXN " + "     , A.REQ_TEL_NUM " + "     , B.DEPOSITOR_TEL_DDD "
			+ "     , B.DEPOSITOR_TEL_EXN " + "     , B.DEPOSITOR_TEL_NUM " + "     , C.ORIG_APPLY_YM "
			+ "     , (SELECT CUST_NM " + "          FROM C11.C1AT_CUST_INFO X "
			+ "         WHERE X.CUST_NUM = D.CUST_NUM) CUST_NM " + "     , F.ZIP_NO1 || F.ZIP_NO2 ZIP_NO "
			+ "     , F.CITY || ' ' || F.COUNTY || ' ' || F.TOWN ADDR1 "
			+ "     , substr(E.CURR_ADDR_UNION, LENGTH(F.CITY || ' ' || F.COUNTY || ' ' || F.TOWN || ' ') + 1) ADDR2 " +
			// " , (SELECT NVL(CI_NUM, '') FROM C11.C1AT_CERT_MST WHERE
			// CERT_MANAGE_FLAG = '40' AND CERT_MANAGE_NUM = B.SOC_BIZ_NUM)
			// CI_NUM " +
			// " , (SELECT NVL(CI_NUM, '') FROM C11.C1AT_CERT_MST WHERE
			// CERT_MANAGE_FLAG = '40' AND CERT_MANAGE_NUM = (SELECT SOC_NUM
			// FROM C11.C1BT_USE_CONT A, C11.C1AT_CUST_INFO B WHERE A.CUST_NUM =
			// B.CUST_NUM AND A.USE_CONT_NUM = trim(D.USE_CONT_NUM))) CI_NUM " +
			"  FROM C11.C1AT_TRANS_ACNT_REQ A " + "     , C11.C1AT_TRANS_ACNT B " + "     , C11.C1BT_USE_CONT_TRANS C "
			+ "     , C11.C1BT_USE_CONT D " + "     , C31.C3AT_INST_PLACE E " + "     , A11.A1AT_ZIP F "
			+ " WHERE C.DEFRAY_ACCOUNT_NUM = B.DEFRAY_ACCOUNT_NUM " + "   AND C.CUST_NUM = B.CUST_NUM "
			+ "   AND A.DEFRAY_ACCOUNT_NUM(+) = C.DEFRAY_ACCOUNT_NUM " + "   AND A.CUST_NUM(+) = C.CUST_NUM "
			+ "   AND A.REQ_YMD(+) = C.CNL_YMD " + "   AND A.REQ_ITEM_CD(+) = '08' "
			+ "   AND C.REQ_INFO_NUM = D.REQ_INFO_NUM " + "   AND D.INST_PLACE_NUM = E.INST_PLACE_NUM "
			+ "   AND E.ZIP_SEQ = F.ZIP_SEQ " + "   AND C.DEFRAY_ACCOUNT_NUM = ? " + "   AND C.CUST_NUM = ? "
			+ "   AND C.REQ_INFO_NUM = ? " + "   AND C.CNL_YMD = to_char(SYSDATE, 'YYYYMMDD') ";

	public String convFormat(String str, int len) {
		String formattedstr = new String();
		byte[] buff;
		int filllen = 0;

		buff = str.getBytes();

		filllen = len - buff.length;
		formattedstr = "";

		for (int i = 0; i < filllen; i++) {
			formattedstr += " ";
		}
		formattedstr = str + formattedstr;

		return formattedstr;
	}

	/*
	 * convRelatCd(String relatCd, int direction) - 상호간 관계코드변환 direction : 0
	 * (KMC -> SCG) 1 (SCG -> KMC)
	 */
	private String convRelatCd(String relatCd, int direction) {
		String rValue = null;

		if (direction == 0 && relatCd != null) {
			if (relatCd.equals("01"))
				rValue = "10";
			else if (relatCd.equals("02"))
				rValue = "11";
			else if (relatCd.equals("03"))
				rValue = "13";
			else if (relatCd.equals("04"))
				rValue = "21";
			else if (relatCd.equals("05"))
				rValue = "12";
			else if (relatCd.equals("06"))
				rValue = "12";
			else if (relatCd.equals("07"))
				rValue = "14";
			else if (relatCd.equals("09"))
				rValue = "16";
			else
				rValue = "16";
		} else if (direction == 1 && relatCd != null) {
			if (relatCd.equals("10"))
				rValue = "01";
			else if (relatCd.equals("11"))
				rValue = "02";
			else if (relatCd.equals("12"))
				rValue = "05";
			else if (relatCd.equals("13"))
				rValue = "03";
			else if (relatCd.equals("14"))
				rValue = "07";
			else if (relatCd.equals("16"))
				rValue = "09";
			else if (relatCd.equals("21"))
				rValue = "04";
			else if (relatCd.equals("22"))
				rValue = "04";
			else
				rValue = "09";
		}
		return rValue;
	}

	/**
	 * 납부자 통합 고객인지 확인
	 * 
	 */
	private int chkPayTot() {

		int rValue = 0;

		try {
			StringBuffer sb = new StringBuffer();

			sb.append("SELECT 1 ");
			sb.append("FROM C21.C2BT_PAY_TOT_OBJ A ");
			sb.append("WHERE 1=1 ");
			sb.append("AND A.USE_CONT_NUM = ? ");
			sb.append("AND A.ADD_YN ='Y' ");

			String sqlchkPayTot = sb.toString();

			ps = conn.prepareStatement(sqlchkPayTot);

			ps.setString(1, reqInfoNum);

			rs = ps.executeQuery();

			// 건수가 있으면 납부통합고객이므로 해지 불가
			if (rs.next()) {
				rValue = 55;
			} else {
				rValue = 0;// 정상
			}

		} catch (Exception e) {
			System.out.println("!TransAcntReq.chkPayTot() : " + e.toString());
			rValue = 99;
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (ps != null) {
					ps.close();
				}
			} catch (Exception e) {

			}
		}
		return rValue;
	}
}
