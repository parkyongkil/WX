package scg.c24.net.server;

public interface CardDataServerMap {

	CardDataServer get(String uid);

	CardDataServer put(String uid, CardDataServer server);

	CardDataServer remove(String uid);

	void close();
}
