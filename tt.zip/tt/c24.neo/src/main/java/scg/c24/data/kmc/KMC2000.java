package scg.c24.data.kmc;

import lombok.Data;
import lombok.EqualsAndHashCode;
import scg.c24.data.CardDataRemote;
import tt.io.annotation.AtLPad;
import tt.io.annotation.AtSize;
import tt.io.annotation.AtUnuse;

/**
 * @제목 자동납부신청등록 요청,응답 (2000, 8150)
 * 
 * @요청 국민카드
 * @응답 서울도시가스
 */

@Data
@EqualsAndHashCode(callSuper = true)
public class KMC2000 extends KMCData implements CardDataRemote {

	/** 처리요청구분(1) 1=등록, 2=변경, 3=해지, 4=조회 */
	@AtSize(1)
	public String b01;

	/** 사용계약번호(20) */
	@AtSize(20)
	public String b02;

	/** 카드번호(16) */
	@AtSize(16)
	public String b03;

	/** 카드유효기간(4) yyMM */
	@AtSize(4)
	public String b04;

	/** 카드고객 주민번호(13) (현재 사용안함) (예전방식=199012310000000) */
	@AtSize(13)
	public String b05;

	@AtUnuse(print = true)
	public String b05x;

	/** 카드고객 성명(30) */
	@AtSize(30)
	public String b06;

	/** 신청인 관계코드(2) */
	@AtSize(2)
	public String b07;

	/** 신청인 성명(30) */
	@AtSize(30)
	public String b08;

	/** 신청인 휴대전화번호1(4) */
	@AtLPad(4)
	public String b09;

	/** 신청인 휴대전화번호2(4) */
	@AtLPad(4)
	public String b10;

	/** 신청인 휴대전화번호3(4) */
	@AtLPad(4)
	public String b11;

	/** 신청인 자택전화번호1(4) */
	@AtLPad(4)
	public String b12;

	/** 신청인 자택전화번호2(4) */
	@AtLPad(4)
	public String b13;

	/** 신청인 자택전화번호3(4) */
	@AtLPad(4)
	public String b14;

	/** 최초출금일(8) yyyyMMdd */
	@AtSize(8)
	public String b15;

	/** 계약고객명(30) */
	@AtSize(30)
	public String b16;

	/** 계약우편번호(6) */
	@AtSize(6)
	public String b17;

	/** 계약우편주소(150) */
	@AtSize(150)
	public String b18;

	/** 계약상세주소(150) */
	@AtSize(150)
	public String b19;

	/** CI(88) */
	@AtSize(88)
	public String b20;

	/** 제휴카드여부(1) YN */
	@AtSize(1)
	public String b21;

	/** 필러(127) */
	@AtSize(127)
	public String b22;

	@Override
	public void toSCGS() throws Exception {
		// NOTHING
	}

	@Override
	public void toCARD() throws Exception {
		b05x = b05;
		b05 = null;
	}
}
