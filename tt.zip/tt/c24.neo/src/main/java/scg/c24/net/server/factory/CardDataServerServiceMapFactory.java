package scg.c24.net.server.factory;

import scg.c24.ApplicationContextHolder;
import scg.c24.net.server.CardDataServerServiceMap;

public class CardDataServerServiceMapFactory {

	public static CardDataServerServiceMap create() {
		return ApplicationContextHolder.getBean(CardDataServerServiceMap.class);
	}
}
