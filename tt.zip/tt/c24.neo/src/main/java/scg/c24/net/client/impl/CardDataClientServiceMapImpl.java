package scg.c24.net.client.impl;

import java.util.HashMap;

import org.springframework.stereotype.Component;

import scg.c24.net.client.CardDataClientService;
import scg.c24.net.client.CardDataClientServiceMap;

@Component
public class CardDataClientServiceMapImpl extends HashMap<String, CardDataClientService>
		implements CardDataClientServiceMap {

	@Override
	public CardDataClientService get(String uid) {
		return super.get(uid);
	}

	@Override
	public CardDataClientService put(String uid, CardDataClientService service) {
		super.put(uid, service);
		return service;
	}

	@Override
	public CardDataClientService remove(String uid) {
		return super.remove(uid);
	}

	@Override
	public void close() {
		super.clear();
	}
}
