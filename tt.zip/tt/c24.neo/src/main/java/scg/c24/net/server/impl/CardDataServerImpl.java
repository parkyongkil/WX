package scg.c24.net.server.impl;

import java.net.InetSocketAddress;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Iterator;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.slf4j.Logger;

import scg.c24.config.CardDataConfig;
import scg.c24.net.server.CardDataServer;
import scg.c24.net.server.CardDataServerAcceptor;
import scg.c24.net.server.CardDataServerService;
import scg.c24.net.server.factory.CardDataServerAcceptorFactory;
import scg.c24.net.server.factory.CardDataServerServiceFactory;
import scg.c24.util.CardLoggerUtil;

public class CardDataServerImpl implements CardDataServer {

	private CardDataConfig config;
	private Logger logger;
	private CardDataServerService service;

	private Selector selector;
	private ServerSocketChannel serverSocketChannel;
	private ExecutorService executor;
	private boolean run;

	public CardDataServerImpl(CardDataConfig config) throws Exception {
		super();
		this.config = config;
		this.logger = CardLoggerUtil.getLogger(config.getUid(), CardDataServer.class);
		this.service = CardDataServerServiceFactory.create(config);
		Runtime.getRuntime().addShutdownHook(new Thread() {
			@Override
			public void run() {
				close();
			}
		});
	}

	@Override
	public void run() {
		try {
			selector = Selector.open();
			serverSocketChannel = ServerSocketChannel.open();
			serverSocketChannel.configureBlocking(false);
			serverSocketChannel.bind(new InetSocketAddress(config.getServer().getPort()));
			serverSocketChannel.register(selector, SelectionKey.OP_ACCEPT, null);
			executor = Executors.newCachedThreadPool();

			if (logger.isInfoEnabled())
				logger.info("Server({}) Started.", config.getServer().getPort());

			run = true;
			while (run) {
				if (selector.select() == 0)
					continue;
				Iterator<SelectionKey> it = selector.selectedKeys().iterator();
				while (it.hasNext()) {
					SelectionKey k = it.next();
					it.remove();
					if (k == null)
						continue;
					if (k.isAcceptable()) {
						SocketChannel socketChannel = serverSocketChannel.accept();
						socketChannel.configureBlocking(false);
						socketChannel.register(selector, SelectionKey.OP_READ);
						if (logger.isInfoEnabled())
							logger.info("Server({}) Accepted From ({}).", config.getServer().getPort(),
									socketChannel.getRemoteAddress());
						CardDataServerAcceptor acceptor = CardDataServerAcceptorFactory.create(config, socketChannel,
								service);
						executor.execute(acceptor);
					}
				}
			}
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		} finally {
			close();
		}
	}

	@Override
	public void close() {
		if (run)
			run = false;
		if (executor != null) {
			executor.shutdown();
			executor = null;
		}
		if (selector != null)
			try {
				selector.close();
				selector = null;
			} catch (Exception e) {
				logger.error(e.getMessage(), e);
			}
		if (serverSocketChannel != null)
			try {
				serverSocketChannel.close();
				serverSocketChannel = null;
				if (logger.isInfoEnabled())
					logger.info("Server({}) Closed.", config.getServer().getPort());
			} catch (Exception e) {
				logger.error(e.getMessage(), e);
			}
	}
}
