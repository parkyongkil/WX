package scg.c24.net.transfer.impl.kmc;

import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;

import org.apache.commons.lang3.math.NumberUtils;

import scg.c24.config.CardDataConfig;
import scg.c24.data.kmc.KMC1000;
import scg.c24.data.kmc.KMC2000;
import scg.c24.data.kmc.KMC3000;
import scg.c24.data.kmc.KMC4000;
import scg.c24.data.kmc.KMC4100;
import scg.c24.net.transfer.impl.CardDataTransferBase;

public class KMCCardDataTransfer extends CardDataTransferBase {

	private static final int FZ = 4096;
	private ByteBuffer fh = ByteBuffer.allocate(2);
	private ByteBuffer ff = ByteBuffer.allocate(FZ);

	public KMCCardDataTransfer(CardDataConfig config, SocketChannel socketChannel, boolean forServer) {
		super(config, socketChannel, forServer);
	}

	@Override
	public byte[] read() throws Exception {
		fh.clear();
		int i = socketChannel.read(fh);
		if (i == 0) {
			logger.error("{}: red 0 byte.", tr);
			return null;
		}
		if (i < 0)
			throw new Exception("읽기채널이 끊겼습니다.");
		if (i != 2)
			throw new Exception("전문길이를 읽지 못하였습니다.");
		fh.rewind();
		int n = ((fh.get() & 255) << 8) + (fh.get() & 255);
		if (n > ff.capacity())
			ff = ByteBuffer.allocate(n);
		else if (n < FZ && FZ < ff.capacity())
			(ff = ByteBuffer.allocate(FZ)).limit(n);
		else
			ff.clear().limit(n);
		i = socketChannel.read(ff);
		if (i < n)
			logger.error("읽기: {} 바이트, 기대값: {} 바이트.", i, n);
		byte[] b = new byte[n];
		ff.rewind();
		ff.get(b, 0, i);
		if (logger.isInfoEnabled())
			logger.info("{}({}): {}[{}]", tr, i > 4 ? new String(b, 0, 4, charset) : "X", i, new String(b, charset));
		return b;
	}

	@SuppressWarnings("unchecked")
	@Override
	public <X> X readObject() throws Exception {
		byte[] b = read();
		if (b == null)
			return null;
		String s = new String(b, 0, 4, charset);
		int n = NumberUtils.toInt(s);
		Class<?> c = null;
		switch (n) {
		case 1000:
		case 1100:
			c = KMC1000.class;
			break;
		case 2000:
		case 2100:
			c = KMC2000.class;
			break;
		case 3000:
		case 3100:
			c = KMC3000.class;
			break;
		case 4000:
			c = KMC4000.class;
			break;
		case 4100:
			c = KMC4100.class;
			break;
		default:
			throw new Exception(String.format("처리할 수 없는 전문구분값({})입니다.", s));
		}
		return (X) toObject(b, c);
	}

	@Override
	public void write(byte[] b) throws Exception {
		int n = b.length;
		if (logger.isInfoEnabled())
			logger.info("{}({}): {}[{}]", tr, n > 4 ? new String(b, 0, 4, charset) : "X", n, new String(b, charset));
		fh.clear();
		fh.put((byte) (n >>> 8 & 255));
		fh.put((byte) (n & 255));
		fh.rewind();
		socketChannel.write(fh);
		socketChannel.write(ByteBuffer.wrap(b));
	}

	@Override
	public <X> void writeObject(X o) throws Exception {
		write(toBytes(o));
	}

	@Override
	public void clear() {
		try {
			do {
				ff.clear();
			} while (socketChannel.read(ff) > 0);
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
	}
}
