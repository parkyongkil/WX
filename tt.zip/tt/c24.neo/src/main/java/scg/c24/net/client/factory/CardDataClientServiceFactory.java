package scg.c24.net.client.factory;

import scg.c24.config.CardDataConfig;
import scg.c24.net.client.CardDataClientService;
import scg.c24.net.client.CardDataClientServiceMap;
import scg.c24.net.client.pool.CardDataClientPool;
import scg.c24.net.client.pool.factory.CardDataClientPoolFactory;

public class CardDataClientServiceFactory {

	public static CardDataClientService create(CardDataConfig config) throws Exception {
		String uid = config.getUid();
		CardDataClientServiceMap map = CardDataClientServiceMapFactory.create();
		CardDataClientService service = map.remove(uid);
		if (service != null)
			service.close();
		CardDataClientPool pool = CardDataClientPoolFactory.create(config);
		service = config.getClient().getServiceType().getConstructor(CardDataConfig.class, CardDataClientPool.class)
				.newInstance(config, pool);
		return map.put(uid, service);
	}
}
