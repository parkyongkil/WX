package scg.c24.net.client;

import java.io.Closeable;

public interface CardDataClientServiceMap extends Closeable {

	CardDataClientService get(String uid);

	CardDataClientService put(String uid, CardDataClientService service);

	CardDataClientService remove(String uid);

	void close();
}
