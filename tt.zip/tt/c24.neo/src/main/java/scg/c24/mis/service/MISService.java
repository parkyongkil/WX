package scg.c24.mis.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import scg.c24.mis.data.MIS1000q;
import scg.c24.mis.data.MIS1000r;
import scg.c24.mis.data.MIS2000q;
import scg.c24.mis.data.MIS2000r;
import scg.c24.mis.data.MIS3000q;
import scg.c24.mis.data.MIS3000r;
import scg.c24.mis.data.MIS4000q;
import scg.c24.mis.data.MIS4000r;
import scg.c24.net.client.CardDataClientServiceMap;
import scg.c24.net.server.CardDataServerServiceMap;
import scg.c24.util.CardCom;

@Component
public class MISService {

	@Autowired
	CardDataServerServiceMap serverServiceMap;

	@Autowired
	CardDataClientServiceMap clientServiceMap;

	public MIS1000r mis1000(MIS1000q q) throws Exception {
		return serverServiceMap.get(CardCom.getByCardCd(q.CARD_CD).getCid()).callMis(q);
	}

	public MIS2000r mis2000(MIS2000q q) throws Exception {
		return serverServiceMap.get(CardCom.getByCardCd(q.CARD_CD).getCid()).callMis(q);
	}

	public MIS3000r mis3000(MIS3000q q) throws Exception {
		return clientServiceMap.get(CardCom.getByCardCd(q.CARD_CD).getCid()).callMis(q);
	}

	public MIS4000r mis4000(MIS4000q q) throws Exception {
		return clientServiceMap.get(CardCom.getByCardCd(q.CARD_CD).getCid()).callMis(q);
	}
}
