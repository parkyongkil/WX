package scg.c24.config;

import lombok.Data;
import scg.c24.net.server.CardDataServer;
import scg.c24.net.server.CardDataServerAcceptor;
import scg.c24.net.server.CardDataServerService;

@Data
public class CardDataServerConfig {

	private int port;
	private Class<CardDataServer> serverType;
	private Class<CardDataServerAcceptor> acceptorType;
	private Class<CardDataServerService> serviceType;
}
