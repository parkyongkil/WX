package scg.c24.data.ssc;

import java.util.List;

import lombok.Data;
import lombok.EqualsAndHashCode;
import scg.c24.data.CardData;
import tt.io.annotation.AtLPad;
import tt.io.annotation.AtSize;

@Data
@EqualsAndHashCode(callSuper = true)
public class SSC8050 extends SSCData {

	/** 고객명(100) */
	@AtSize(100)
	public String b01;

	/** 핸드폰식별번호1(3) */
	@AtSize(3)
	public String b02;

	/** 핸드폰국번2(4) */
	@AtSize(4)
	public String b03;

	/** 핸드폰전화번호3(4) */
	@AtSize(4)
	public String b04;

	/** 사용계약번호(10) */
	@AtSize(10)
	public String b05;

	/** 전송건수(1) */
	@AtLPad(1)
	public int b06;

	/** 계약번호, 주소 목록(5개고정) */
	@AtSize(5)
	public List<Cont> b07;

	/** 필러(18) */
	@AtSize(18)
	public String b17;

	@Data
	public static class Cont implements CardData {

		/** 사용계약번호 */
		@AtSize(10)
		public String c01;

		/** 주소 */
		@AtSize(500)
		public String c02;
	}
}
