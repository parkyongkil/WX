package scg.c24.net.client.pool;

import java.io.Closeable;

public interface CardDataClientPoolMap extends Closeable {

	CardDataClientPool get(String uid);

	CardDataClientPool put(String uid, CardDataClientPool pool);

	CardDataClientPool remove(String uid);

	void close();
}
