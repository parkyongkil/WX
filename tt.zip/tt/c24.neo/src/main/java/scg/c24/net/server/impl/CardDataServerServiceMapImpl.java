package scg.c24.net.server.impl;

import java.util.HashMap;

import org.springframework.stereotype.Component;

import scg.c24.net.server.CardDataServerService;
import scg.c24.net.server.CardDataServerServiceMap;

@Component
public class CardDataServerServiceMapImpl extends HashMap<String, CardDataServerService>
		implements CardDataServerServiceMap {

	@Override
	public CardDataServerService get(String uid) {
		return super.get(uid);
	}

	@Override
	public CardDataServerService put(String uid, CardDataServerService service) {
		super.put(uid, service);
		return service;
	}

	@Override
	public CardDataServerService remove(String uid) {
		return super.remove(uid);
	}

	@Override
	public void close() {
		for (CardDataServerService service : super.values())
			if (service != null)
				service.close();
		super.clear();
	}
}
