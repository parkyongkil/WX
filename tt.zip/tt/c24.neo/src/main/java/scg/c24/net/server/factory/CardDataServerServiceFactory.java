package scg.c24.net.server.factory;

import scg.c24.config.CardDataConfig;
import scg.c24.net.server.CardDataServerService;
import scg.c24.net.server.CardDataServerServiceMap;

public class CardDataServerServiceFactory {

	public static CardDataServerService create(CardDataConfig config) throws Exception {
		String uid = config.getUid();
		CardDataServerServiceMap map = CardDataServerServiceMapFactory.create();
		CardDataServerService service = map.get(uid);
		if (service != null)
			service.close();
		service = config.getServer().getServiceType().newInstance();
		map.put(uid, service);
		return service;
	}
}
