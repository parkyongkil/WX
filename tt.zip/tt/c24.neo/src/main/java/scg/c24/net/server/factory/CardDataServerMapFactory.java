package scg.c24.net.server.factory;

import scg.c24.ApplicationContextHolder;
import scg.c24.net.server.CardDataServerMap;
import scg.c24.net.server.impl.CardDataServerMapImpl;

public class CardDataServerMapFactory {

	public static CardDataServerMap create() {
		return ApplicationContextHolder.getBean(CardDataServerMapImpl.class);
	}
}
