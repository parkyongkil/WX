package scg.c24;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.scheduling.annotation.EnableScheduling;

import scg.c24.config.CardDataConfig;
import scg.c24.net.client.CardDataClientService;
import scg.c24.net.client.factory.CardDataClientServiceFactory;
import scg.c24.net.server.CardDataServer;
import scg.c24.net.server.factory.CardDataServerFactory;

@Configuration
@MapperScan(basePackages = { "scg.c24.biz" })
@EnableScheduling
public class CardDataConfiguration {

	@Bean
	@Primary
	@ConfigurationProperties(prefix = "card")
	CardDataConfig cardDataConfig() {
		return new CardDataConfig();
	}

	@Bean
	@ConfigurationProperties(prefix = "cardJob")
	CardDataConfig cardDataJobConfig() {
		return new CardDataConfig();
	}

	@Bean
	public CardDataServer server1() throws Exception {
		CardDataConfig config = cardDataConfig();
		return CardDataServerFactory.create(config);
	}

	@Bean
	public CardDataServer server2() throws Exception {
		CardDataConfig config = cardDataJobConfig();
		return CardDataServerFactory.create(config);
	}

	@Bean
	public CardDataClientService clientService1() throws Exception {
		CardDataConfig config = cardDataConfig();
		return CardDataClientServiceFactory.create(config);
	}
}
