package scg.c24.net.process;

public interface CardDataProcess<Q, R> {

	R call(Q q) throws Exception;
}
