package scg.c24.data.ssc;

import org.springframework.stereotype.Component;

import scg.c24.ApplicationContextHolder;
import scg.c24.biz.kmc.KMCUseContMapper;
import scg.c24.net.process.CardDataProcess;
import scg.c24.net.server.impl.ssc.SSCCardDataServerService;

@Component
public class SSC8050Process implements CardDataProcess<SSC8050, SSC8050> {

	KMCUseContMapper m1 = ApplicationContextHolder.getBean(KMCUseContMapper.class);

	@Override
	public SSC8050 call(SSC8050 q) throws Exception {

		SSC8050 r = new SSC8050();
		SSCCardDataServerService.setResponseHeader(q, r);

		return r;
	}
}
