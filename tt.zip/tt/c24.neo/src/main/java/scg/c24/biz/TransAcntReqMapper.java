package scg.c24.biz;

public class TransAcntReqMapper {

}
