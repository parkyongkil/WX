package scg.c24.net.server.impl.kmc;

import java.util.Date;

import org.apache.commons.lang3.time.DateFormatUtils;

import scg.c24.ApplicationContextHolder;
import scg.c24.data.kmc.KMC1000;
import scg.c24.data.kmc.KMC1000Process;
import scg.c24.data.kmc.KMC2000;
import scg.c24.data.kmc.KMC2000Process;
import scg.c24.data.kmc.KMCData;
import scg.c24.net.server.CardDataServerService;

public class KMCCardDataServerService implements CardDataServerService {

	private KMC1000Process p1000 = ApplicationContextHolder.getBean(KMC1000Process.class);
	private KMC2000Process p2000 = ApplicationContextHolder.getBean(KMC2000Process.class);

	@SuppressWarnings("unchecked")
	@Override
	public <Q, R> R call(Q q) throws Exception {
		if (q instanceof KMC1000)
			return (R) kmc1000((KMC1000) q);
		if (q instanceof KMC2000)
			return (R) kmc2000((KMC2000) q);
		throw new Exception(String.format("처리할 수 없는 자료구조(%s)입니다.", q == null ? "X" : q.getClass().getSimpleName()));
	}

	public KMC1000 kmc1000(KMC1000 q) throws Exception {
		return p1000.call(q);
	}

	public KMC2000 kmc2000(KMC2000 q) throws Exception {
		return p2000.call(q);
	}

	@Override
	public <Q, R> R callMis(Q q) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void close() {
		// NOTHING
	}

	public static void setResponseHeader(KMCData q, KMCData r) {
		r.a01 = q.a01.replaceAll("^(.)0", "$11");
		r.a02 = q.a03;
		r.a03 = q.a02;
		r.a04 = q.a04;
		r.a05 = DateFormatUtils.format(new Date(), "yyyyMMddHHmmss");
		r.a06 = "0000";
	}
}
