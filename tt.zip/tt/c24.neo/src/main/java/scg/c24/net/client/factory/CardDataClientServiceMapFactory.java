package scg.c24.net.client.factory;

import scg.c24.ApplicationContextHolder;
import scg.c24.net.client.CardDataClientServiceMap;
import scg.c24.net.client.impl.CardDataClientServiceMapImpl;

public class CardDataClientServiceMapFactory {

	public static CardDataClientServiceMap create() {
		return ApplicationContextHolder.getBean(CardDataClientServiceMapImpl.class);
	}
}
