package scg.c24.net.client.pool.factory;

import org.apache.commons.pool2.PooledObject;
import org.apache.commons.pool2.PooledObjectFactory;
import org.apache.commons.pool2.impl.DefaultPooledObject;

import scg.c24.config.CardDataConfig;
import scg.c24.net.client.CardDataClient;
import scg.c24.net.client.factory.CardDataClientFactory;

public class CardDataClientPooledObjectFactory implements PooledObjectFactory<CardDataClient> {

	private CardDataConfig config;

	public CardDataClientPooledObjectFactory(CardDataConfig config) {
		super();
		this.config = config;
	}

	@Override
	public PooledObject<CardDataClient> makeObject() throws Exception {
		CardDataClient o = CardDataClientFactory.create(config);
		o.open();
		return new DefaultPooledObject<>(o);
	}

	@Override
	public void destroyObject(PooledObject<CardDataClient> p) throws Exception {
		CardDataClient o = p.getObject();
		if (o != null)
			o.close();
	}

	@Override
	public boolean validateObject(PooledObject<CardDataClient> p) {
		CardDataClient o = p.getObject();
		return o != null && o.validate();
	}

	@Override
	public void activateObject(PooledObject<CardDataClient> p) throws Exception {
		CardDataClient o = p.getObject();
		if (o != null)
			o.clear();
	}

	@Override
	public void passivateObject(PooledObject<CardDataClient> p) throws Exception {
		CardDataClient o = p.getObject();
		if (o != null)
			o.clear();
	}
}
