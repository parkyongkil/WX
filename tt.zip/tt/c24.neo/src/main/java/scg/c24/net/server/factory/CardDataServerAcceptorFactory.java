package scg.c24.net.server.factory;

import java.nio.channels.SocketChannel;

import scg.c24.config.CardDataConfig;
import scg.c24.net.server.CardDataServerAcceptor;
import scg.c24.net.server.CardDataServerService;

public class CardDataServerAcceptorFactory {

	public static CardDataServerAcceptor create(CardDataConfig config, SocketChannel socketChannel,
			CardDataServerService service) throws Exception {
		return config.getServer().getAcceptorType()
				.getConstructor(CardDataConfig.class, SocketChannel.class, CardDataServerService.class)
				.newInstance(config, socketChannel, service);
	}
}
