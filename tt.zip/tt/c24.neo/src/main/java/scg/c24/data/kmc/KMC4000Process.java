package scg.c24.data.kmc;

import org.springframework.stereotype.Component;

import scg.c24.ApplicationContextHolder;
import scg.c24.biz.kmc.KMCUseContMapper;
import scg.c24.net.process.CardDataProcess;
import scg.c24.net.server.impl.kmc.KMCCardDataServerService;

@Component
public class KMC4000Process implements CardDataProcess<KMC4000, KMC4100> {

	KMCUseContMapper m1 = ApplicationContextHolder.getBean(KMCUseContMapper.class);

	@Override
	public KMC4100 call(KMC4000 q) throws Exception {

		KMC4100 r = new KMC4100();
		KMCCardDataServerService.setResponseHeader(q, r);

		// TODO

		return r;
	}
}
