package scg.c24.data.kmc;

import org.springframework.stereotype.Component;

import scg.c24.ApplicationContextHolder;
import scg.c24.biz.kmc.KMCUseContMapper;
import scg.c24.net.process.CardDataProcess;
import scg.c24.net.server.impl.kmc.KMCCardDataServerService;

@Component
public class KMC3000Process implements CardDataProcess<KMC3000, KMC3000> {

	KMCUseContMapper m1 = ApplicationContextHolder.getBean(KMCUseContMapper.class);

	@Override
	public KMC3000 call(KMC3000 q) throws Exception {

		KMC3000 r = new KMC3000();
		KMCCardDataServerService.setResponseHeader(q, r);

		String useContNum = q.b01;
		String custName = q.b06;
		String cp1 = q.b10;
		String cp2 = q.b11;
		String cp3 = q.b12;

		// TODO
		return r;
	}
}
