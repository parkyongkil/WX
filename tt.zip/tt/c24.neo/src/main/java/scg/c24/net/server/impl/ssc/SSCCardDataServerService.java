package scg.c24.net.server.impl.ssc;

import scg.c24.data.ssc.SSC8050;
import scg.c24.data.ssc.SSC8150;
import scg.c24.data.ssc.SSCData;
import scg.c24.net.server.CardDataServerService;

public class SSCCardDataServerService implements CardDataServerService {

	@SuppressWarnings("unchecked")
	@Override
	public <Q, R> R call(Q q) throws Exception {
		if (q instanceof SSC8050)
			return (R) biz8050((SSC8050) q);
		if (q instanceof SSC8150)
			return (R) biz8150((SSC8150) q);
		// if (q instanceof SSC9050)
		// return (R) biz9050((SSC9050) q);
		// if (q instanceof SSC9150)
		// return (R) biz9150((SSC9150) q);
		throw new Exception(String.format("서버에서 처리할 수 없는 전문(%s)입니다.", q == null ? "X" : q.getClass().getSimpleName()));
	}

	@Override
	public void close() {
		// NOTHING
	}

	@Override
	public <Q, R> R callMis(Q q) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	public SSC8050 biz8050(SSC8050 q) {
		// TODO
		return null;
	}

	public SSC8150 biz8150(SSC8150 q) {
		// TODO
		return null;
	}

	// public SSC9050 biz9050(SSC9050 q) {
	// // TODO
	// return null;
	// }
	//
	// public SSC9150 biz9150(SSC9150 q) {
	// // TODO
	// return null;
	// }

	public static void setResponseHeader(SSCData q, SSCData r) {
		// TODO
	}
}
