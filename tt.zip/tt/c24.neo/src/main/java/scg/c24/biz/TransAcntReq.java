package scg.c24.biz;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.net.Socket;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.sql.DataSource;

import scg.c24.ApplicationContextHolder;

public class TransAcntReq {

	private String accountNum;
	private String bnkCd;
	private String useContNum;
	private String validYm;
	private String socBizNum;
	private String depositNm;
	private String relatCd;
	private String reqNm;
	private String reqCpDdd;
	private String reqCpExn;
	private String reqCpNum;
	private String reqTelDdd;
	private String reqTelExn;
	private String reqTelNum;
	private String payMethod;
	private String receiveSecCd; // 5 홈페이지 6 카드사
	private String webId;
	private String ci;
	private String joinYn;

	private String custNum;
	private String receiveStsCd;
	private String applyYmd;
	private String treatFlag;

	private Connection conn = null;
	private PreparedStatement ps = null;
	private ResultSet rs = null;

	private DataSource dataSource;

	public TransAcntReq(String accountNum, String bnkCd, String useContNum, String validYm, String socBizNum,
			String depositNm, String relatCd, String reqNm, String reqCpDdd, String reqCpExn, String reqCpNum,
			String reqTelDdd, String reqTelExn, String reqTelNum, String payMethod, String receiveSecCd, String webId,
			String ci, String joinYn) {
		this.accountNum = accountNum;
		this.bnkCd = bnkCd;
		this.useContNum = useContNum;
		this.validYm = validYm;
		this.socBizNum = socBizNum;
		this.depositNm = depositNm;
		this.relatCd = relatCd;
		this.reqNm = reqNm;
		this.reqCpDdd = reqCpDdd;
		this.reqCpExn = reqCpExn;
		this.reqCpNum = reqCpNum;
		this.reqTelDdd = reqTelDdd;
		this.reqTelExn = reqTelExn;
		this.reqTelNum = reqTelNum;
		this.payMethod = payMethod;
		this.receiveSecCd = receiveSecCd;
		this.webId = webId;
		this.ci = ci;
		this.joinYn = joinYn;

		this.dataSource = ApplicationContextHolder.getBean(DataSource.class);
	}

	public int start() {
		int chk, rValue = 0;
		String tmpStsCd;

		chk = validate();
		// parameter 체크
		if (chk != 0) {
			return chk;
		}

		try {
			conn = dataSource.getConnection();
			conn.setAutoCommit(false);
			// 사용계약 상태 체크
			chk = chkUseCont();
			if (chk != 0) {
				throw new Exception("사용계약번호 상태 오류");
			}

			// 이체상태 체크
			chk = chkTrans();
			if (chk == 99) {
				throw new Exception("이체상태 체크 오류");
			}

			if (chk == 10) {

				// TODO 카드자동이체 변경시(20) 납부자통합 고객 체크 2016-02-18
				chk = chkPayTot("20");

				if (chk != 0) {
					throw new Exception("납부자통합 고객 변경불가");
				}

				TransAcntCnl objCnl = new TransAcntCnl(useContNum, "40", null, null, null, null, null, null, "1", "N",
						"6", null, true, conn, ci);
				chk = objCnl.start();
				if (chk != 0) {
					throw new Exception("사용계약 변경(해지)중 오류");
				}
			} else {

				// TODO 카드자동이체 신청시(10) 납부자통합 고객 체크 2016-02-18
				chk = chkPayTot("10");
				if (chk != 0) {
					throw new Exception("납부자통합 고객 신청불가");
				}
			}

			// 현재 계좌상태 조회 process
			chk = chkReceiveSts();
			if (chk == 99) {
				throw new Exception("계좌정보 조회 중 오류");
			}

			if (payMethod.equals("20")) // 자동이체는 접수
			{
				tmpStsCd = "10";
			} else // 카드이체는 바로 정상
			{
				tmpStsCd = "20";
			}

			if (receiveStsCd == null || receiveStsCd.equals("")) { // 계좌없음->신규생성
				chk = insertTransAcnt();
				if (chk != 0)
					throw new Exception("이체계좌생성오류");
				chk = insertTransAcntReq();
				if (chk != 0)
					throw new Exception("이체계좌신청생성오류");
				chk = insertUseContTrans(tmpStsCd);
				if (chk != 0)
					throw new Exception("사용계약이체생성오류");

			} else if (receiveStsCd.equals("11") || receiveStsCd.equals("30") || receiveStsCd.equals("40")) { // 접수취소,해지,오류->변경+신규
				chk = updateTransAcnt();
				if (chk != 0)
					throw new Exception("이체계좌변경오류");
				chk = insertTransAcntReq();
				if (chk != 0)
					throw new Exception("이체계좌신청생성오류");
				chk = insertUseContTrans(tmpStsCd);
				if (chk != 0)
					throw new Exception("사용계약이체생성오류");
			} else if (receiveStsCd.equals("10") || receiveStsCd.equals("20")) { // 접수,정상->신규
				chk = insertUseContTrans(receiveStsCd);
				if (chk != 0)
					throw new Exception("사용계약이체생성오류");
			}

			if ((receiveStsCd != null && receiveStsCd.equals("20")) || payMethod.equals("30")) { // 은행이체,정상
																									// &&
																									// 카드이체
																									// ->
																									// 납부방법변경
				chk = updateReqInfo();
				if (chk != 0)
					throw new Exception("청구정보변경오류");
			}

			if (receiveSecCd.equals("5")) { // 홈페이지 -> 추가인서트
				chk = insertScsTrans();
				if (chk != 0)
					throw new Exception("홈페이지입력오류");
				if (payMethod.equals("30")) {
					chk = sendKB();
				}
			}

		} catch (Exception e) {
			System.out.println("TransAcntReq.start() : catch! " + e.toString());
			rValue = chk;
		} finally {
			try {
				if (conn != null) {
					if (rValue == 0)
						conn.commit();
					else
						conn.rollback();
				}

				if (conn != null)
					conn.close();
			} catch (Exception e) {

			}
		}

		return rValue;
	}

	/*
	 * validate() - parameter 체크
	 */
	private int validate() {
		if (accountNum == null || accountNum.length() > 20) {
			System.out.println("!accountNum error : " + accountNum);
			return 98;
		}
		if (bnkCd == null || bnkCd.length() != 3) {
			System.out.println("!bnkCd error : " + bnkCd);
			return 98;
		}
		if (useContNum == null || useContNum.length() != 10) {
			System.out.println("!useContNum error : " + useContNum);
			return 98;
		}
		if (validYm != null && validYm.length() != 4) {
			System.out.println("!validYm error : " + validYm);
			return 98;
		}
		if (socBizNum == null || (socBizNum.length() != 13 && socBizNum.length() != 10)) {
			System.out.println("!socBizNum error : " + socBizNum);
			return 98;
		}
		if (relatCd == null || relatCd.length() != 2) {
			System.out.println("!relatCd error : " + relatCd);
			return 98;
		}
		if (payMethod == null || payMethod.length() != 2) {
			System.out.println("!payMethod error : " + payMethod);
			return 98;
		}
		return 0;
	}

	private int chkUseCont() {
		int rValue = 0;
		/*
		 * check! 0. 사용계약번호 존재여부 체크 1. 사용계약번호 상태 체크 2. 당일접수자료 체크 3. 임시고객번호 체크
		 */
		try {
			ps = conn.prepareStatement(sqlChk);
			ps.setString(1, useContNum);
			ps.setString(2, useContNum);
			ps.setString(3, accountNum);
			ps.setString(4, useContNum);
			ps.setString(5, useContNum);
			ps.setString(6, useContNum);

			rs = ps.executeQuery();

			if (rs.next()) {

				if (rs.getString("CHK_0").equals("0")) {
					System.out.println("!TransAcntReq.chkUseCont:사용계약미존재 오류");
					rValue = 10;
				} else if (rs.getString("CHK_1").equals("0")) {
					System.out.println("!TransAcntReq.chkUseCont:사용계약 해지상태 오류");
					rValue = 20;
				} else if (rs.getString("CHK_2").equals("0")) {
					System.out.println("!TransAcntReq.chkUseCont:기신청자료");
					rValue = 30;
				} else if (rs.getString("CHK_3").equals("0")) {
					System.out.println("!TransAcntReq.chkUseCont:임시고객번호 오류");
					rValue = 40;
				} else if (rs.getString("CHK_4").equals("2") && this.payMethod.equals("30")) {
					System.out.println("!TransAcntReq.chkUseCont:비가정용 신청 오류");
					rValue = 90;
				}
			} else {
				rValue = 99;
			}
		} catch (Exception e) {
			System.out.println("!TransAcntReq.chkUseCont() : " + e.toString());
			rValue = 99;
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (ps != null) {
					ps.close();
				}
			} catch (Exception e) {

			}
		}
		return rValue;
	}

	private static final String sqlChk = "SELECT nvl((SELECT '1' " + "              FROM C11.C1BT_USE_CONT "
			+ "             WHERE USE_CONT_NUM = ?), '0') CHK_0 " + "     , nvl((SELECT '1' "
			+ "              FROM C11.C1BT_USE_CONT " + "             WHERE USE_CONT_NUM = ? "
			+ "               AND CONT_STS_CD != '30'), '0') CHK_1 " + "     , nvl((SELECT '0' "
			+ "              FROM C11.C1BT_USE_CONT_TRANS " + "             WHERE DEFRAY_ACCOUNT_NUM = ? "
			+ "               AND REQ_INFO_NUM = ? " + "               AND REQ_YMD = to_char(sysdate, 'YYYYMMDD')) "
			+ "         , '1') CHK_2 " + "     , nvl((SELECT '1' " + "              FROM C11.C1BT_USE_CONT "
			+ "             WHERE USE_CONT_NUM = ? " + "               AND CUST_NUM NOT LIKE '0%'), '0') CHK_3 "
			+ "     , nvl((SELECT C21.PKS_C2_FUNC_4.FUNC_GET_PAY_INF(?, '7') "
			+ "              FROM dual ), '0') CHK_4 " + "  FROM dual ";

	private int chkTrans() {
		int rValue = 0;
		/*
		 * check! 현재 이체계좌 상태 체크 및 고객번호 등 조회
		 */
		try {
			ps = conn.prepareStatement(sqlchkTrans);
			ps.setString(1, useContNum);

			rs = ps.executeQuery();

			if (rs.next()) {
				this.custNum = rs.getString("CUST_NUM");
				this.applyYmd = rs.getString("APPLY_YMD");
				this.treatFlag = rs.getString("TREAT_FLAG");
				if (rs.getString("TRANS_YN").equals("Y")) // 이체중이면 해지 실시
				{
					rValue = 10;
				}
			} else {
				rValue = 99; // 사용계약 없어짐
			}
		} catch (Exception e) {
			System.out.println("chkTrans() : " + e.toString());
			rValue = 99;
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (ps != null) {
					ps.close();
				}
			} catch (Exception e) {

			}
		}
		return rValue;
	}

	private static final String sqlchkTrans = "SELECT A.CUST_NUM " + "     , B.DEFRAY_ACCOUNT_NUM "
			+ "     , B.REQ_INFO_NUM " + "     , B.REQ_YMD "
			+ "     , CASE WHEN B.BNK_CD = '807' THEN '2' ELSE '1' END TREAT_FLAG " + "     , CASE "
			+ "           WHEN B.DEFRAY_ACCOUNT_NUM IS NULL THEN 'N' " + "           ELSE 'Y' " + "       END TRANS_YN "
			+ "     , C21.PKS_C2_FUNC_4.FUNC_GET_C1_ORIG_APPLY_YMD(A.USE_CONT_NUM) APPLY_YMD "
			+ "  FROM C11.C1BT_USE_CONT A " + "     , (SELECT * " + "          FROM C11.C1BT_USE_CONT_TRANS B "
			+ "         WHERE RECEIVE_STS_CD IN('10', '20') " + "           AND CNL_YMD = '99991231') B "
			+ " WHERE A.USE_CONT_NUM = ? " + "   AND A.REQ_INFO_NUM = B.REQ_INFO_NUM(+) "
			+ "   AND A.CUST_NUM = B.CUST_NUM(+) ";

	private int chkReceiveSts() {
		int rValue = 0;
		/*
		 * check! 현재계좌상태 체크
		 */
		try {
			ps = conn.prepareStatement(sqlchkReceiveSts);
			ps.setString(1, accountNum);
			ps.setString(2, custNum);

			rs = ps.executeQuery();

			if (rs.next()) {
				receiveStsCd = rs.getString("RECEIVE_STS_CD");
			} else {
				receiveStsCd = null;
			}
		} catch (Exception e) {
			System.out.println("chkReceiveSts() : " + e.toString());
			rValue = 99;
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (ps != null) {
					ps.close();
				}
			} catch (Exception e) {

			}
		}
		return rValue;
	}

	private static final String sqlchkReceiveSts = "SELECT RECEIVE_STS_CD " + "  FROM C11.C1AT_TRANS_ACNT "
			+ " WHERE DEFRAY_ACCOUNT_NUM = ? " + "   AND CUST_NUM = ? ";

	private int insertTransAcnt() {
		int rValue = 0, result;
		/*
		 * 
		 */
		try {
			ps = conn.prepareStatement(sqlinsertTransAcnt);
			ps.setString(1, accountNum);
			ps.setString(2, custNum);
			ps.setString(3, payMethod);
			ps.setString(4, bnkCd);
			ps.setString(5, receiveSecCd);
			ps.setString(6, payMethod);
			ps.setString(7, payMethod);
			ps.setString(8, custNum);
			ps.setString(9, bnkCd + "0000");
			ps.setString(10, bnkCd + "0000");
			ps.setString(11, socBizNum);
			ps.setString(12, depositNm);
			ps.setString(13, relatCd);
			ps.setString(14, reqTelDdd);
			ps.setString(15, reqTelExn);
			ps.setString(16, reqTelNum);
			ps.setString(17, validYm);

			result = ps.executeUpdate();

		} catch (Exception e) {
			System.out.println("insertTransAcnt() : " + e.toString());
			rValue = 99;
		} finally {
			try {
				if (ps != null) {
					ps.close();
				}
			} catch (Exception e) {

			}
		}
		return rValue;
	}

	private static final String sqlinsertTransAcnt = "INSERT INTO C11.C1AT_TRANS_ACNT "
			+ "            (DEFRAY_ACCOUNT_NUM " + "           , CUST_NUM " + "           , CRT_EMPID "
			+ "           , CRT_IP " + "           , TRAN_FLAG " + "           , BNK_CD "
			+ "           , RECEIVE_PLC_FLAG_CD " + "           , RECEIVE_STS_CD " + "           , REQ_YMD "
			+ "           , CNL_YMD " + "           , PAY_METHOD_CD " + "           , BEFO_PAY_MANAGE_NUM "
			+ "           , ACCOUNT_BRANCH_CD " + "           , BNK_BRANCH_CD " + "           , SOC_BIZ_NUM "
			+ "           , DEPOSITOR_NM " + "           , CUST_RELAT_CD " + "           , DEPOSITOR_TEL_DDD "
			+ "           , DEPOSITOR_TEL_EXN " + "           , DEPOSITOR_TEL_NUM " + "           , VALID_PERIOD "
			+ "           , TRANS_YMD " + "            ) " + "VALUES      (? " + "           , ? "
			+ "           , 'KBCard' " + "           , '**.**.**.**' "
			+ "           , DECODE(?, '20', '10', '30', '20', ' ') " + "           , ? "
			+ "           , DECODE(?, '5', '5', '6', '4', ' ') " + "           , DECODE(?, '20', '10', '30', '20') "
			+ "           , to_char(SYSDATE, 'YYYYMMDD') " + "           , '99991231' " + "           , ? "
			+ "           , nvl(?, ' ') " + "           , nvl(?, ' ') " + "           , nvl(?, ' ') "
			+ "           , ? " + "           , ? " + "           , nvl(?, ' ') " + "           , ? "
			+ "           , ? " + "           , ? " + "           , nvl(?, ' ') "
			+ "           , to_char(SYSDATE, 'YYYYMMDD') " + "            ) ";

	private int updateTransAcnt() {
		int rValue = 0, result;
		/*
		 * 
		 */
		try {
			ps = conn.prepareStatement(sqlupdateTransAcnt);

			ps.setString(1, payMethod);
			ps.setString(2, bnkCd);
			ps.setString(3, receiveSecCd);
			ps.setString(4, payMethod);
			ps.setString(5, payMethod);
			ps.setString(6, bnkCd + "0000");
			ps.setString(7, bnkCd + "0000");
			ps.setString(8, socBizNum);
			ps.setString(9, depositNm);
			ps.setString(10, relatCd);
			ps.setString(11, reqTelDdd);
			ps.setString(12, reqTelExn);
			ps.setString(13, reqTelNum);
			ps.setString(14, validYm);
			ps.setString(15, accountNum);
			ps.setString(16, custNum);

			result = ps.executeUpdate();

		} catch (Exception e) {
			System.out.println("updateTransAcnt() : " + e.toString());
			rValue = 99;
		} finally {
			try {
				if (ps != null) {
					ps.close();
				}
			} catch (Exception e) {

			}
		}
		return rValue;
	}

	private static final String sqlupdateTransAcnt = "UPDATE C11.C1AT_TRANS_ACNT " + "   SET UPD_DTM = sysdate "
			+ "     , UPD_EMPID = 'KBCard' " + "     , UPD_IP = '**.**.**.**' "
			+ "     , TRAN_FLAG = decode(?, '20', '10', '30', '20', ' ') " + "     , BNK_CD = nvl(?, BNK_CD) "
			+ "     , RECEIVE_PLC_FLAG_CD = decode(?, '5', '5', '6', '4', ' ') "
			+ "     , RECEIVE_STS_CD = decode(?, '20', '10', '30', '20') "
			+ "     , REQ_YMD = to_char(sysdate, 'YYYYMMDD') " + "     , TRANS_YMD = to_char(sysdate, 'YYYYMMDD') "
			+ "     , CNL_YMD = '99991231' " + "     , CNL_WHY_CD = ' ' "
			+ "     , PAY_METHOD_CD = nvl(?, PAY_METHOD_CD) " + "     , ACCOUNT_BRANCH_CD = nvl(?, ACCOUNT_BRANCH_CD) "
			+ "     , BNK_BRANCH_CD = nvl(?, BNK_BRANCH_CD) " + "     , SOC_BIZ_NUM = nvl(?, SOC_BIZ_NUM) "
			+ "     , DEPOSITOR_NM = nvl(?, DEPOSITOR_NM) " + "     , CUST_RELAT_CD = nvl(?, CUST_RELAT_CD) "
			+ "     , DEPOSITOR_TEL_DDD = nvl(?, DEPOSITOR_TEL_DDD) "
			+ "     , DEPOSITOR_TEL_EXN = nvl(?, DEPOSITOR_TEL_EXN) "
			+ "     , DEPOSITOR_TEL_NUM = nvl(?, DEPOSITOR_TEL_NUM) " + "     , VALID_PERIOD = nvl(?, VALID_PERIOD) "
			+ " WHERE DEFRAY_ACCOUNT_NUM = ? " + "   AND CUST_NUM = ? ";

	private int insertTransAcntReq() {
		int rValue = 0, result;
		/*
		 * 
		 */
		try {
			ps = conn.prepareStatement(sqlinsertTransAcntReq);
			ps.setString(1, accountNum);
			ps.setString(2, custNum);
			ps.setString(3, bnkCd);
			ps.setString(4, payMethod);
			ps.setString(5, receiveSecCd);
			ps.setString(6, relatCd);
			ps.setString(7, reqNm);
			ps.setString(8, reqCpDdd);
			ps.setString(9, reqCpExn);
			ps.setString(10, reqCpNum);
			ps.setString(11, validYm);

			result = ps.executeUpdate();

		} catch (Exception e) {
			System.out.println("insertTransAcntReq() : " + e.toString());
			rValue = 99;
		} finally {
			try {
				if (ps != null) {
					ps.close();
				}
			} catch (Exception e) {

			}
		}
		return rValue;
	}

	private static final String sqlinsertTransAcntReq = "INSERT INTO C11.C1AT_TRANS_ACNT_REQ "
			+ "            (DEFRAY_ACCOUNT_NUM " + "           , CUST_NUM " + "           , REQ_ITEM_CD "
			+ "           , REQ_YMD " + "           , CRT_EMPID " + "           , CRT_IP " + "           , BNK_CD "
			+ "           , REQ_RSLT_CD " + "           , RECEIVE_SEC_CD " + "           , CUST_RELAT_CD "
			+ "           , REQ_NM " + "           , REQ_TEL_DDD " + "           , REQ_TEL_EXN "
			+ "           , REQ_TEL_NUM " + "           , KFTC_RECEIVE_STS_CD " + "           , VALID_PERIOD "
			+ "           , TRANS_YMD " + "           , APPRO_YMD " + "            ) " + "VALUES      (? "
			+ "           , ? " + "           , '01' " + "           , to_char(sysdate, 'YYYYMMDD') "
			+ "           , 'KBCard' " + "           , '**.**.**.**' " + "           , ? "
			+ "           , DECODE(?, '20', '10', '30', '30') " + "           , ? " + "           , ? "
			+ "           , ? " + "           , ? " + "           , ? " + "           , ? " + "           , '01' "
			+ "           , nvl(?, ' ') " + "           , to_char(sysdate, 'YYYYMMDD') "
			+ "           , to_char(sysdate, 'YYYYMMDD') " + "            ) ";

	private int insertUseContTrans(String parReceiveSts) {
		int rValue = 0, result;
		/*
		 * 
		 */
		try {
			ps = conn.prepareStatement(sqlinsertUseContTrans);
			ps.setString(1, accountNum);
			ps.setString(2, custNum);
			ps.setString(3, useContNum);
			ps.setString(4, bnkCd);
			ps.setString(5, parReceiveSts);
			ps.setString(6, receiveSecCd);
			ps.setString(7, applyYmd);
			ps.setString(8, joinYn);

			result = ps.executeUpdate();

		} catch (Exception e) {
			System.out.println("insertUseContTrans() : " + e.toString());
			rValue = 99;
		} finally {
			try {
				if (ps != null) {
					ps.close();
				}
			} catch (Exception e) {

			}
		}
		return rValue;
	}

	private static final String sqlinsertUseContTrans = "INSERT INTO C11.C1BT_USE_CONT_TRANS "
			+ "            (DEFRAY_ACCOUNT_NUM " + "           , CUST_NUM " + "           , REQ_INFO_NUM "
			+ "           , REQ_YMD " + "           , CRT_EMPID " + "           , CRT_IP " + "           , BNK_CD "
			+ "           , RECEIVE_STS_CD " + "           , RECEIVE_SEC_CD " + "           , ORIG_APPLY_YM "
			+ "           , CNL_YMD " + "           , JOIN_YN " + "            ) " + "VALUES      (? "
			+ "           , ? " + "           , ? " + "           , to_char(sysdate, 'YYYYMMDD') "
			+ "           , 'KBCard' " + "           , '**.**.**.**' " + "           , ? " + "           , ? "
			+ "           , nvl(?, ' ') " + "           , ? " + "           , '99991231' " + "           , ? " + // 제휴카드여부
			"            ) ";

	private int updateReqInfo() {
		int rValue = 0, result;
		/*
		 * 
		 */
		try {
			ps = conn.prepareStatement(sqlupdateReqInfo);
			ps.setString(1, payMethod);
			ps.setString(2, useContNum);

			result = ps.executeUpdate();

		} catch (Exception e) {
			System.out.println("updateReqInfo() : " + e.toString());
			rValue = 99;
		} finally {
			try {
				if (ps != null) {
					ps.close();
				}
			} catch (Exception e) {

			}
		}
		return rValue;
	}

	private static final String sqlupdateReqInfo = "UPDATE C11.C1BT_REQ_INFO " + "   SET UPD_DTM = sysdate "
			+ "     , UPD_EMPID = 'KBCard' " + "     , UPD_IP = '**.**.**.**' " + "     , PAY_METHOD_CD = ? "
			+ " WHERE REQ_INFO_NUM = ? ";

	private int insertScsTrans() {
		int rValue = 0, result;
		/*
		 * 
		 */
		try {
			ps = conn.prepareStatement(sqlInsertScsTrans);
			ps.setString(1, webId);
			ps.setString(2, webId);
			ps.setString(3, custNum);
			ps.setString(4, useContNum);
			ps.setString(5, accountNum);

			result = ps.executeUpdate();

		} catch (Exception e) {
			System.out.println("insertScsTrans() : " + e.toString());
			rValue = 99;
		} finally {
			try {
				if (ps != null) {
					ps.close();
				}
			} catch (Exception e) {

			}
		}
		return rValue;
	}

	private static final String sqlInsertScsTrans = "INSERT INTO H11.SCS_TRANS_REQ " + "            (CUS_CID "
			+ "           , REQ_YMD " + "           , SEQ " + "           , CRT_DTM " + "           , CRT_EMPID "
			+ "           , CRT_IP " + "           , CUST_NUM " + "           , USE_CONT_NUM "
			+ "           , DEFRAY_ACCOUNT_NUM " + "           , TRANS_REQ_FLAG " + "            ) " + "VALUES      (? "
			+ "           , to_char(sysdate, 'YYYYMMDD') " + "           , (SELECT nvl(MAX(SEQ), 0) + 1 "
			+ "                FROM H11.SCS_TRANS_REQ " + "               WHERE CUS_CID = ? "
			+ "                 AND REQ_YMD = to_char(sysdate, 'YYYYMMDD')) " + "           , sysdate "
			+ "           , 'SYSTEM' " + "           , '**.**.**.**' " + "           , ? " + "           , ? "
			+ "           , ? " + "           , '10' " + "            ) ";

	private int sendKB() {
		int rValue = 0;
		/*
		 * KB로 send
		 */
		try {
			ps = conn.prepareStatement(sqlselReq);
			ps.setString(1, accountNum);
			ps.setString(2, custNum);
			ps.setString(3, useContNum);

			rs = ps.executeQuery();

			if (rs.next()) {
				String outMsg = "3000" + convFormat(treatFlag, 1) + convFormat(useContNum, 20)
						+ convFormat(accountNum, 16) + convFormat(rs.getString("VALID_YM"), 4)
						// + convFormat(socBizNum.substring(0,7) + "000000", 13)
						// //황정현 수정 8111250000000
						+ convFormat(socBizNum.substring(0, 6) + "0000000", 13) // 2015-03-13
																				// 주민번호
																				// 미수집에
																				// 따라
																				// 성별
																				// 0
																				// 처리
						+ convFormat(depositNm, 30) + convFormat(convRelatCd(relatCd, 1), 2) + convFormat(reqNm, 30)
						+ convFormat(reqCpDdd, 4) + convFormat(reqCpExn, 4) + convFormat(reqCpNum, 4)
						+ convFormat(reqTelDdd, 4) + convFormat(reqTelExn, 4) + convFormat(reqTelNum, 4)
						+ convFormat(rs.getString("ORIG_APPLY_YM"), 8) + convFormat(rs.getString("CUST_NM"), 30)
						+ convFormat(rs.getString("ZIP_NO"), 6) + convFormat(rs.getString("ADDR1"), 150)
						+ convFormat(rs.getString("ADDR2"), 150)
						// + convFormat(ci, 88) //황정현 CI 추가
						+ convFormat(" ", 88) // 2015-03-13 주민번호 미수집에 따른 CI정책 폐기
						+ convFormat(" ", 128) // 황정현 FILLER 추가
				;

				Socket socket = new Socket(kbIp, kbPort);
				socket.setSoTimeout(1000);

				BufferedInputStream bis = new BufferedInputStream(socket.getInputStream());
				BufferedOutputStream bos = new BufferedOutputStream(socket.getOutputStream());

				bos.write(2);
				bos.write(88); // 2 X 256 + 88 = 600

				bos.write(outMsg.getBytes("euc-kr"));
				bos.flush();

				byte[] readbyte = new byte[700]; // 황정현 수정 600 -> 700
				int len1 = bis.read();
				int len2 = bis.read();

				bis.read(readbyte, 0, 700); // 황정현 수정 600 -> 700

				if (bos != null)
					bos.close();
				if (bis != null)
					bis.close();
				if (socket != null)
					socket.close();

			}
		} catch (Exception e) {
			System.out.println("sendKB() : " + e.toString());
			rValue = 99;
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (ps != null) {
					ps.close();
				}
			} catch (Exception e) {
			}
		}
		return rValue;
	}

	private static final String kbIp = "10.20.1.55";
	private static final int kbPort = 23001;

	private final static String sqlselReq = "SELECT '1' TREAT_FLAG " + "     , D.USE_CONT_NUM "
			+ "     , C.DEFRAY_ACCOUNT_NUM " + "     , trim(B.VALID_PERIOD) VALID_YM " + "     , B.SOC_BIZ_NUM "
			+ "     , B.DEPOSITOR_NM " + "     , B.CUST_RELAT_CD " + "     , A.REQ_NM " + "     , A.REQ_TEL_DDD "
			+ "     , A.REQ_TEL_EXN " + "     , A.REQ_TEL_NUM " + "     , B.DEPOSITOR_TEL_DDD "
			+ "     , B.DEPOSITOR_TEL_EXN " + "     , B.DEPOSITOR_TEL_NUM " + "     , C.ORIG_APPLY_YM "
			+ "     , (SELECT CUST_NM " + "          FROM C11.C1AT_CUST_INFO X "
			+ "         WHERE X.CUST_NUM = D.CUST_NUM) CUST_NM " + "     , F.ZIP_NO1 || F.ZIP_NO2 ZIP_NO "
			+ "     , F.CITY || ' ' || F.COUNTY || ' ' || F.TOWN ADDR1 "
			+ "     , substr(E.CURR_ADDR_UNION, LENGTH(F.CITY || ' ' || F.COUNTY || ' ' || F.TOWN || ' ') + 1) ADDR2 " +
			// " , (SELECT NVL(CI_NUM, '') FROM C11.C1AT_CERT_MST WHERE
			// CERT_MANAGE_FLAG = '40' AND CERT_MANAGE_NUM = B.SOC_BIZ_NUM)
			// CI_NUM " +
			// " , (SELECT NVL(CI_NUM, '') FROM C11.C1AT_CERT_MST WHERE
			// CERT_MANAGE_FLAG = '40' AND CERT_MANAGE_NUM = (SELECT SOC_NUM
			// FROM C11.C1BT_USE_CONT A, C11.C1AT_CUST_INFO B WHERE A.CUST_NUM =
			// B.CUST_NUM AND A.USE_CONT_NUM = trim(D.USE_CONT_NUM))) CI_NUM " +
			"  FROM C11.C1AT_TRANS_ACNT_REQ A " + "     , C11.C1AT_TRANS_ACNT B " + "     , C11.C1BT_USE_CONT_TRANS C "
			+ "     , C11.C1BT_USE_CONT D " + "     , C31.C3AT_INST_PLACE E " + "     , A11.A1AT_ZIP F "
			+ " WHERE C.DEFRAY_ACCOUNT_NUM = B.DEFRAY_ACCOUNT_NUM " + "   AND C.CUST_NUM = B.CUST_NUM "
			+ "   AND A.DEFRAY_ACCOUNT_NUM(+) = C.DEFRAY_ACCOUNT_NUM " + "   AND A.CUST_NUM(+) = C.CUST_NUM "
			+ "   AND A.REQ_YMD(+) = C.REQ_YMD " + "   AND A.REQ_ITEM_CD(+) = '02' "
			+ "   AND C.REQ_INFO_NUM = D.REQ_INFO_NUM " + "   AND D.INST_PLACE_NUM = E.INST_PLACE_NUM "
			+ "   AND E.ZIP_SEQ = F.ZIP_SEQ " + "   AND C.DEFRAY_ACCOUNT_NUM = ? " + "   AND C.CUST_NUM = ? "
			+ "   AND C.REQ_INFO_NUM = ? " + "   AND C.REQ_YMD = to_char(SYSDATE, 'YYYYMMDD') ";

	public String convFormat(String str, int len) {
		String formattedstr = new String();
		byte[] buff;
		int filllen = 0;

		buff = str.getBytes();

		filllen = len - buff.length;
		formattedstr = "";

		for (int i = 0; i < filllen; i++) {
			formattedstr += " ";
		}
		formattedstr = str + formattedstr;

		return formattedstr;
	}

	/*
	 * convRelatCd(String relatCd, int direction) - 상호간 관계코드변환 direction : 0
	 * (KMC -> SCG) 1 (SCG -> KMC)
	 */
	private String convRelatCd(String relatCd, int direction) {
		String rValue = null;

		if (direction == 0 && relatCd != null) {
			if (relatCd.equals("01"))
				rValue = "10";
			else if (relatCd.equals("02"))
				rValue = "11";
			else if (relatCd.equals("03"))
				rValue = "13";
			else if (relatCd.equals("04"))
				rValue = "21";
			else if (relatCd.equals("05"))
				rValue = "12";
			else if (relatCd.equals("06"))
				rValue = "12";
			else if (relatCd.equals("07"))
				rValue = "14";
			else if (relatCd.equals("09"))
				rValue = "16";
			else
				rValue = "16";
		} else if (direction == 1 && relatCd != null) {
			if (relatCd.equals("10"))
				rValue = "01";
			else if (relatCd.equals("11"))
				rValue = "02";
			else if (relatCd.equals("12"))
				rValue = "05";
			else if (relatCd.equals("13"))
				rValue = "03";
			else if (relatCd.equals("14"))
				rValue = "07";
			else if (relatCd.equals("16"))
				rValue = "09";
			else if (relatCd.equals("21"))
				rValue = "04";
			else if (relatCd.equals("22"))
				rValue = "04";
			else
				rValue = "09";
		}
		return rValue;
	}

	/**
	 * //TODO 납부자 통합 고객인지 확인 2016-02-18 reqFlag : 카드이체 신청/변경 구분 10 : 신청 20 : 변경
	 */
	private int chkPayTot(String reqFlag) {

		int rValue = 0;

		try {
			StringBuffer sb = new StringBuffer();

			if ("10".equals(reqFlag)) {
				// 카드이체 신청시 납부자통합 확인
				sb.append("SELECT 1 ");
				sb.append("FROM C21.C2BT_PAY_TOT_OBJ A ");
				sb.append("WHERE 1=1 ");
				sb.append("AND A.USE_CONT_NUM = ? ");
				sb.append("AND A.ADD_YN ='Y' ");
			} else if ("20".equals(reqFlag)) {
				// 카드이체 변경시 납부자통합 이고 이체구분이 카드가 아닌경우(은행이체::TRAN_FLAG:10) 블락킹
				// 카드 -> 카드 변경은 가능
				sb.append("SELECT 1 ");
				sb.append("FROM    C21.C2BT_PAY_TOT_OBJ    A ");
				sb.append("    ,   C11.C1BT_REQ_INFO     B ");
				sb.append("WHERE 1=1 ");
				sb.append("AND A.USE_CONT_NUM = ? ");
				sb.append("AND A.ADD_YN = 'Y' ");
				sb.append("AND A.USE_CONT_NUM = B.REQ_INFO_NUM ");
				sb.append("AND B.PAY_METHOD_CD = '20' ");
				// sb.append("AND B.DEFRAY_ACCOUNT_NUM = rtrim(?) ");
				// sb.append("AND B.CUST_NUM = ? ");
				// sb.append("AND B.CNL_YMD = '99991231' ");
				// sb.append("AND B.TRAN_FLAG <> '20' ");
			} else {
				throw new Exception("납부자통합 확인 중 FLAG 오류");
			}

			String sqlchkPayTot = sb.toString();

			ps = conn.prepareStatement(sqlchkPayTot);

			if ("10".equals(reqFlag)) {
				ps.setString(1, useContNum);
			} else if ("20".equals(reqFlag)) {
				ps.setString(1, useContNum);
				// ps.setString(2, accountNum);
				// ps.setString(3, custNum);
			}

			rs = ps.executeQuery();

			// 건수가 있으면 납부통합고객이므로 신청 불가
			if (rs.next()) {
				rValue = 55;// 합산청구세대 신청불가
			} else {
				rValue = 0;// 정상
			}

		} catch (Exception e) {
			System.out.println("!TransAcntReq.chkPayTot() : " + e.toString());
			rValue = 99;
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}
				if (ps != null) {
					ps.close();
				}
			} catch (Exception e) {

			}
		}
		return rValue;
	}
}
