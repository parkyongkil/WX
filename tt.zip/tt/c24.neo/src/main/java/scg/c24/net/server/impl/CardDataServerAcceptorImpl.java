package scg.c24.net.server.impl;

import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.SocketChannel;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Queue;

import org.slf4j.Logger;

import scg.c24.config.CardDataConfig;
import scg.c24.data.CardDataRemote;
import scg.c24.net.server.CardDataServerAcceptor;
import scg.c24.net.server.CardDataServerService;
import scg.c24.net.transfer.CardDataTransfer;
import scg.c24.net.transfer.factory.CardDataTransferFactory;
import scg.c24.util.CardLoggerUtil;

public class CardDataServerAcceptorImpl implements CardDataServerAcceptor {

	private CardDataConfig config;
	private SocketChannel socketChannel;
	private CardDataServerService service;
	private Logger logger;

	private Selector selector;
	CardDataTransfer transfer;
	private boolean run;

	private Queue<Object> queue = new LinkedList<>();

	public CardDataServerAcceptorImpl(CardDataConfig config, SocketChannel socketChannel,
			CardDataServerService service) {
		super();
		this.config = config;
		this.socketChannel = socketChannel;
		this.service = service;
		this.logger = CardLoggerUtil.getLogger(config.getUid(), CardDataServerAcceptor.class);
		Runtime.getRuntime().addShutdownHook(new Thread() {
			@Override
			public void run() {
				close();
			}
		});
	}

	@Override
	public void run() {
		try {
			if (logger.isInfoEnabled())
				logger.info("Acceptor({}) Opended.", socketChannel.getRemoteAddress());

			selector = Selector.open();
			socketChannel.register(selector, SelectionKey.OP_READ);
			transfer = CardDataTransferFactory.create(config, socketChannel, true);

			run = true;
			while (run) {
				if (selector.select() > 0) {
					Iterator<SelectionKey> it = selector.selectedKeys().iterator();
					while (it.hasNext()) {
						SelectionKey k = it.next();
						it.remove();
						if (k == null)
							continue;
						if (k.isReadable())
							addQueue(k);
					}
				} else if (queue.size() > 0) {
					sendQueue();
				} else {
					wait(1000);
				}
			}
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		} finally {
			while (queue.size() > 0)
				sendQueue();
		}
	}

	private void addQueue(SelectionKey k) {
		while (k.isReadable()) {
			try {
				Object q = transfer.readObject();
				if (q != null)
					queue.offer(q);
			} catch (Exception e) {
				logger.error(e.getMessage(), e);
			}
		}
	}

	private void sendQueue() {
		Object q = queue.poll();
		if (q != null)
			try {
				if (q instanceof CardDataRemote)
					((CardDataRemote) q).toSCGS();
				Object r = service.call(q);
				if (r instanceof CardDataRemote)
					((CardDataRemote) r).toCARD();
				transfer.writeObject(r);
			} catch (Exception e) {
				logger.error(e.getMessage(), e);
			}
	}

	@Override
	public void close() {
		run = false;
		if (selector != null)
			try {
				selector.close();
				socketChannel = null;
			} catch (Exception e) {
				logger.error(e.getMessage(), e);
			}
		if (socketChannel != null)
			try {
				socketChannel.close();
				if (logger.isInfoEnabled())
					logger.info("Acceptor({}) Closed.", socketChannel.getRemoteAddress());
				socketChannel = null;
			} catch (Exception e) {
				logger.error(e.getMessage(), e);
			}
	}

}
