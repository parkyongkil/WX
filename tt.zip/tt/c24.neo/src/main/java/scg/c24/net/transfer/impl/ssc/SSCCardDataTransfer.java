package scg.c24.net.transfer.impl.ssc;

import java.nio.ByteBuffer;
import java.nio.channels.SocketChannel;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;

import scg.c24.config.CardDataConfig;
import scg.c24.data.ssc.SSC8050;
import scg.c24.data.ssc.SSC8150;
import scg.c24.data.ssc.SSC9050;
import scg.c24.data.ssc.SSC9150;
import scg.c24.data.ssc.SSCData;
import scg.c24.net.transfer.impl.CardDataTransferBase;

public class SSCCardDataTransfer extends CardDataTransferBase {

	private static final int HL = 70;
	private static final int FZ = 4096;
	private ByteBuffer ff = ByteBuffer.allocate(FZ);

	public SSCCardDataTransfer(CardDataConfig config, SocketChannel socketChannel, boolean forServer) {
		super(config, socketChannel, forServer);
	}

	@Override
	public byte[] read() throws Exception {
		ff.clear();
		ff.limit(HL);
		byte[] b = ff.array();
		int i = socketChannel.read(ff);
		if (i == 0) {
			logger.error("{}: red 0 byte.", tr);
			return null;
		}
		if (i < 0)
			throw new Exception("읽기채널이 끊겼습니다.");
		if (i != HL) {
			ff.rewind();
			logger.error("전문공통부읽기: {} 바이트, 기대값: {} 바이트.\n[{}]", i, HL, new String(b, 0, i, charset));
			throw new Exception("전문공통부를 읽지 못하였습니다.");
		}
		int n = NumberUtils.toInt(new String(b, 9, 5));
		ff.limit(n);
		i = socketChannel.read(ff);
		if (i + HL < n)
			logger.error("전문개별부읽기: {} 바이트, 기대값: {} 바이트.\n[{}]", i, HL, new String(b, 0, i + HL, charset));
		if (logger.isInfoEnabled()) {
			logger.info("{}({}): {}[{}]", tr, new String(b, 17, 4, charset), n, new String(b, 0, n, charset));
		}
		b = new byte[n];
		ff.rewind();
		ff.get(b, 0, n);
		return b;
	}

	@SuppressWarnings("unchecked")
	@Override
	public <X> X readObject() throws Exception {
		byte[] b = read();
		String sx = new String(b, 17, 4);
		int nx = NumberUtils.toInt(sx);
		Class<? extends SSCData> c = null;
		switch (nx) {
		case 8050:
		case 8051:
			c = SSC8050.class;
			break;
		case 8150:
		case 8151:
			c = SSC8150.class;
			break;
		case 9050:
		case 9051:
			c = SSC9050.class;
			break;
		case 9150:
		case 9151:
			c = SSC9150.class;
			break;
		default:
			throw new Exception(String.format("처리할 수 없는 전문구분번호(%s)입니다.", sx));
		}
		return (X) toObject(b, c);
	}

	@Override
	public void write(byte[] b) throws Exception {
		socketChannel.write(ByteBuffer.wrap(b));
	}

	@Override
	public <X> void writeObject(X o) throws Exception {
		byte[] b = toBytes(o), a = null;
		SSCData d = (SSCData) o;
		d.a02 = b.length;
		d.a07 = b.length - HL;
		if (b.length < HL)
			throw new Exception(String.format("유효하지 않은 전문입니다.\n%d[%s]", b.length, new String(b, charset)));
		a = StringUtils.leftPad(String.valueOf(d.a02), 5, '0').getBytes();
		System.arraycopy(a, 0, b, 9, 5);
		a = StringUtils.leftPad(String.valueOf(d.a07), 4, '0').getBytes();
		System.arraycopy(a, 0, b, 57, 4);
		write(b);
	}

	@Override
	public void clear() {
		try {
			do {
				ff.clear();
			} while (socketChannel.read(ff) > 0);
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
	}
}
