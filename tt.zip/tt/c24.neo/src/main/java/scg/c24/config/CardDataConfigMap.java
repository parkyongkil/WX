package scg.c24.config;

public class CardDataConfigMap {

}
