package scg.c24.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CardLoggerUtil {

	public static Logger getLogger(String uid, Class<?> clazz) {
		return LoggerFactory.getLogger(String.format("%s", clazz.getSimpleName()));
	}

	public static Logger getLogger(String uid, Class<?> clazz, String spx) {
		return LoggerFactory.getLogger(String.format("%s%s", clazz.getSimpleName(), spx));
	}

	public static Logger getLogger(String uid, String name) {
		return LoggerFactory.getLogger(String.format("%s", name));
	}
}
