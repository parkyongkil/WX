package scg.c24.net.server;

import java.io.Closeable;

public interface CardDataServerService extends Closeable {

	<Q, R> R call(Q q) throws Exception;

	<Q, R> R callMis(Q q) throws Exception;

	void close();
}
