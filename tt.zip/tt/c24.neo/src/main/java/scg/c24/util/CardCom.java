package scg.c24.util;

import java.util.HashMap;

public class CardCom {

	public static final String SHC = "SHC";
	public static final String SSC = "SSC";
	public static final String KMC = "KMC";

	private static HashMap<String, CardCom> M = new HashMap<>();
	static {
		M.put("807", new CardCom(KMC, "807", "xxx", "xxx", "KOOKMINCD"));
		M.put("808", new CardCom(SHC, "808", "110", "001", "SHCard"));
		M.put("803", new CardCom(SSC, "803", "120", "002", "SAMSUNGCD"));
	}

	public static CardCom getByCardCd(String s) {
		return M.get(s);
	}

	public static CardCom getByCardCid(String s) {
		for (CardCom c : M.values())
			if (c.getCid().equals(s))
				return c;
		return null;
	}

	private final String cid;
	private final String bnkCd;
	private final String memberCd;
	private final String partnerCd;
	private final String name;

	public CardCom(String cid, String bnkCd, String memberCd, String partnerCd, String name) {
		super();
		this.cid = cid;
		this.bnkCd = bnkCd;
		this.memberCd = memberCd;
		this.partnerCd = partnerCd;
		this.name = name;
	}

	public String getCid() {
		return cid;
	}

	public String getBnkCd() {
		return bnkCd;
	}

	public String getMemberCd() {
		return memberCd;
	}

	public String getPartnerCd() {
		return partnerCd;
	}

	public String getName() {
		return name;
	}
}
