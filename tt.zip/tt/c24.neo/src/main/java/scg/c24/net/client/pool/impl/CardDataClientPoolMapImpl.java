package scg.c24.net.client.pool.impl;

import java.util.HashMap;

import org.springframework.stereotype.Component;

import scg.c24.net.client.pool.CardDataClientPool;
import scg.c24.net.client.pool.CardDataClientPoolMap;

@Component
public class CardDataClientPoolMapImpl extends HashMap<String, CardDataClientPool> implements CardDataClientPoolMap {

	@Override
	public CardDataClientPool get(String uid) {
		return super.get(uid);
	}

	@Override
	public CardDataClientPool put(String uid, CardDataClientPool pool) {
		super.put(uid, pool);
		return pool;
	}

	@Override
	public CardDataClientPool remove(String uid) {
		return super.remove(uid);
	}

	@Override
	public void close() {
		for (CardDataClientPool pool : values())
			if (pool != null)
				pool.close();
		super.clear();
	}

}
