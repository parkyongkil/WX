package scg.c24.net.client;

import java.io.Closeable;

public interface CardDataClientService extends Closeable {

	<Q, R> R call(Q q) throws Exception;

	<Q, R> R callMis(Q q) throws Exception;

	void close();
}
