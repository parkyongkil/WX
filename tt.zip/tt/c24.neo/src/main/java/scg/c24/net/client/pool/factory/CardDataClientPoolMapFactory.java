package scg.c24.net.client.pool.factory;

import scg.c24.ApplicationContextHolder;
import scg.c24.net.client.pool.CardDataClientPoolMap;
import scg.c24.net.client.pool.impl.CardDataClientPoolMapImpl;

public class CardDataClientPoolMapFactory {

	public static CardDataClientPoolMap create() {
		return ApplicationContextHolder.getBean(CardDataClientPoolMapImpl.class);
	}
}
