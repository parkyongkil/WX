package scg.c24.net.server;

import java.io.Closeable;

public interface CardDataServer extends Runnable, Closeable {

	void close();
}
