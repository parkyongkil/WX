package scg.c24.data.kmc;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Component;

import scg.c24.ApplicationContextHolder;
import scg.c24.biz.kmc.KMCUseCont;
import scg.c24.biz.kmc.KMCUseContMapper;
import scg.c24.net.process.CardDataProcess;
import scg.c24.net.server.impl.kmc.KMCCardDataServerService;

@Component
public class KMC1000Process implements CardDataProcess<KMC1000, KMC1000> {

	KMCUseContMapper m1 = ApplicationContextHolder.getBean(KMCUseContMapper.class);

	@Override
	public KMC1000 call(KMC1000 q) throws Exception {

		KMC1000 r = new KMC1000();
		KMCCardDataServerService.setResponseHeader(q, r);

		String useContNum = q.b01;
		String custName = q.b06;
		String cp1 = q.b10;
		String cp2 = q.b11;
		String cp3 = q.b12;

		List<KMCUseCont> l = StringUtils.length(useContNum) == 10 ? m1.selectKMCUseContByUseContNum(useContNum)
				: m1.selectUseContByUseCustNmCp(custName, cp1, cp2, cp3);

		if (l != null && l.size() > 0) {
			KMCUseCont u = l.get(0);
			r.a06 = "0000"; // 성공
			r.b01 = u.getUSE_CONT_NUM();
			r.b02 = u.getCONT_STS();
			r.b03 = u.getPAY_METHOD_CD();
			r.b04 = u.getBNK_NM();
			r.b05 = u.getFIRST_YMD();
			r.b06 = u.getCUST_NM();
			r.b07 = u.getZIP_NO();
			r.b08 = u.getADDR1();
			r.b09 = u.getADDR2();
			r.b10 = u.getCP_DDD();
			r.b11 = u.getCP_EXN();
			r.b12 = u.getCP_NUM();
		} else {
			r.a06 = "1112";
			r.a07 = "검색결과없음";
		}
		return r;
	}
}
