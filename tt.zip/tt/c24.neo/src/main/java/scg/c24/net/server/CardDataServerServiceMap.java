package scg.c24.net.server;

import java.io.Closeable;

public interface CardDataServerServiceMap extends Closeable {

	CardDataServerService get(String uid);

	CardDataServerService put(String uid, CardDataServerService service);

	CardDataServerService remove(String uid);

	void close();
}
