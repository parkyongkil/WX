package scg.c24.net.client.impl.kmc;

import java.util.Date;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import scg.c24.config.CardDataConfig;
import scg.c24.data.kmc.KMC3000;
import scg.c24.data.kmc.KMC4000;
import scg.c24.data.kmc.KMC4100;
import scg.c24.data.kmc.KMCData;
import scg.c24.mis.data.MIS3000q;
import scg.c24.mis.data.MIS3000r;
import scg.c24.mis.data.MIS4000q;
import scg.c24.mis.data.MIS4000r;
import scg.c24.net.client.CardDataClient;
import scg.c24.net.client.CardDataClientService;
import scg.c24.net.client.pool.CardDataClientPool;
import scg.c24.util.CardCom;

public class KMCCardDataClientService implements CardDataClientService {

	protected CardDataConfig config;
	private CardDataClientPool pool;
	private Logger logger = LoggerFactory.getLogger(CardDataClientService.class);

	public KMCCardDataClientService(CardDataConfig config, CardDataClientPool pool) {
		super();
		this.config = config;
		this.pool = pool;
	}

	@Override
	public <Q, R> R call(Q q) throws Exception {
		CardDataClient client = pool.borrowObject();
		try {
			return client.call(q);
		} catch (Exception e) {
			pool.invalidateObject(client);
			client = null;
			throw e;
		} finally {
			if (client != null)
				pool.returnObject(client);
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public <Q, R> R callMis(Q q) throws Exception {
		if (q instanceof MIS3000q)
			return (R) mis3000((MIS3000q) q);
		if (q instanceof MIS4000q)
			return (R) mis4000((MIS4000q) q);
		throw new Exception(String.format("처리할수 없는 구조체(%s)입니다.", q == null ? "X" : q.getClass().getSimpleName()));
	}

	@Override
	public void close() {
		// NOTHING
	}

	public static void setRequestHeader(KMCData cq, CardCom cc, String cd) {
		String ts = DateFormatUtils.format(new Date(), "yyyyMMddHHmmss");
		String ns = String.valueOf(System.nanoTime()).substring(0, 6);
		String cid = cc.getCid();

		cq.a01 = cd;
		cq.a02 = "SCG";
		cq.a03 = cid;
		cq.a04 = String.format("%s%s", ts, ns);
		cq.a05 = ts;
	}

	/**
	 * (3000, 9150) 자동납부신청 (서울도시가스 -> 카드사)
	 */
	public MIS3000r mis3000(MIS3000q mq) {

		MIS3000r mr = new MIS3000r();
		KMC3000 q = new KMC3000();
		KMC3000 r = new KMC3000();

		setRequestHeader(q, CardCom.getByCardCd(mq.CARD_CD), "9150");

		q.b01 = mq.TREAT_FLAG;
		q.b02 = mq.USE_CONT_NUM;
		q.b03 = mq.DEFRAY_ACCOUNT_NUM;
		q.b04 = mq.VALID_YM;
		q.b05 = mq.SOC_BIZ_NUM;
		q.b06 = mq.DEPOSITOR_NM;
		q.b07 = mq.CUST_RELAT_CD;
		q.b08 = mq.REQ_NM;
		q.b09 = mq.REQ_TEL_DDD;
		q.b10 = mq.REQ_TEL_EXN;
		q.b11 = mq.REQ_TEL_NUM;
		q.b12 = mq.DEPOSITOR_TEL_DDD;
		q.b13 = mq.DEPOSITOR_TEL_EXN;
		q.b14 = mq.DEPOSITOR_TEL_NUM;
		q.b15 = mq.ORIG_APPLY_YM;
		q.b16 = mq.CUST_NM;
		q.b17 = mq.ZIP_NO;
		q.b18 = mq.ADDR1;
		q.b19 = mq.ADDR2;

		try {
			r = call(q);

			if (StringUtils.equals(q.a04, r.a04)) {
				boolean b = "0000".equals(r.a06);
				mr.RSLT_CD = r.a06;
				mr.RSLT_NM = b ? "정상" : String.format("오류: %s", r.a07);
			} else {
				mr.RSLT_CD = "91";
				mr.RSLT_NM = "거래번호가 일치하지 않는 응답을 수신하였습니다.";
			}

		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			mr.RSLT_CD = "99";
			mr.RSLT_NM = "카드사에 요청 중 오류가 발생하였습니다.";
		}
		return mr;
	}

	/**
	 * 카드인증조회 요청 (4000, 9050) (서울도시가스 -> 카드사)
	 */
	public MIS4000r mis4000(MIS4000q mq) {

		MIS4000r mr = new MIS4000r();
		KMC4000 q = new KMC4000();

		setRequestHeader(q, CardCom.getByCardCd(mq.CARD_CD), "9050");

		q.b01 = mq.CARD_NUM;
		q.b02 = mq.SOC_BIZ_NUM;

		try {
			KMC4100 r = call(q);
			if (StringUtils.equals(q.a04, r.a04)) {
				boolean b = "0000".equals(r.a06);
				mr.RSLT_CD = r.a06;
				mr.RSLT_NM = b ? "정상" : String.format("오류: %s", r.a07);
			} else {
				mr.RSLT_CD = "91";
				mr.RSLT_NM = "거래번호가 일치하지 않는 응답을 수신하였습니다.";
			}

			mr.CARD_STS_CD = r.b03;
			mr.JOIN_YN = r.b04;
			mr.VALID_YM = StringUtils.substring(r.b05, 2);

		} catch (Exception e) {
			logger.error(e.getMessage(), e);
			mr.RSLT_CD = "99";
			mr.RSLT_NM = "카드사에 요청 중 오류가 발생하였습니다.";
		}
		return mr;
	}
}
