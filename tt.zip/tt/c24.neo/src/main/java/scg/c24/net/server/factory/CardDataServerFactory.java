package scg.c24.net.server.factory;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import scg.c24.config.CardDataConfig;
import scg.c24.net.server.CardDataServer;
import scg.c24.net.server.CardDataServerMap;

public class CardDataServerFactory {

	static ExecutorService executor = Executors.newCachedThreadPool();

	public static CardDataServer create(CardDataConfig config) throws Exception {
		String uid = config.getUid();
		CardDataServerMap map = CardDataServerMapFactory.create();
		CardDataServer server = map.get(uid);
		if (server != null)
			server.close();
		server = config.getServer().getServerType().getConstructor(CardDataConfig.class).newInstance(config);
		// server =
		// ApplicationContextHolder.getBean(config.getServer().getServerType(),
		// config);
		executor.execute(server);
		return map.put(uid, server);
	}

	public static void shutdown() {
		executor.shutdown();
	}
}
