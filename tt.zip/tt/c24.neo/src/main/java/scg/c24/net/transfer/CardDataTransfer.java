package scg.c24.net.transfer;

public interface CardDataTransfer {

	byte[] read() throws Exception;

	<X> X readObject() throws Exception;

	void write(byte[] b) throws Exception;

	<X> void writeObject(X o) throws Exception;

	void clear();
}
