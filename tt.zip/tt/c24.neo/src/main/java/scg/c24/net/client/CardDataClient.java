package scg.c24.net.client;

public interface CardDataClient {

	public void open() throws Exception;

	public boolean validate();

	public void clear();

	public void close();

	public <Q, R> R call(Q q) throws Exception;
}
