package scg.c24.config.factory;

import org.springframework.boot.context.properties.ConfigurationPropertiesBindingPostProcessor;

import scg.c24.ApplicationContextHolder;
import scg.c24.config.CardDataConfig;

public class CardDataConfigFactory {

	static ConfigurationPropertiesBindingPostProcessor postProcessor = new ConfigurationPropertiesBindingPostProcessor();

	public static CardDataConfig create(String uid) {
		postProcessor.setApplicationContext(ApplicationContextHolder.getContext());
		CardDataConfig config = new CardDataConfig();
		postProcessor.postProcessBeforeInitialization(config, String.format("card.%s", uid));
		return config;
	}
}
